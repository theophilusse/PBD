import bpy

from .. import mesh_preview, uv_layout


def refresh_pbd_uv_mapping(obj):
    """Lays the texture coordinates of this PBD primitive's preview mesh out exactly as the ENGINE lays its texture over the real
    primitive (uv_layout.py has the tables, tools/regression/blender_addon_check.py judges them with the engine's own evaluator of
    the shader): each patch of the primitive - a cube's face, a cylinder's wall or cap, the whole of a sphere - shows the picture
    once, and the material's UV Scale repeats (or, negative, mirrors) it. Nothing depends on the object's size, so resizing never
    stretches a texture - a wall 4 m long and a door 4 cm thick both show the picture once; give the wall's material a bigger UV
    Scale to tile it.

    This replaces a cube projection at the object's size (bpy.ops.uv.cube_project), which is a different layout on every face
    the moment the object is not a cube - the texture streaked in Blender where the engine showed it whole - and needed edit
    mode and a selection. Here nothing but mesh data is touched, in any mode.

    A cube whose faces were removed or rounded is a grid generated from the patches' own coordinates: it is generated again (its
    mesh is defined by its settings, not by hand edits). A cap that is one polygon of many sides - what older versions of this
    add-on and Blender's own default make - is given a middle vertex first. Returns True when the object has an engine layout."""
    if obj is None or obj.type != 'MESH' or not getattr(obj, "pbd", None):
        return False
    prim_type = obj.pbd.pbd_type
    if prim_type not in uv_layout.ENGINE_TYPES:
        return False
    from .. import properties  # here, not at the top: properties imports mesh_preview, and this module is imported by the panel
    if prim_type == 'cube' and len(obj.data.polygons) != 6:
        properties.regenerate_cube_preview(obj.pbd)
        return True
    positions = properties.undeformed_positions(obj)
    if positions is None and prim_type in ('cylinder', 'cone', 'disc'):
        mesh_preview.poke_ngons(obj)
    mesh_preview.write_engine_uvs(obj, prim_type, positions)
    return True


class OBJECT_OT_add_pbd_primitive(bpy.types.Operator):
    """Adds a PBD primitive: a standard Blender mesh for preview/manipulation
    in the viewport, tagged with the type and material the exporter will
    read later."""

    bl_idname = "object.add_pbd_primitive"
    bl_label = "Add PBD Primitive"
    bl_options = {'REGISTER', 'UNDO'}

    prim_type: bpy.props.EnumProperty(
        items=[
            ('plane', "Plane", ""),
            ('sphere', "Sphere", ""),
            ('cylinder', "Cylinder", ""),
            ('cone', "Cone", ""),
            ('cube', "Cube", ""),
            ('disc', "Disc", ""),
            ('torus', "Torus", ""),
        ],
        default='cube',
    )

    def execute(self, context):
        # Uses Blender's own native default sizes (all 6 primitives fit in
        # a 2x2x2 box, 2x2x0 for the flat ones - plane and disc) - the
        # exporter compensates for this factor at export time (see
        # export_pbd.py), which removes any distinction between objects
        # created here and objects created via Blender's native Mesh tools
        # and tagged by hand afterwards. Disc is filled (fill_type='TRIFAN',
        # a fan round a middle vertex: an actual filled circle, not just a
        # wire outline - confirmed, not assumed, to match the same 2x2x0
        # sizing as the others), and so are the caps of the cylinder and the
        # cone: the engine lays a texture over a cap in polar coordinates,
        # which needs a middle.
        if self.prim_type == 'plane':
            bpy.ops.mesh.primitive_plane_add()
        elif self.prim_type == 'sphere':
            bpy.ops.mesh.primitive_uv_sphere_add()
        elif self.prim_type == 'cylinder':
            bpy.ops.mesh.primitive_cylinder_add(end_fill_type='TRIFAN')  # caps with a middle vertex: see refresh_pbd_uv_mapping
        elif self.prim_type == 'cone':
            bpy.ops.mesh.primitive_cone_add(end_fill_type='TRIFAN')
        elif self.prim_type == 'cube':
            bpy.ops.mesh.primitive_cube_add()
        elif self.prim_type == 'disc':
            bpy.ops.mesh.primitive_circle_add(fill_type='TRIFAN')
        elif self.prim_type == 'torus':
            # major=0.7, minor=0.3 here (not the engine's canonical
            # 0.35/0.15) for the same reason cylinder/cube aren't created
            # at their literal 0.5 half-extent: every type's exported
            # scale gets the same x0.5 (_BLENDER_TO_SHADER_SCALE)
            # correction, so every native mesh needs to start at 2x its
            # canonical size for scale=1 to come out matching after export.
            bpy.ops.mesh.primitive_torus_add(major_radius=0.7, minor_radius=0.3)
        else:
            self.report({'ERROR'}, f"Unknown PBD type: {self.prim_type}")
            return {'CANCELLED'}

        obj = context.active_object
        obj.name = self.prim_type
        obj.pbd.is_pbd_primitive = True
        obj.pbd.pbd_type = self.prim_type
        refresh_pbd_uv_mapping(obj)
        return {'FINISHED'}


class OBJECT_OT_add_pbd_ref(bpy.types.Operator):
    """Adds a pbd_ref: an Empty (no geometry of its own) that places
    another .pbd file's whole scene here, transformed by this object's
    pos/rot/scale - see PbdParser.parsePbdRef on the engine side, which
    this mirrors. Blender can't preview the referenced file's actual
    geometry (that would need a full .pbd importer, planned for after the
    format reaches a stable 2.0 - see the project README), so the Empty's
    display is just a placement/orientation marker, not a preview."""

    bl_idname = "object.add_pbd_ref"
    bl_label = "Add PBD Reference"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        bpy.ops.object.empty_add(type='ARROWS', radius=1.0)
        obj = context.active_object
        obj.name = "pbd_ref"
        obj.pbd.is_pbd_primitive = True
        obj.pbd.pbd_type = 'ref'
        return {'FINISHED'}


class OBJECT_OT_add_pbd_light(bpy.types.Operator):
    """Adds a light: an Empty (no geometry of its own, same category as
    pbd_ref) carrying point/spot light parameters - see PbdInstance's
    own light* fields on the engine side. Uses Blender's own light-bulb
    Empty display type purely as a recognizable placement marker in the
    viewport - it does NOT create or link a real Blender Light
    data-block, so Blender's own viewport lighting is unaffected; only
    the exported .pbd's lightMode/lightColor/etc. fields, and the Java
    engine reading them, actually light anything."""

    bl_idname = "object.add_pbd_light"
    bl_label = "Add PBD Light"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        bpy.ops.object.empty_add(type='SPHERE', radius=0.15)
        obj = context.active_object
        obj.name = "pbd_light"
        obj.pbd.is_pbd_primitive = True
        obj.pbd.pbd_type = 'light'
        return {'FINISHED'}


class OBJECT_OT_add_pbd_group(bpy.types.Operator):
    """Adds a pivot: an Empty (no geometry, no volume - the engine's own
    `group` type) that other PBD objects are parented to so they move with
    it. Its job in practice is to be a HINGE: a PBD cube is always centred
    on its own origin in Blender, so a door cannot be given a pivot on its
    own edge - a pivot Empty placed at the hinge, with the door panel and
    its handle parented to it, can. Put the Lever Arm on the pivot (not on
    the door), and the whole door swings around the hinge line, handle and
    any light or decoration attached along with it.

    Keep the pivot's scale at 1: children inherit their parent's scale
    exactly like in Blender, and the engine does the same."""

    bl_idname = "object.add_pbd_group"
    bl_label = "Add PBD Pivot"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        bpy.ops.object.empty_add(type='PLAIN_AXES', radius=0.25)
        obj = context.active_object
        obj.name = "pbd_pivot"
        obj.pbd.is_pbd_primitive = True
        obj.pbd.pbd_type = 'group'
        return {'FINISHED'}


def menu_func(self, context):
    self.layout.separator()
    for prim_type, label in (
        ('plane', "PBD Plane"),
        ('sphere', "PBD Sphere"),
        ('cylinder', "PBD Cylinder"),
        ('cone', "PBD Cone"),
        ('cube', "PBD Cube"),
        ('disc', "PBD Disc"),
        ('torus', "PBD Torus"),
    ):
        op = self.layout.operator(OBJECT_OT_add_pbd_primitive.bl_idname, text=label)
        op.prim_type = prim_type
    # The things that are not a shape - until these were listed here, a light could only be found in the sidebar
    self.layout.operator(OBJECT_OT_add_pbd_light.bl_idname, text="PBD Light")
    self.layout.operator(OBJECT_OT_add_pbd_group.bl_idname, text="PBD Pivot (hinge)")
    self.layout.operator(OBJECT_OT_add_pbd_ref.bl_idname, text="PBD Reference")


CLASSES = (OBJECT_OT_add_pbd_primitive, OBJECT_OT_add_pbd_ref, OBJECT_OT_add_pbd_light,
           OBJECT_OT_add_pbd_group)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.VIEW3D_MT_mesh_add.append(menu_func)


def unregister():
    bpy.types.VIEW3D_MT_mesh_add.remove(menu_func)
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
