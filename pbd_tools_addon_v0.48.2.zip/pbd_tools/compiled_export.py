"""The compiled formats, written by the add-on itself: .pbdbin and .pbdasset - no Java, no Gradle.

The add-on used to hand both to Java: it asked Gradle for the project's classpath and ran pbd.PbdConvertMain with the `java` of the PATH.
That chain wants the Gradle project above the file, a Java as recent as the one the classes were compiled for, and a quiet half minute - and
on a machine whose `java` was older than the Java 21 Gradle fetches for the project it ended in
"UnsupportedClassVersionError: pbd/PbdConvertMain has been compiled by a more recent version of the Java Runtime". Neither format needs Java:

  .pbdbin    the four bytes `PBDB`, a version byte (1), then a gzip stream of the minified .pbd text. The engine's PbdBinFormat reads exactly
             that (gunzip, then the same parser as any .pbd); the add-on's importer already did.
  .pbdasset  a plain zip: manifest.txt (author=, date=, version=, description= lines), scene.pbd, and every material and picture the scene
             names, at the relative paths its include_material lines say (PbdAssetFormat.pack / unpack).

so the add-on writes them. Pure Python, no bpy (a check runs it on its own, and the engine reads what it writes: tools/regression).

What it takes care of, which the Java route did not:

  - the engine's own limits (safety.MAX_DECOMPRESSED_BYTES, MAX_ASSET_*, the rules for an entry's name) are checked BEFORE the file is
    written: an export never produces a file the engine would refuse to open;
  - the file is written to a name of its own beside the destination and moved into place, so a failure (a full disk, a name Windows refuses)
    leaves the file that was there before as it was, and no half-written one;
  - the pictures of the scene's materials come with the file: a .pbdasset is self-contained (it used to leave them out, quietly), and a
    .pbdbin has its .pbdmat and its pictures beside it, named after it (it used to write a `scene.pbdmat` that the next export overwrote);
  - what cannot be done is said (a picture that is not there, two pictures with one file name), never skipped in silence.
"""

import gzip
import os
import posixpath
import re
import zipfile

from . import safety
from .pbdmat_text import parse_pbdmat_text

#: The first four bytes of a .pbdbin, and the version byte after them (pbd.format.PbdBinFormat).
PBDBIN_MAGIC = b"PBDB"
PBDBIN_VERSION = 1

#: Entries of a .pbdasset that mean something to the engine: a bundled file cannot take one of these names.
RESERVED_ENTRIES = ("manifest.txt", "scene.pbd", "icon.png")

#: The date every entry of a bundle carries: two exports of the same scene give the same bytes.
_ENTRY_TIME = (1980, 1, 1, 0, 0, 0)


# ---- .pbdbin ----------------------------------------------------------------------------------------------------------------------------------

def pbdbin_bytes(text, limit=safety.MAX_DECOMPRESSED_BYTES):
    """The content of the .pbdbin for a scene's (minified) text: PBDB, 1, then the gzip of the UTF-8 text. Refused - before anything is written -
    when the text is longer than `limit` (the engine refuses a compiled scene that expands to more than 64 MB) or the file would be."""
    data = text.encode("utf-8")
    if len(data) > limit:
        raise safety.Refused(f"the scene is {safety.describe(len(data))} of text: the engine refuses a compiled scene that expands to "
                             f"more than {safety.describe(limit)}")
    packed = PBDBIN_MAGIC + bytes([PBDBIN_VERSION]) + gzip.compress(data, compresslevel=9, mtime=0)
    if len(packed) > limit:
        raise safety.Refused(f"the compiled scene would be {safety.describe(len(packed))}: the engine refuses a file of more than {safety.describe(limit)}")
    return packed


def write_atomic(path, data):
    """Writes `data` to `path` by writing a file of its own beside it and moving it into place: the file that was there is replaced whole or not
    at all. Makes the folder when it is not there. Returns the number of bytes written."""
    path = os.path.abspath(path)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    part = f"{path}.{os.getpid()}.part"
    try:
        with open(part, "wb") as f:
            f.write(data)
        os.replace(part, path)
    except BaseException:
        try:
            os.remove(part)
        except OSError:
            pass
        raise
    return len(data)


# ---- the pictures a scene's materials name ----------------------------------------------------------------------------------------------------

def texture_sources(paths, abspath=os.path.abspath):
    """-> ({file name: absolute path}, [what to tell the person]) for the picture files a material catalog names (`paths` as they are typed,
    empty ones ignored; `abspath` is bpy.path.abspath in Blender, which knows `//` is the .blend's folder).

    A .pbdmat names a picture by its FILE NAME alone, so two different pictures that share one name cannot both be found: the first is
    kept, and the person is told."""
    sources = {}
    notes = []
    for raw in paths:
        if not raw or not str(raw).strip():
            continue
        absolute = os.path.normpath(abspath(raw))
        name = os.path.basename(absolute)
        if not name:
            continue
        known = sources.get(name)
        if known is None:
            sources[name] = absolute
        elif os.path.normcase(known) != os.path.normcase(absolute):
            notes.append(f"two different pictures are both called '{safety.printable(name)}' ({safety.printable(known)} and {safety.printable(absolute)}): "
                         f"a .pbdmat names a picture by its file name alone, so the engine finds one of them for both - rename one")
    return sources, notes


PICTURE_KEYS = ("texture", "normalMap", "roughnessMap", "displacementMap")


def picture_names(pbdmat_text):
    """The file names a .pbdmat's texture, normalMap, roughnessMap and displacementMap fields give, material by material in the order the file has
    them, each name once - read by the engine's own grammar (pbdmat_text.py): a name in quotes, or up to the first space or bracket, a `#` that starts a
    comment only where a word could start, a value on the line after its `=`. Raises ValueError (with the line) for a file the engine refuses."""
    _authors, materials = parse_pbdmat_text(pbdmat_text)
    names = []
    for fields in materials.values():
        for key in PICTURE_KEYS:
            name = fields.get(key)
            if name and name not in names:
                names.append(name)
    return names


def _same_file(a, b):
    return os.path.normcase(os.path.abspath(a)) == os.path.normcase(os.path.abspath(b))


def _copy_unless_there(source, target):
    """Copies `source` to `target` unless it is there already. -> "copied", "there" (the same file, or one with the same bytes) or "differs" (another
    file with that name is there: it is not replaced - it may be somebody's)."""
    import filecmp
    import shutil
    if os.path.exists(target):
        if _same_file(source, target) or filecmp.cmp(source, target, shallow=False):
            return "there"
        return "differs"
    os.makedirs(os.path.dirname(os.path.abspath(target)), exist_ok=True)
    shutil.copyfile(source, target)
    return "copied"


def place_beside(staged_pbdmat, out_dir, sources, copy_textures=True):
    """What goes beside a .pbdbin (a .pbdbin is not a bundle: its materials stay files of their own, like those of a .pbd): the .pbdmat the scene
    includes - written whole, as it is the export's own - and, unless `copy_textures` is off, the pictures it names, each copied unless a file
    with that name is there already. -> ([names written], [what to tell the person])."""
    written = []
    notes = []
    if staged_pbdmat and os.path.isfile(staged_pbdmat):
        name = os.path.basename(staged_pbdmat)
        with open(staged_pbdmat, "rb") as f:
            write_atomic(os.path.join(out_dir, name), f.read())
        written.append(name)
        if copy_textures:
            for name, source in sources.items():
                if not os.path.isfile(source):
                    notes.append(f"the picture '{safety.printable(source)}' is not there: it was not copied (the material still names it)")
                    continue
                verdict = _copy_unless_there(source, os.path.join(out_dir, name))
                if verdict == "copied":
                    written.append(name)
                elif verdict == "differs":
                    notes.append(f"'{safety.printable(name)}' beside the file is not the picture the material uses ({safety.printable(source)}): "
                                 f"it was left as it is")
    return written, notes


# ---- .pbdasset --------------------------------------------------------------------------------------------------------------------------------

def manifest_text(author=None, date=None, version=None, description=None):
    """manifest.txt: a `key=value` line for each of author, date, version and description that has a value (PbdAssetFormat.Manifest). A value is
    kept on one line - the reader takes a line for a field."""
    rows = []
    for key, value in (("author", author), ("date", date), ("version", version), ("description", description)):
        value = " ".join(str(value).split()) if value is not None else ""
        if value:
            rows.append(f"{key}={value}\n")
    return "".join(rows)


_INCLUDE_LINE = re.compile(r'^include_material[ \t]+(?:"([^"\n]*)"|([^\s"#]+))[ \t]*$', re.MULTILINE)


def _is_url(text):
    """What the engine takes for an address (PbdParser.isUrl): http or https, in any case, from the first character - a quoted value is not trimmed
    by the reader, so " https://x" is a file name to it, and is looked for as one here."""
    return text.lower().startswith(("http://", "https://"))


def quote_word(word):
    """A file name, an address, a material name, a category or a link group as the scene reader (PbdParser.readRawValue) must see it: bare, or in
    quotes when a bare one would be cut short. A bare value stops at a space, a tab or one of `{ } ( ) [ ] = ,` (PbdParser.isStructural) -
    `scene(1).pbdmat` was read as `scene` and the file was not found, `a,b` was refused - and a `#` starts a comment. A quoted value runs to the next
    `"`, so the quotes keep it whole (a name with a `"` in it cannot be written either way: the include lines this module reads cannot hold one).
    The exporter uses this one too, so the line it writes and the line the bundle rewrites follow the same rule."""
    return f'"{word}"' if (word == "" or any(c.isspace() or c in '{}()[]=,#' for c in word)) else word


def entry_name_problem(name):
    """None when a bundle may hold an entry of this name, else why not: the engine's rules (PbdLimits.entryTarget, safety.entry_target)."""
    if safety.entry_target(os.path.abspath(os.sep + "bundle"), name) is None:
        return "it is not a plain relative path (no drive, no '..', no backslash, no empty part, no name Windows keeps for itself, at most 255 long)"
    if name.lower() in RESERVED_ENTRIES:
        return "a bundle has a file of its own with that name"
    return None


def bundle_scene(text, staged_pbd, sources, blend_dir=None, texture_dirs=(), reference_dir=None):
    """What a .pbdasset holds, from the scene text the exporter wrote at `staged_pbd` (pretty text: its include_material lines are read as lines).
    -> (the scene text for the bundle, {name in the bundle: file to take it from}, [what to tell the person]).

    Every material the scene includes comes into the bundle - the .pbdmat the export wrote beside the scene keeps its name, any other becomes
    `materials/<its file name>` (`materials/2/...` for the ones from a second folder, `materials/3/...` for a third: each folder keeps its own
    pictures) - and the include_material line is rewritten to the name it has there (a path with `..` or a drive cannot be an entry name, and
    would point at nothing on the machine that opens the bundle). A URL is left as it is: the engine fetches it again. Each
    material brings its pictures, next to it: for the one the export wrote, those of `sources` ({file name: path}); for another, the file with
    that name beside the .pbdmat or in one of `texture_dirs` (the engine looks in the same two kinds of place). An include that cannot be
    found, or a picture, is left out and said - the bundle is still made.

    An include path is looked for beside the stage, then in `reference_dir` (the folder the export wrote its relative paths for: where the person
    chose to save the bundle), then in `blend_dir` (the folder of the .blend: where a path typed by hand was most likely meant from)."""
    stage_dir = os.path.dirname(os.path.abspath(staged_pbd))
    staged_mat = os.path.splitext(os.path.abspath(staged_pbd))[0] + ".pbdmat"
    files = {}
    owner = {}          # the name in lower case (a disk that does not tell a from A would write one over the other) -> its source
    notes = []
    arc_of = {}         # a material's source, normalised -> its name in the bundle
    folder_arc = {}     # the folder a material comes from, normalised -> its folder in the bundle

    def claim(name, source):
        problem = entry_name_problem(name)
        if problem:
            notes.append(f"'{safety.printable(name)}' cannot be put in the bundle: {problem}")
            return False
        known = owner.get(name.lower())
        if known is not None:
            if _same_file(known, source):
                return True
            notes.append(f"'{safety.printable(name)}' is already in the bundle, from {safety.printable(known)}: {safety.printable(source)} was not added")
            return False
        owner[name.lower()] = source
        files[name] = source
        return True

    def find_include(value):
        for base in (stage_dir, reference_dir, blend_dir):
            if base:
                candidate = os.path.normpath(os.path.join(base, value))
                if os.path.isfile(candidate):
                    return candidate
        return None

    def material_name(source):
        if _same_file(source, staged_mat):
            return os.path.basename(staged_mat)
        # one folder of the bundle for each folder the materials come from: a picture is looked for beside its material, so two materials from
        # different folders keep their own pictures even when those have one name (materials/wood.png in each would be one file)
        folder = os.path.normcase(os.path.dirname(os.path.abspath(source)))
        if folder not in folder_arc:
            folder_arc[folder] = "materials" if not folder_arc else f"materials/{len(folder_arc) + 1}"
        return f"{folder_arc[folder]}/{os.path.basename(source)}"

    def bring_pictures(material_source, material_arc):
        try:
            names = picture_names(safety.read_text_capped(material_source))
        except (OSError, ValueError, UnicodeDecodeError) as e:
            notes.append(f"'{safety.printable(os.path.basename(material_source))}' cannot be read ({safety.printable(str(e))}): its pictures are not in the bundle")
            return
        for name in names:
            found = sources.get(name) if _same_file(material_source, staged_mat) else None
            if found is None or not os.path.isfile(found):
                found = None
                for folder in (os.path.dirname(os.path.abspath(material_source)), *texture_dirs):
                    candidate = os.path.normpath(os.path.join(folder, name))
                    if os.path.isfile(candidate):
                        found = candidate
                        break
            if found is None:
                notes.append(f"the picture '{safety.printable(name)}' of '{safety.printable(os.path.basename(material_source))}' is not there: it is not in the bundle")
                continue
            claim(posixpath.normpath(posixpath.join(posixpath.dirname(material_arc), name.replace("\\", "/"))), found)

    def rewrite(match):
        value = match.group(1) if match.group(1) is not None else match.group(2)
        if _is_url(value):
            return match.group(0)
        source = find_include(value)
        if source is None:
            notes.append(f"include_material '{safety.printable(value)}' is not a file that can be found: it is not in the bundle (the line is kept as it is)")
            return match.group(0)
        key = os.path.normcase(source)
        if key not in arc_of:
            arc = material_name(source)
            if not claim(arc, source):
                return match.group(0)
            arc_of[key] = arc
            bring_pictures(source, arc)
        return "include_material " + quote_word(arc_of[key])

    return _INCLUDE_LINE.sub(rewrite, text), files, notes


def write_pbdasset(path, scene_text, files, manifest=""):
    """Writes the .pbdasset: manifest.txt, scene.pbd, then each of `files` ({name in the bundle: file to take it from}), in that order. The names,
    the number of entries and their sizes are checked against what the engine accepts when it opens a bundle (PbdLimits) before the first byte is
    written: a bundle it would refuse is not made. Returns the names of the entries, in the order they are in the bundle."""
    scene = scene_text.encode("utf-8")
    head = manifest.encode("utf-8")
    if 2 + len(files) > safety.MAX_ASSET_ENTRIES:
        raise safety.Refused(f"the bundle would hold {2 + len(files)} files: the engine opens at most {safety.MAX_ASSET_ENTRIES}")
    seen = set()
    for name, source in files.items():
        problem = entry_name_problem(name)
        if problem:
            raise safety.Refused(f"'{safety.printable(name)}' cannot be put in a bundle: {problem}")
        if name.lower() in seen:
            raise safety.Refused(f"'{safety.printable(name)}' is in the bundle twice (names are compared without regard to case: one disk would write one over the other)")
        seen.add(name.lower())
        if not os.path.isfile(source):
            raise safety.Refused(f"'{safety.printable(source)}' is not a file: it cannot be put in the bundle as '{safety.printable(name)}'")
    sizes = {"manifest.txt": len(head), "scene.pbd": len(scene)}
    sizes.update({name: os.path.getsize(source) for name, source in files.items()})
    for name, size in sizes.items():
        if size > safety.MAX_ASSET_ENTRY_BYTES:
            raise safety.Refused(f"'{safety.printable(name)}' is {safety.describe(size)}: the engine opens no file of more than {safety.describe(safety.MAX_ASSET_ENTRY_BYTES)} in a bundle")
    if sum(sizes.values()) > safety.MAX_ASSET_TOTAL_BYTES:
        raise safety.Refused(f"the bundle would hold {safety.describe(sum(sizes.values()))}: the engine opens no bundle of more than {safety.describe(safety.MAX_ASSET_TOTAL_BYTES)}")

    path = os.path.abspath(path)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    part = f"{path}.{os.getpid()}.part"

    def info(name):
        entry = zipfile.ZipInfo(name, date_time=_ENTRY_TIME)
        entry.compress_type = zipfile.ZIP_DEFLATED
        entry.external_attr = 0o644 << 16
        return entry

    try:
        with zipfile.ZipFile(part, "w") as archive:
            archive.writestr(info("manifest.txt"), head)
            archive.writestr(info("scene.pbd"), scene)
            for name, source in files.items():
                with open(source, "rb") as src, archive.open(info(name), "w") as out:
                    while True:
                        chunk = src.read(64 * 1024)
                        if not chunk:
                            break
                        out.write(chunk)
        os.replace(part, path)
    except BaseException:
        try:
            os.remove(part)
        except OSError:
            pass
        raise
    return ["manifest.txt", "scene.pbd", *files]
