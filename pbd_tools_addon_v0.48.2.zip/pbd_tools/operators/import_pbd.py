"""
Imports a .pbd file (and its include_material .pbdmat, if any) into the
current Blender scene, reconstructing objects with the right type,
transform, material, modifiers, keyframes, and PBD-specific flags
(metadata, linkGroup) - the inverse of export_pbd.py.

The text parser below is a small hand-rolled recursive-descent reader
matching PbdParser.java's own grammar (see that file for the
authoritative spec) - not a wrapper around it, since this runs inside
Blender's own Python with no JVM available. Kept deliberately close to
the Java parser's structure (same field names, same block shapes) so the
two stay easy to compare and keep in sync by hand if the format changes.
"""

import math
import os
import shutil
import tempfile

import bmesh
import bpy
import mathutils

from .. import anim_compat
from .. import safety
from . import export_pbd  # for _BLENDER_TO_SHADER_SCALE and _to_pbd_matrix - see below
from .. import materials as materials_module
from .. import mesh_preview  # for _pbd_to_blender - mesh vertex data needs the same axis remap as everything else
from ..fetcher import PBD_SITE_HOST


# ---------------------------------------------------------------------
# Tokenizing / low-level parsing helpers
# ---------------------------------------------------------------------

class ParseError(Exception):
    pass


class _Reader:
    """Character-index cursor over the whole file text, mirroring
    PbdParser.java's own reader style (skip whitespace/comments, read an
    identifier, expect a specific character) rather than a line-oriented
    approach - this format nests braces and puts multiple fields on one
    line freely, so a line-by-line reader would need most of the same
    logic anyway."""

    def __init__(self, text):
        self.text = text
        self.pos = 0

    def peek(self):
        self._skip_ws()
        return self.text[self.pos] if self.pos < len(self.text) else ''

    def _skip_ws(self):
        while self.pos < len(self.text):
            c = self.text[self.pos]
            if c in ' \t\r\n':
                self.pos += 1
            elif c == '#':
                nl = self.text.find('\n', self.pos)
                self.pos = len(self.text) if nl == -1 else nl + 1
            elif self.text.startswith('//', self.pos):
                nl = self.text.find('\n', self.pos)
                self.pos = len(self.text) if nl == -1 else nl + 1
            else:
                break

    def at_end(self):
        self._skip_ws()
        return self.pos >= len(self.text)

    def expect(self, ch):
        self._skip_ws()
        if self.pos >= len(self.text) or self.text[self.pos] != ch:
            got = self.text[self.pos:self.pos + 20] if self.pos < len(self.text) else '<EOF>'
            raise ParseError(f"Expected '{ch}' at position {self.pos}, got: {got!r}")
        self.pos += 1

    def read_identifier(self):
        """A run of characters up to a space or one of { } ( ) [ ] = , - the
        engine's own rule (PbdParser.readIdentifier). It used to take only
        letters, digits, `_` and `.`, so a file whose ids hold anything else
        (wall-left, a:b, x/y - the engine reads them all) could not be
        opened in Blender."""
        self._skip_ws()
        start = self.pos
        while self.pos < len(self.text) and not self.text[self.pos].isspace() and self.text[self.pos] not in '{}()[]=,':
            self.pos += 1
        if start == self.pos:
            raise ParseError(f"Expected identifier at position {self.pos}, got: {self.text[self.pos:self.pos+20]!r}")
        return self.text[start:self.pos]

    def read_raw_value(self):
        """A quoted string, a (a,b,c)/[a,b,c] tuple, or a bare word/number
        - read up to (but not past) the next unescaped comma or closing
        brace at THIS nesting level. Mirrors PbdParser.readRawValue: the
        exact delimiter set matters (comma is a value separator inside a
        modifier/keyframe block's single line, e.g. 'axis=x angle=30' has
        no commas at all, but 'pos=(1,2,3)' does inside the parens)."""
        self._skip_ws()
        start = self.pos
        if self.pos < len(self.text) and self.text[self.pos] == '"':
            self.pos += 1
            s = self.pos
            while self.pos < len(self.text) and self.text[self.pos] != '"':
                self.pos += 1
            value = self.text[s:self.pos]
            self.pos += 1  # closing quote
            return value
        depth = 0
        while self.pos < len(self.text):
            c = self.text[self.pos]
            if c in '([':
                depth += 1
            elif c in ')]':
                depth -= 1
            elif c == '}' and depth <= 0:
                break
            elif c in ' \t\r\n' and depth <= 0:
                # a bare word ends at whitespace UNLESS we're still inside
                # a tuple's parens (spaces after commas are common: "(1, 2, 3)")
                break
            self.pos += 1
        return self.text[start:self.pos].strip()

    def read_metadata_value(self):
        """Same quoted-string handling as read_raw_value (delegated to
        it directly for that case), but an UNQUOTED value reads to the
        end of the LINE rather than stopping at the first whitespace -
        the exact same fix PbdParser.java's own readMetadataValue
        needed, for the exact same reason: name=/kind=/author=/origin=/
        description= are free-form text, not a single token the way
        mat=/a numeric field/etc. are, so a naturally-multi-word,
        unquoted value like `kind = interior electric decoration`
        mustn't stop at "interior" alone - which is exactly what using
        read_raw_value for these fields used to do, leaving "electric"
        (or worse, "author" itself once one of these fields sat right
        before an author= line - the actual reported crash this fixes)
        sitting at the top level where this reader would then try, and
        fail, to parse it as a whole new TYPE NAME { ... } block."""
        self._skip_ws()
        if self.pos < len(self.text) and self.text[self.pos] == '"':
            return self.read_raw_value()
        start = self.pos
        while self.pos < len(self.text) and self.text[self.pos] not in '\n#':
            self.pos += 1
        return self.text[start:self.pos].strip()


def _apply_removed_faces(pbd_props, raw):
    """Inverse of export_pbd.py's _removed_face_codes: raw is the faces=
    value, e.g. '(-y,+z)' - strip the parens, split on comma, and
    uncheck whichever Blender-labeled boolean corresponds to each
    canonical PBD code (same index table as export, just written the
    other direction: canonical -> Blender rather than Blender -> canonical).
    Unrecognized codes are ignored with a print rather than raising, so a
    hand-edited file with a typo doesn't block the whole import."""
    inner = raw.strip()
    if inner.startswith('(') and inner.endswith(')'):
        inner = inner[1:-1]
    code_to_blender_attr = {
        '+x': 'pbd_cube_face_posx', '-x': 'pbd_cube_face_negx',
        '+y': 'pbd_cube_face_posz', '-y': 'pbd_cube_face_negz',
        '+z': 'pbd_cube_face_negy', '-z': 'pbd_cube_face_posy',
    }
    for token in inner.split(','):
        code = token.strip().lower()
        if not code:
            continue
        attr = code_to_blender_attr.get(code)
        if attr is None:
            print(f"[import_pbd] Unknown face code '{code}' in faces={raw!r} - skipped")
            continue
        setattr(pbd_props, attr, False)


def _smooth_number(raw, fallback):
    """One roundness value of a cube as the engine reads it (pbd.format.PrimitiveParts#cubeSmoothness): the number in `raw`, held to
    0 (sharp) .. 0.5 (fully round); a missing value, one that is not a number and one that is not finite all give `fallback`."""
    if raw is None:
        return fallback
    try:
        value = float(str(raw).strip())
    except ValueError:
        return fallback
    if not math.isfinite(value):
        return fallback
    return min(max(value, 0.0), 0.5)


def cube_smoothness_from_fields(fields):
    """(smoothX, smoothY, smoothZ) of a cube instance's fields, or None when the instance gives no roundness at all. The engine's rule:
    each axis has its own `smoothX` / `smoothY` / `smoothZ`, and an axis without one takes the uniform `smooth` (0 when there is none
    either). A file may say only `smooth = 0.2` - the importer used to read the per-axis keys alone and so brought such a cube in
    sharp-edged."""
    if not any(key in fields for key in ('smooth', 'smoothX', 'smoothY', 'smoothZ')):
        return None
    base = _smooth_number(fields.get('smooth'), 0.0)
    return tuple(_smooth_number(fields.get(f'smooth{axis}'), base) for axis in ('X', 'Y', 'Z'))


def _parse_vec3(raw):
    inner = raw.strip()
    if inner.startswith('(') and inner.endswith(')'):
        inner = inner[1:-1]
    parts = [p.strip() for p in inner.split(',')]
    return tuple(float(p) for p in parts)


# ---------------------------------------------------------------------
# Top-level .pbd parsing
# ---------------------------------------------------------------------

def _decompress_pbdbin(pbdbin_path):
    """Inverse of PbdBinFormat.java's write(): 4-byte 'PBDB' magic + 1
    version byte, then gzip-compressed minified .pbd text. Returns
    (decompressed_pbd_path, warning_or_None).

    Writes the decompressed text to a temp .pbd file NEXT TO the
    original .pbdbin (not an unrelated system temp directory) - that
    placement is what actually matters here, not just a detail: a
    relative include_material= inside the decompressed text resolves
    against wherever THIS file lands, so writing it anywhere other than
    beside the original .pbdbin (where the referenced .pbdmat actually
    lives) silently breaks materials, exactly the same bug the Java side
    had before PbdBinFormat.read() was fixed to pass a real baseDir -
    caught here by actually running this against a real materials-
    referencing .pbdbin rather than assuming the same fix pattern
    carried over automatically. Named after the ORIGINAL .pbdbin (not a
    random temp suffix) so a multi-top-level-instance import's grouping
    root (see import_pbd_file's own doc) gets a sensible name instead of
    an opaque temp filename. Falls back to a real system temp directory
    (with a warning) if the original's directory isn't writable - a
    shared/distributed read-only asset, say - which still imports the
    instances themselves, just without a relative include_material=
    resolving correctly. Caller is responsible for deleting the
    returned path once import is done, if leaving it around isn't
    wanted - not deleted here, since deleting SOMETHING'S source-of-
    truth file while import_pbd_file might still be about to re-read it
    (materials in particular) would be its own bug."""
    label = f"'{os.path.basename(pbdbin_path)}'"
    data = safety.read_file_capped(pbdbin_path, safety.MAX_FETCH_BYTES, label)       # the size is looked at before a byte is read
    if len(data) < 5 or data[:4] != b'PBDB':
        raise ValueError("missing PBDB magic header - not a .pbdbin file")
    version = data[4]
    if version != 1:
        raise ValueError(f".pbdbin version {version} is not supported (this reader only knows version 1)")
    # a few kilobytes can inflate to gigabytes: the decompressor is told how much it may produce BEFORE it starts
    text = safety.gunzip_capped(data[5:], safety.MAX_DECOMPRESSED_BYTES, label).decode('utf-8')
    base = os.path.splitext(os.path.basename(pbdbin_path))[0]
    sibling_path = os.path.join(os.path.dirname(os.path.abspath(pbdbin_path)), f".{base}_decompressed.pbd")
    try:
        with open(sibling_path, 'w', encoding='utf-8') as f:
            f.write(text)
        return sibling_path, None
    except OSError:
        # Read-only location (a shared/distributed asset, say) - falls
        # back to a system temp dir, which WILL break a relative
        # include_material= (nothing to be done about that without write
        # access next to the original), but at least still imports the
        # instances themselves rather than failing outright.
        fd, tmp_path = tempfile.mkstemp(suffix='.pbd', prefix=f'{base}_decompressed_')
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            f.write(text)
        return tmp_path, (f"Could not write next to {pbdbin_path} (read-only?) - used a temp "
                           f"location instead, so a relative include_material= inside it won't "
                           f"resolve correctly")


DEFAULT_PBD_DOMAIN = PBD_SITE_HOST


def _resolve_to_local_file(source, base_dir, context, trusted_path=False, budget=None):
    """The URL/local/default-domain-fallback resolution half of
    _resolve_pbd_source below, split out on its own since a .pbdmat
    reference (include_material=) needs exactly this same resolution
    but never the .pbdasset/.pbdbin unwrapping that follows it for a
    .pbd - a .pbdmat is always plain text, there's no compressed/
    bundled form of it to detect. Returns a real local file path -
    raises on a hard failure (404, no such local file and no default-
    domain match either), same as _resolve_pbd_source's own contract.

    ``source`` is, unless ``trusted_path`` says the person chose it in a file dialog, a name WRITTEN IN A SCENE by someone the person
    does not know: it is read as a file only when it is a file (not a network path - Windows would offer the person's credentials
    to that host -, not an address of another kind, not an alternate data stream) and, inside an unpacked bundle, only when it stays
    in the bundle. ``budget`` (safety.ImportBudget) counts the files one import opens."""
    if budget is not None:
        budget.open_file(source)
    is_url = source.startswith('http://') or source.startswith('https://')
    if is_url:
        from .. import fetcher
        cache_dir = _shared_remote_cache_dir(context)
        return fetcher.fetch(source, cache_dir, None, use_cache=True)
    if not trusted_path:
        reason = safety.refuse_local_reference(source)
        if reason:
            raise safety.Refused(f"reference '{safety.printable(source)}': {reason}")
    candidate = os.path.join(base_dir, source) if base_dir else source
    root = safety.bundle_root_of(base_dir) if (base_dir and not trusted_path) else None
    if root is not None and not safety.is_within(root, candidate):
        raise safety.Refused(f"reference '{safety.printable(source)}' leaves the bundle it is part of - refused")
    if os.path.isfile(candidate):
        return candidate
    # Not found locally - retry against this project's own default
    # host before giving up. A bare filename with nothing found
    # locally is exactly what an external resource with no domain of
    # its own written into it looks like.
    from .. import fetcher
    cache_dir = _shared_remote_cache_dir(context)
    fallback_url = f"https://{DEFAULT_PBD_DOMAIN}/{source.lstrip('/')}"
    return fetcher.fetch(fallback_url, cache_dir, None, use_cache=True)


def _resolve_pbd_source(source, base_dir, context, trusted_path=False, budget=None):
    """source= from a pbd_ref, or an include_material target, or
    whatever the main import dialog's own URL/file field held - turns
    it into a real, LOCAL, PLAIN-TEXT .pbd file ready for
    parse_pbd_file(), regardless of which of these it started as:
      - an http(s):// URL - fetched via the shared fetcher module.
      - a local path that exists relative to base_dir - used directly.
      - a local-LOOKING path that does NOT exist relative to base_dir -
        retried as https://{DEFAULT_PBD_DOMAIN}/{source} before giving
        up. A bare filename with nothing found locally is exactly what
        an external resource with no domain of its own written into it
        looks like - source= on a shared/community asset is written as
        a bare name when the author expects it to live on THIS
        project's own default server, same as include_material's own
        texture= fields already assume relative to wherever the
        .pbdmat itself is; this is the same assumption one level up,
        for a source= this project's own default host never got
        spelled out on.
    Then, whichever of the three it resolved to, detects and unwraps
    .pbdasset (zip)/.pbdbin (gzip) the exact same way the top-level
    import operator's own execute() already did inline - extracted
    here specifically so this ONE resolution path is shared by BOTH
    that top-level operator and the NEW pbd_ref-recursion below,
    rather than the .pbdasset/.pbdbin handling existing in only one of
    the two places, which is exactly how "PBDBIN don't carry their own
    materials in Blender" and "a directly re-fetched reference doesn't
    resolve" both actually happened: the top-level operator's own
    fetch+format-detection was never reachable from anywhere else.

    Returns (local_pbd_text_path, sub_base_dir, warning_or_None) - the
    plain-text .pbd ready to hand to parse_pbd_file, the directory any
    of ITS OWN relative references (include_material, a nested
    pbd_ref) should resolve against, and a warning string (or None) to
    surface via self.report if resolution partly failed but didn't
    raise. Raises OSError/ValueError on a hard failure (a 404, a
    corrupt zip, ...) - the caller decides whether that should abort
    the whole import or just this one reference.

    ``trusted_path`` and ``budget``: see _resolve_to_local_file. A bundle (.pbdasset) is unpacked entry by entry under the engine's own
    rules (safety.unpack_asset): a name that is not a plain relative path, too many entries, too many bytes - the whole bundle is refused."""
    is_url = source.startswith('http://') or source.startswith('https://')
    local_path = _resolve_to_local_file(source, base_dir, context, trusted_path=trusted_path, budget=budget)

    warning = None
    lower = local_path.lower()
    if lower.endswith('.pbdasset'):
        extract_dir = tempfile.mkdtemp(prefix="pbdasset_")
        safety.register_bundle_root(extract_dir)          # what is in it may refer to what is in it, and to nothing outside
        try:
            safety.unpack_asset(local_path, extract_dir)
            scene_pbd = os.path.join(extract_dir, "scene.pbd")
            if not os.path.isfile(scene_pbd):
                raise ValueError(f"'{safety.printable(source)}' has no scene.pbd entry - not a valid .pbdasset")
        except BaseException:
            # a bundle that is refused leaves nothing behind: not its files, and not a folder that would stay a trusted root
            safety.forget_bundle_root(extract_dir)
            shutil.rmtree(extract_dir, ignore_errors=True)
            raise
        # The EXTRACTED bundle's own directory, not base_dir - a
        # .pbdasset bundles its materials/textures alongside scene.pbd
        # INSIDE the zip (see PbdAssetFormat.java's own doc), so a
        # relative include_material inside it needs to resolve against
        # where those landed, not wherever the .pbdasset file itself
        # came from.
        return scene_pbd, extract_dir, warning
    elif lower.endswith('.pbdbin'):
        decompressed_path, warning = _decompress_pbdbin(local_path)
        return decompressed_path, os.path.dirname(decompressed_path), warning
    else:
        return local_path, (os.path.dirname(local_path) if not is_url else None), warning


def parse_pbd_file(filepath):
    """Returns (scene_meta_dict, include_material_filename_or_None,
    [instance_dict, ...]). scene_meta_dict has whichever of
    name/kind/authors(list)/origin were present - mirrors PbdParser.java's
    own top-level loop, which special-cases these exactly the same way
    (expects "=" then a value) rather than treating them as the start of
    a "TYPE NAME {" instance block the way every other top-level keyword
    is. Missing this case here specifically would have made this
    Python-side reader crash on any file this add-on's OWN exporter now
    writes, the moment scene-level metadata was added on the export side
    without a matching update here.

    scene_meta_dict also has 'include_materials': every include_material
    line in file order (the second return value is only the last).

    Each instance dict has: type, id, fields (plain key->raw-string map),
    modifiers (list of {type, params}), keyframes (list of {time, pos, rot,
    and scale/channel/sound when present}), containerTriggers (list of
    ids) and leverArm (None, or the dict _lever_arm_from_fields builds)."""
    # the size is looked at before a byte is read; the line ends are read as open(..., 'r') always did
    text = safety.read_text_capped(filepath).replace('\r\n', '\n').replace('\r', '\n')
    reader = _Reader(text)
    scene_meta = {}
    include_material = None
    instances = []

    while not reader.at_end():
        keyword = reader.read_identifier()
        if keyword == 'pbd_version':
            reader.read_raw_value()
            continue
        if keyword == 'include_material':
            include_material = reader.read_raw_value().strip('"')
            # include_material= above keeps only the LAST one (what the
            # importer has always used); an embed (export_pbd's
            # _serialize_embedded_ref) needs all of them, in file order.
            scene_meta.setdefault('include_materials', []).append(include_material)
            continue
        if keyword == 'name':
            reader.expect('=')
            scene_meta['name'] = reader.read_metadata_value().strip('"')
            continue
        if keyword == 'kind':
            reader.expect('=')
            scene_meta['kind'] = reader.read_metadata_value().strip('"')
            continue
        if keyword == 'author':
            reader.expect('=')
            scene_meta.setdefault('authors', []).append(reader.read_metadata_value().strip('"'))
            continue
        if keyword == 'origin':
            reader.expect('=')
            scene_meta['origin'] = reader.read_metadata_value().strip('"')
            continue
        if keyword == 'description':
            reader.expect('=')
            scene_meta['description'] = reader.read_metadata_value().strip('"')
            continue
        # Otherwise: TYPE NAME { ... } - covers every primitive type and pbd_ref
        prim_type = keyword
        name = reader.read_identifier()
        inst = _parse_instance_body(reader, prim_type, name)
        instances.append(inst)

    return scene_meta, include_material, instances


def _parse_instance_body(reader, prim_type, name):
    inst = {'type': prim_type, 'id': name, 'fields': {}, 'modifiers': [], 'keyframes': [], 'containerTriggers': [], 'leverArm': None}
    reader.expect('{')
    while reader.peek() != '}':
        key = reader.read_identifier()
        reader.expect('=') if reader.peek() == '=' else None
        # Some blocks (keyframe, leverArm) use bare "key { ... }" with no
        # '=' before the brace - check for that before assuming a value
        # follows. "modifier" doesn't hit this case: its grammar is
        # "modifier TYPE { ... }" (a type word always comes between the
        # keyword and the brace), so it falls through to the raw-value
        # read below like any other field, with "modifier" handled
        # specially there once its raw value (the type word) is known.
        if reader.peek() == '{':
            body = _read_brace_block_fields(reader)
            if key == 'keyframe':
                inst['keyframes'].append(_keyframe_from_fields(body))
            elif key == 'leverArm':
                inst['leverArm'] = _lever_arm_from_fields(body)
            continue
        raw = reader.read_raw_value()
        if key == 'modifier':
            # raw is actually the modifier's type word (e.g. "bend"),
            # read immediately before its own '{' - re-read properly:
            mod_type = raw
            reader.expect('{')
            params = {}
            while reader.peek() != '}':
                pkey = reader.read_identifier()
                reader.expect('=')
                params[pkey] = reader.read_raw_value()
                if reader.peek() == ',':
                    reader.pos += 1
            reader.expect('}')
            inst['modifiers'].append({'type': mod_type, 'params': params})
            continue
        if key == 'containerTrigger':
            inst['containerTriggers'].append(raw)
        else:
            inst['fields'][key] = raw
        if reader.peek() == ',':
            reader.pos += 1
    reader.expect('}')
    return inst


def _read_brace_block_fields(reader):
    reader.expect('{')
    fields = {}
    while reader.peek() != '}':
        key = reader.read_identifier()
        reader.expect('=')
        fields[key] = reader.read_raw_value()
        if reader.peek() == ',':
            reader.pos += 1
    reader.expect('}')
    return fields


def _keyframe_from_fields(fields):
    kf = {'time': float(fields.get('time', 0.0))}
    if 'pos' in fields:
        kf['pos'] = _parse_vec3(fields['pos'])
    if 'rot' in fields:
        kf['rot'] = _parse_vec3(fields['rot'])
    if 'scale' in fields:
        kf['scale'] = _parse_vec3(fields['scale'])
    if 'channel' in fields:
        kf['channel'] = fields['channel']
    if 'sound' in fields:
        kf['sound'] = fields['sound']
    return kf


def _lever_arm_from_fields(fields):
    """Mirrors _keyframe_from_fields just above, for a leverArm { } block
    (see PbdInstance.LeverArm on the engine side) instead of a keyframe
    one - openPos/openRot are independently optional, same null-means-
    "fall back to this instance's own base pos/rot" convention as a
    keyframe's own pos/rot fields."""
    arm = {'speed': float(fields.get('speed', 1.0))}
    if 'openPos' in fields:
        arm['openPos'] = _parse_vec3(fields['openPos'])
    if 'openRot' in fields:
        arm['openRot'] = _parse_vec3(fields['openRot'])
    # What letting go of a held arm does, whether it starts bolted shut,
    # and its two sounds - see PbdParser.parseLeverArm for the grammar
    # these mirror. A value this reader does not know is ignored rather
    # than fatal (the engine is the strict one); the defaults are what the
    # engine would use too.
    if fields.get('release') in ('snap', 'free'):
        arm['release'] = fields['release']
    if fields.get('locked') in ('true', 'false'):
        arm['locked'] = fields['locked'] == 'true'
    if 'lockAt' in fields:
        try:
            arm['lockAt'] = min(1.0, max(0.0, float(fields['lockAt'])))
        except ValueError:
            pass
    if fields.get('openSound'):
        arm['openSound'] = fields['openSound']
    if fields.get('closeSound'):
        arm['closeSound'] = fields['closeSound']
    return arm


# ---------------------------------------------------------------------
# PBD -> Blender axis conversion (inverse of export_pbd._to_pbd_matrix)
# ---------------------------------------------------------------------

def _to_blender_matrix(pbd_matrix):
    """Inverse of export_pbd._to_pbd_matrix - same axis-conversion
    matrix, applied on the opposite side. _to_pbd_matrix computes
    AXIS @ blender_matrix @ AXIS_INV; undoing that is AXIS_INV @
    pbd_matrix @ AXIS, i.e. swap which side AXIS and AXIS_INV go on. Not
    re-derived by hand here on purpose - see this project's own history
    of getting rotation axis conversions wrong when reasoned out fresh
    under time pressure; reusing the one place that conversion is
    already proven is the safer move."""
    axis = export_pbd._AXIS_CONVERSION
    axis_inv = axis.inverted()
    return axis_inv @ pbd_matrix @ axis


def _decode_mesh_data(raw_vertex_data, name):
    """Inverse of export_pbd.py's _export_mesh_vertex_data - decodes the
    same binary layout pbd.format.PbdMeshData uses (int32 vertexCount,
    int32 indexCount, per-vertex float32 x,y,z,nx,ny,nz,u,v, per-index
    int32, little-endian) and builds a real Blender Mesh DATABLOCK from
    it (not yet an Object - see _create_mesh_object_from_field below for
    the base/LOD-0 case, which wraps one in an Object; an LOD variant
    stays a bare datablock, never linked to any Object at all, matching
    how Capture/Apply store one on PbdMeshLodEntry). Indices come in
    groups of 3 (one per triangle corner, matching the export side's "no
    vertex sharing" choice), so reconstruction is a straight triangle
    fan, no face-merging needed."""
    import struct, base64
    if raw_vertex_data is None:
        raise ParseError(f"'mesh' instance '{name}' has no vertexData= field")
    encoded = raw_vertex_data[len('base64:'):] if raw_vertex_data.startswith('base64:') else raw_vertex_data
    buf = base64.b64decode(encoded)
    vertex_count, index_count = struct.unpack_from('<ii', buf, 0)
    offset = 8
    positions, normals, uvs = [], [], []
    for _ in range(vertex_count):
        x, y, z, nx, ny, nz, u, v = struct.unpack_from('<8f', buf, offset)
        offset += 32
        positions.append(mesh_preview._pbd_to_blender((x, y, z)))
        normals.append(mesh_preview._pbd_to_blender((nx, ny, nz)))
        uvs.append((u, v))
    indices = list(struct.unpack_from(f'<{index_count}i', buf, offset))

    bm = bmesh.new()
    bm_verts = [bm.verts.new(p) for p in positions]
    bm.verts.ensure_lookup_table()
    uv_layer = bm.loops.layers.uv.new("UVMap")
    for i in range(0, len(indices), 3):
        tri = indices[i:i + 3]
        try:
            face = bm.faces.new([bm_verts[j] for j in tri])
        except ValueError:
            continue  # degenerate/duplicate triangle - skip rather than fail the whole import
        for loop, vi in zip(face.loops, tri):
            loop[uv_layer].uv = uvs[vi]
    bm.normal_update()

    mesh = bpy.data.meshes.new(name + "_mesh")
    bm.to_mesh(mesh)
    bm.free()
    return mesh


def _create_mesh_object_from_field(raw_vertex_data, name):
    """The base/LOD-0 case: decodes and wraps the result in a real,
    linked, visible Object - unlike an LOD variant's mesh (see
    _decode_mesh_data), which stays an unlinked datablock forever."""
    mesh = _decode_mesh_data(raw_vertex_data, name)
    obj = bpy.data.objects.new(name, mesh)
    bpy.context.collection.objects.link(obj)
    bpy.context.view_layer.objects.active = obj
    for o in bpy.context.selected_objects:
        o.select_set(False)
    obj.select_set(True)
    return obj


def _pbd_transform_to_blender(pos, rot_deg, scale, apply_native_scale=True, parent_factor=1.0):
    """pos/rot_deg/scale as parsed from the .pbd text (PBD space) ->
    (blender_location, blender_euler, blender_scale). Builds the full
    TRS matrix in PBD space and decomposes the conjugated result for all
    three at once - mirroring _serialize_instance's own
    pbd_matrix.decompose() on the export side exactly. Scale can't be
    converted as 3 independent numbers the way position's axis remap
    works: it's expressed along the object's OWN rotated local axes, so
    it has to go through the same rotation-aware conjugation as
    position/rotation, not a separate per-component pass - the first
    version of this function did that and silently swapped Y/Z scale on
    any object with a non-trivial rotation, caught by round-tripping a
    rotated test object rather than only checking axis-aligned ones.

    apply_native_scale=False for 'mesh'/'ref'/'group'/'light' instances,
    whose export side never multiplied by _BLENDER_TO_SHADER_SCALE in the
    first place (export_pbd._shape_factor) - halving it back here
    regardless of type would shrink an imported mesh to half its real
    size.

    parent_factor is export_pbd._shape_factor of the instance's PARENT:
    what the file stores is relative to a parent whose own x2 the engine
    composes in, and Blender's is not (see export_pbd._factors), so the
    stored position is multiplied by it and the stored scale by
    parent_factor / own factor on the way back. 1 for a root, or a child
    of a pivot, a reference or a mesh."""
    rx, ry, rz = (math.radians(a) for a in rot_deg)
    rot_matrix = (mathutils.Matrix.Rotation(rz, 4, 'Z')
                  @ mathutils.Matrix.Rotation(ry, 4, 'Y')
                  @ mathutils.Matrix.Rotation(rx, 4, 'X'))
    own_factor = export_pbd._BLENDER_TO_SHADER_SCALE if apply_native_scale else 1.0
    ratio = parent_factor / own_factor
    scale_matrix = mathutils.Matrix.Diagonal((scale[0] * ratio, scale[1] * ratio, scale[2] * ratio, 1.0))
    pbd_matrix = (mathutils.Matrix.Translation(mathutils.Vector(pos) * parent_factor)
                  @ rot_matrix @ scale_matrix)
    blender_matrix = _to_blender_matrix(pbd_matrix)
    loc, rot_quat, blender_scale = blender_matrix.decompose()
    return loc, rot_quat.to_euler('XYZ'), blender_scale


# ---------------------------------------------------------------------
# Scene reconstruction
# ---------------------------------------------------------------------

_CAP_TYPES = {'cylinder', 'cone'}


def _create_object_for_instance(inst, base_dir, parent_factor=1.0):
    """parent_factor: export_pbd._shape_factor of this instance's parent in
    the file (1 for a root) - see _pbd_transform_to_blender."""
    prim_type = inst['type']
    fields = inst['fields']
    name = inst['id']

    if prim_type == 'group' and 'source' not in fields:
        # A plain `group`: the engine's zero-geometry transform node - a
        # door's hinge, say - which a Java re-save of a scene writes for
        # every pbd_ref it has resolved too, but those carry a source=
        # (handled just below). Without one it is NOT a reference: it
        # becomes a Pivot (object.add_pbd_group), keeping its lever arm
        # and keyframes, instead of the empty source-less reference it was
        # imported as before - which re-exported as `pbd_ref NAME {
        # source = }` and lost the hinge.
        bpy.ops.object.add_pbd_group()
        obj = bpy.context.active_object
        obj.pbd.pbd_type = 'group'
    elif prim_type in ('group', 'pbd_ref'):
        # 'pbd_ref' is the ACTUAL keyword any real file (Blender's own
        # export included - it never resolves a reference, just writes
        # it as-is) contains; 'group' is what the JAVA parser produces
        # internally ONLY after resolving one, never written to a file
        # by any serializer - this check used to only recognize 'group',
        # meaning it never matched a single real file, only ever an
        # in-memory Java structure this Python reader never receives.
        # Confirmed via a real reported failure: "Unknown primitive type
        # 'pbd_ref'".
        bpy.ops.object.add_pbd_ref()  # the DEDICATED ref-creation operator - add_pbd_primitive's own prim_type enum only lists procedural shapes (plane/sphere/.../torus), calling it with prim_type='ref' throws
        obj = bpy.context.active_object
        obj.pbd.pbd_type = 'ref'
    elif prim_type == 'light':
        bpy.ops.object.add_pbd_light()
        obj = bpy.context.active_object
        obj.pbd.pbd_type = 'light'
        if 'lightMode' in fields:
            mode = fields['lightMode'].strip()
            if mode in ('point', 'spot'):
                obj.pbd.pbd_light_mode = mode
        if 'lightEnabled' in fields:
            obj.pbd.pbd_light_enabled = fields['lightEnabled'].strip() != 'false'
        if 'switchSound' in fields:
            obj.pbd.pbd_light_switch_sound = fields['switchSound'].strip()
        if 'lightColor' in fields:
            try:
                obj.pbd.pbd_light_color = _parse_vec3(fields['lightColor'])
            except (ValueError, IndexError):
                pass  # malformed lightColor= in a hand-edited file - keep the default rather than fail the whole import
        if 'lightIntensity' in fields:
            try:
                obj.pbd.pbd_light_intensity = float(fields['lightIntensity'])
            except ValueError:
                pass
        if 'lightRange' in fields:
            try:
                obj.pbd.pbd_light_range = float(fields['lightRange'])
            except ValueError:
                pass
        if 'lightSpotAngle' in fields:
            try:
                obj.pbd.pbd_light_spot_angle = math.radians(float(fields['lightSpotAngle']))
            except ValueError:
                pass
    elif prim_type == 'mesh':
        obj = _create_mesh_object_from_field(fields.get('vertexData'), name)
        obj.pbd.is_pbd_primitive = True
        obj.pbd.pbd_type = 'mesh'
        # Reconstruct each vertexDataLod<N>= as a hidden Mesh datablock
        # stored directly on its pbd_mesh_lod_sources entry (see
        # PbdMeshLodEntry's own doc comment) - never linked to its own
        # Object/collection, so re-importing a file with LOD variants
        # doesn't fill the scene with extra visible objects the way an
        # earlier version of this (one full Object per variant) did.
        for key, raw in fields.items():
            if not key.startswith('vertexDataLod'):
                continue
            try:
                lod_n = int(key[len('vertexDataLod'):])
            except ValueError:
                continue
            lod_mesh = _decode_mesh_data(raw, f"{name}_LOD{lod_n}")
            lod_mesh.use_fake_user = True  # keeps it alive with zero Object users - that's the point, not an orphan to be purged
            entry = obj.pbd.pbd_mesh_lod_sources.add()
            entry.lod = lod_n
            entry.mesh_data = lod_mesh
    elif prim_type not in ('plane', 'sphere', 'cylinder', 'cone', 'cube', 'disc', 'torus'):
        raise ParseError(f"Unknown primitive type '{prim_type}' for instance '{name}' - "
                          "add it to both PrimitiveRegistry.java and this import module together")
    else:
        bpy.ops.object.add_pbd_primitive(prim_type=prim_type)
        obj = bpy.context.active_object

    obj.name = name

    pos = _parse_vec3(fields['pos']) if 'pos' in fields else (0.0, 0.0, 0.0)
    rot = _parse_vec3(fields['rot']) if 'rot' in fields else (0.0, 0.0, 0.0)
    scale = _parse_vec3(fields['scale']) if 'scale' in fields else (1.0, 1.0, 1.0)
    # 'mesh' and 'ref'/'group' never got the x2 _BLENDER_TO_SHADER_SCALE
    # factor applied on export (see export_pbd.py's scale_factor branch
    # and its "ref isn't a native-2x2x2-sized mesh" comment) - halving it
    # back here regardless of type used to silently shrink both to half
    # size on import, for 'ref' since this function was first written and
    # for 'mesh' it would have from the moment 'mesh' import existed.
    apply_native_scale = prim_type not in export_pbd._UNSCALED_TYPES and prim_type != 'pbd_ref'
    loc, euler, bscale = _pbd_transform_to_blender(pos, rot, scale, apply_native_scale, parent_factor)
    obj.location = loc
    obj.rotation_euler = euler
    obj.scale = bscale

    if 'mat' in fields and obj.pbd.pbd_type != 'group':
        obj.pbd.pbd_material = fields['mat']
    if 'cap' in fields and prim_type in _CAP_TYPES:
        obj.pbd.pbd_cap = fields['cap']
    if prim_type == 'cube':
        smoothness = cube_smoothness_from_fields(fields)
        if smoothness is not None:
            # (the property group's names are pbd_cube_smooth_x/y/z - 'pbd_smooth_x' does not exist and raised AttributeError once)
            for axis, value in zip('xyz', smoothness):
                setattr(obj.pbd, f'pbd_cube_smooth_{axis}', value)
        if 'faces' in fields:
            _apply_removed_faces(obj.pbd, fields['faces'])
    if prim_type in ('ref', 'pbd_ref') or (prim_type == 'group' and 'source' in fields):
        # 'pbd_ref' is what a real parsed file's prim_type actually IS
        # (the file-format keyword) - 'ref' is only ever
        # obj.pbd.pbd_type's OWN value on the Blender side, never what
        # gets compared here against a value straight out of the parser.
        # This checked only 'ref'/'group' before, meaning source=/
        # fallback=/mat= never actually got read back in for ANY real
        # file - not just the mat= override added this session, but
        # source= and fallback= too, silently, since the object still
        # got CREATED correctly (that check was already fixed
        # separately) even though none of its OWN fields underneath
        # this branch ever populated. A re-export of a re-imported file
        # would have written an empty source= - Blender's own file has
        # never exercised writing back what it just read for a ref,
        # only exercised writing what it authored itself, so nothing
        # caught this until actually asserting the reimported value
        # matches what was exported, not just that import succeeds.
        if 'source' in fields:
            obj.pbd.pbd_ref_source = fields['source'].strip('"')
        if 'fallback' in fields:
            obj.pbd.pbd_ref_fallback = fields['fallback'].strip('"')
        if 'mat' in fields:
            obj.pbd.pbd_ref_mat_override = fields['mat'].strip('"')
    if fields.get('metadata') == 'true':
        obj.pbd.pbd_metadata = True
    if 'lod' in fields:
        try:
            obj.pbd.pbd_lod = int(fields['lod'])
            obj.pbd.pbd_lod_enabled = True
        except ValueError:
            pass  # malformed lod= in a hand-edited file - not worth failing the whole import over
    if 'category' in fields:
        obj.pbd.pbd_category = fields['category'].strip('"')
    if fields.get('indestructible') == 'true':
        obj.pbd.pbd_indestructible = True
        if 'hardness' in fields:
            try:
                obj.pbd.pbd_hardness = float(fields['hardness'])
            except ValueError:
                pass  # malformed hardness= in a hand-edited file - not worth failing the whole import over
        if 'resistance' in fields:
            try:
                obj.pbd.pbd_resistance = float(fields['resistance'])
            except ValueError:
                pass
    if 'linkGroup' in fields:
        obj.pbd.pbd_link_group = fields['linkGroup']
    if fields.get('loop') == 'true':
        obj.pbd.pbd_loop_animation = True
    # growthDays no longer exists as of the generic channel system
    # (see PbdInstance.Keyframe's channel field) - not read here even if
    # an OLD file still has it, since nothing on the engine side
    # consumes it anymore either.

    for mod in inst['modifiers']:
        _apply_modifier(obj, mod)

    for kf in inst['keyframes']:
        _apply_keyframe(obj, kf, parent_factor)

    # Once a keyframe touches location/rotation/scale, Blender's f-curve
    # for that property re-evaluates and overwrites it on every
    # subsequent frame change - by the time the loop above finishes, the
    # object's own base values (set once, above) may silently reflect
    # whatever frame the last keyframe happened to land on instead. This
    # doesn't re-key anything, just restores the STATIC values this
    # instance's own scale=/pos=/rot= fields should show on export.
    if inst['keyframes']:
        obj.location = loc
        obj.rotation_euler = euler
        obj.scale = bscale
        # matrix_world/matrix_local (what _serialize_instance actually
        # reads, not these properties directly) come from Blender's
        # depsgraph, which doesn't refresh itself immediately after a
        # plain Python assignment - without this, the restored values
        # above are correct when read directly but export would still
        # see whatever matrix the last keyframe's frame left evaluated.
        bpy.context.view_layer.update()

    # Was parsed and then dropped here: a lever arm survived Java <-> Java
    # but vanished the moment a file went through Blender. Not applied to
    # a light or a reference - neither has anywhere to put one on export
    # (see export_pbd._check_motion_setup).
    if inst.get('leverArm') and obj.pbd.pbd_type not in ('ref', 'light'):
        _apply_lever_arm(obj, inst['leverArm'], pos, rot, euler, parent_factor)

    return obj


def _apply_lever_arm(obj, arm, base_pos, base_rot_deg, closed_euler, parent_factor=1.0):
    """Fills obj's Lever Arm properties from a parsed leverArm { } block
    (see _lever_arm_from_fields) - the inverse of export_pbd.
    _serialize_lever_arm_lines.

    The open pose goes through the same PBD -> Blender conversion as the
    instance's own pos/rot (_pbd_transform_to_blender), NOT a per-component
    remap. An openPos/openRot the block leaves out means "this instance's
    own pos/rot" (that is what the engine does), so the base values stand
    in for it. Imported children always get an identity parent inverse (see
    the parenting pass in import_pbd_file), so the converted pose is
    already in the frame Open Position/Open Rotation are read from.
    The open Euler is the one nearest the closed rotation, so an opening
    of more than a half turn on one side of +/-180 deg is not folded back
    onto the other side (the engine interpolates Euler angles, it would
    swing the long way round)."""
    pbd = obj.pbd
    pbd.pbd_lever_arm_enabled = True
    pbd.pbd_lever_arm_speed = max(0.01, arm.get('speed', 1.0))  # the property's own minimum - the engine itself requires > 0

    open_pos = arm.get('openPos', base_pos)
    open_rot = arm.get('openRot', base_rot_deg)
    open_loc, open_euler, _ = _pbd_transform_to_blender(open_pos, open_rot, (1.0, 1.0, 1.0), False, parent_factor)
    open_euler = open_euler.to_quaternion().to_euler('XYZ', closed_euler)
    pbd.pbd_lever_arm_open_pos = open_loc
    pbd.pbd_lever_arm_open_rot = open_euler

    pbd.pbd_lever_arm_release = arm.get('release', 'snap')
    pbd.pbd_lever_arm_locked = bool(arm.get('locked', False))
    pbd.pbd_lever_arm_lock_at = arm.get('lockAt', 0.0)
    pbd.pbd_lever_arm_open_sound = arm.get('openSound', "")
    pbd.pbd_lever_arm_close_sound = arm.get('closeSound', "")


def _apply_modifier(obj, mod):
    mtype = mod['type']
    params = mod['params']
    if mtype == 'bend':
        obj.pbd.pbd_bend_enabled = True
        if 'axis' in params:
            obj.pbd.pbd_bend_axis = params['axis'].upper()
        if 'angle' in params:
            obj.pbd.pbd_bend_angle = math.radians(float(params['angle']))  # .pbd stores degrees, pbd_bend_angle (subtype='ANGLE') stores radians
    elif mtype == 'shear':
        obj.pbd.pbd_shear_enabled = True
        for axis in ('X', 'Y', 'Z'):
            key = f'factor{axis}'
            if key in params:
                setattr(obj.pbd, f'pbd_shear_factor_{axis.lower()}', float(params[key]))
    elif mtype == 'taper':
        obj.pbd.pbd_taper_enabled = True
        if 'bottomScale' in params:
            obj.pbd.pbd_taper_bottom_scale = float(params['bottomScale'])
        if 'topScale' in params:
            obj.pbd.pbd_taper_top_scale = float(params['topScale'])
    # twist/curve are documented no-ops engine-side (see roadmap notes) -
    # nothing meaningful to reconstruct in Blender for them yet.


def _apply_keyframe(obj, kf, parent_factor=1.0):
    """Inserts a real Blender keyframe reproducing the imported
    rotation/scale - this feeds back into the SAME f-curves
    _serialize_keyframes/anim_compat already read, so a round-tripped
    file keeps working with the existing keyframe panel, goto/delete
    buttons, and export untouched.

    Channel-mode keyframes (kf.get('channel') set): the ORIGINAL Blender
    frame number can't be recovered here - export only ever writes the
    already-converted channel value (time = frame * time_scale), never
    the factor itself, so there's no way back to the artist's original
    frame numbers from the file alone. This uses the channel value
    directly as the frame number instead, and sets THIS object's own
    pbd_channel_time_scale to 1.0 - a re-export immediately after import
    reproduces the same channel values exactly (round-trip preserved at
    the level that actually matters, the channel's own numbers), even
    though the Blender timeline no longer matches whatever frames the
    original artist actually keyframed on.
    """
    scene = bpy.context.scene
    channel = kf.get('channel')
    if channel:
        obj.pbd.pbd_channel_name = channel
        obj.pbd.pbd_channel_time_scale = 1.0
        frame = round(kf['time'])
    else:
        frame = round(kf['time'] * scene.render.fps)
    scene.frame_set(frame)
    # Position and rotation convert independently of each other (the
    # translation of a PBD -> Blender matrix conversion does not depend on
    # its rotation, and vice versa), so each is only touched when the
    # keyframe has it. The position used to be dropped altogether: a
    # drawer sliding open by keyframes came back from Blender not moving.
    kf_loc, kf_euler, _ = _pbd_transform_to_blender(
        kf.get('pos', (0, 0, 0)), kf.get('rot', (0, 0, 0)), (1, 1, 1), False, parent_factor)
    if 'rot' in kf:
        obj.rotation_euler = kf_euler
    if 'pos' in kf:
        obj.location = kf_loc
    obj.keyframe_insert(data_path='rotation_euler', frame=frame)
    if 'pos' in kf:
        obj.keyframe_insert(data_path='location', frame=frame)
    if 'scale' in kf:
        _, _, blender_scale = _pbd_transform_to_blender(
            (0, 0, 0), (0, 0, 0), kf['scale'],
            obj.pbd.pbd_type not in export_pbd._UNSCALED_TYPES, parent_factor)
        obj.scale = blender_scale
        obj.keyframe_insert(data_path='scale', frame=frame)
    if 'sound' in kf:
        entry = obj.pbd.pbd_keyframe_sounds.add()
        entry.time = kf['time']
        entry.sound_file = kf['sound']


def _merge_pbdmat_into_scene(context, mat_path, warnings):
    """Parses mat_path and creates/updates EMBEDDED-mode PbdMaterialEntry
    items for every material found - the MERGE behavior, extracted here
    so both the .pbd import's own include_material handling AND the
    new standalone IMPORT_OT_pbdmat operator's own Merge mode share one
    implementation rather than two copies that could drift apart.
    Mutates warnings in place (matching import_pbd_file's own existing
    convention) rather than returning them, so an existing call site
    doesn't need restructuring to adopt this."""
    if not os.path.exists(mat_path):
        warnings.append(f"'{mat_path}' not found")
        return
    problems = []
    try:
        parsed = materials_module._parse_pbdmat(mat_path, problems)
    except (OSError, ValueError) as e:  # ValueError: not a .pbdmat the engine could read (and a file that is not UTF-8)
        warnings.append(f"Could not read materials from {mat_path}: {e}")
        return
    mat_dir = os.path.dirname(os.path.abspath(mat_path))
    for mname, mfields in parsed.items():
        entry = context.scene.pbd_materials.get(mname)
        if entry is None:
            entry = context.scene.pbd_materials.add()
            entry.name = mname
        entry.material_source = 'EMBEDDED'
        materials_module.apply_pbdmat_fields(entry, mfields, mat_dir, problems)
    warnings.extend(problems)


def import_pbd_file(context, filepath, display_name=None, material_import_mode='MERGE', _recursion_depth=0, _budget=None):
    """Returns (instance_count, warning_list). display_name, if given,
    names the grouping root instead of filepath's own basename - for a
    .pbdbin/.pbdasset, filepath by this point is a decompressed/
    extracted TEMP file (see IMPORT_OT_pbd.execute()), whose name is an
    implementation detail (a hidden ".x_decompressed.pbd" sibling, or
    always literally "scene" inside every .pbdasset) rather than
    anything the user would recognize as what they imported.

    material_import_mode: 'MERGE' (default, existing behavior) parses
    this .pbd's own include_material target and recreates its materials
    as local EMBEDDED entries, same as ever. 'INCLUDE' instead adds the
    include_material target's own PATH to
    scene.pbd_include_material_sources, so re-exporting still points at
    the SAME external .pbdmat rather than a fresh local copy - the same
    choice IMPORT_OT_pbd's own dialog now offers for the .pbd's
    instances themselves, extended to cover a .pbd that carries its own
    include_material too, not just the standalone IMPORT_OT_pbdmat case.

    _budget (safety.ImportBudget; made here for the import a person starts) is shared by every file the import reaches through
    pbd_ref: the instances they would create and the files they open are counted in all, so that a scene which includes ten copies
    of a scene which includes ten copies... ends in a message instead of in Blender going down. Raises safety.Refused (a ValueError)
    for a file that alone is more than the budget."""
    warnings = []
    if _budget is None:
        _budget = safety.ImportBudget()
    base_dir = os.path.dirname(os.path.abspath(filepath))
    scene_meta, include_material, instances = parse_pbd_file(filepath)
    _budget.add_instances(len(instances), os.path.basename(filepath))
    if 'name' in scene_meta:
        context.scene.pbd_scene_name = scene_meta['name']
    if 'kind' in scene_meta:
        context.scene.pbd_scene_kind = scene_meta['kind']
    if 'authors' in scene_meta:
        context.scene.pbd_scene_authors = ", ".join(scene_meta['authors'])
    if 'origin' in scene_meta:
        context.scene.pbd_scene_origin = scene_meta['origin']
    if 'description' in scene_meta:
        context.scene.pbd_scene_description = scene_meta['description']

    # What each instance's parent is, so its stored pos/scale can be undone
    # relative to a parent whose canonical-shape x2 Blender does not have
    # (export_pbd._factors says why). Instances of the file only: a parent
    # that is not in it is reported by the parenting pass below.
    type_of = {i['id']: i['type'] for i in instances}

    def parent_factor_of(inst):
        parent_type = type_of.get(inst['fields'].get('parent'))
        if parent_type is None:
            return 1.0
        return export_pbd._shape_factor('ref' if parent_type == 'pbd_ref' else parent_type)

    name_to_obj = {}
    for inst in instances:
        try:
            obj = _create_object_for_instance(inst, base_dir, parent_factor_of(inst))
        except ParseError as e:
            warnings.append(f"{inst.get('id', '?')}: {e}")
            continue
        name_to_obj[inst['id']] = obj

        # Recursively resolve and import a pbd_ref's OWN content - this
        # is the actual "Blender doesn't resolve/display dependencies
        # by reference" fix: before this, a pbd_ref only ever became a
        # bare, empty Empty marker here, regardless of whether
        # source= pointed at something real - no different from a
        # broken reference, visually. Depth-limited (not a visited-set:
        # a legitimate diamond - two different objects both
        # referencing the same shared prop - should still resolve
        # twice, not be treated as a cycle) since a REAL cycle (A
        # references B references A) would otherwise recurse forever;
        # 6 levels is far deeper than any real asset hierarchy this
        # project has ever produced, while still generous enough that
        # a legitimate multi-level reference chain isn't cut short.
        if obj is not None and inst['type'] in ('group', 'pbd_ref') and 'source' in inst['fields']:
            source = inst['fields']['source'].strip('"')
            if _recursion_depth >= safety.MAX_INCLUDE_DEPTH:
                warnings.append(f"{inst['id']}: reference chain too deep ({safety.MAX_INCLUDE_DEPTH}+ levels) - "
                                 f"stopping here in case this is a cycle, not importing '{safety.printable(source)}'")
            else:
                try:
                    ref_path, ref_base_dir, ref_warning = _resolve_pbd_source(source, base_dir, context, budget=_budget)
                    if ref_warning:
                        warnings.append(f"{inst['id']}: {ref_warning}")
                    ref_display_name = os.path.splitext(os.path.basename(source))[0]
                    ref_count, ref_warnings, ref_result_obj = import_pbd_file(
                        context, ref_path, display_name=ref_display_name,
                        material_import_mode=material_import_mode, _recursion_depth=_recursion_depth + 1, _budget=_budget)
                    warnings.extend(f"{inst['id']} -> {w}" for w in ref_warnings)
                    if ref_result_obj is not None:
                        # Parented under the pbd_ref's OWN Empty, whose
                        # position/rotation/scale already carry
                        # whatever THIS instance's own pos=/rot=/
                        # scale= fields set - Blender's own parent-
                        # transform composition is what actually makes
                        # the referenced content appear correctly
                        # placed, the same way the engine's own
                        # PatchExpander/world-transform composition
                        # does at runtime for the exact same
                        # reference.
                        ref_result_obj.parent = obj
                        ref_result_obj.matrix_parent_inverse.identity()
                except (OSError, ValueError, ParseError) as e:
                    warnings.append(f"{inst['id']}: could not resolve/import reference '{source}': {e} "
                                     f"(showing the empty placeholder instead)")

    # Second pass for parenting - every object must exist first, since a
    # child can be listed before its parent isn't guaranteed by the
    # format (the engine's own PbdScene.resolveHierarchy handles this by
    # sorting, this just needs both ends to exist before linking).
    for inst in instances:
        parent_name = inst['fields'].get('parent')
        if parent_name:
            child = name_to_obj.get(inst['id'])
            parent = name_to_obj.get(parent_name)
            if child and parent:
                child.parent = parent
                # Identity, not parent.matrix_world.inverted(): the
                # parsed pos/rot/scale are already the LOCAL (parent-
                # relative) transform - matching what _serialize_instance
                # exports via matrix_local for a parented object in the
                # first place - so they should combine normally with the
                # parent's own world transform via Blender's usual
                # parent.matrix_world @ matrix_parent_inverse @
                # matrix_basis formula. Setting matrix_parent_inverse to
                # the parent's own inverse cancels the parent transform
                # out entirely instead.
                child.matrix_parent_inverse.identity()
            elif child:
                warnings.append(f"{inst['id']}: parent '{parent_name}' not found in this file")

    # Third pass for container trigger references - same reasoning as
    # parenting above: a referenced door object might be listed before
    # or after the storage cube referencing it, so resolve names to
    # actual objects only once every object in the file exists. A
    # storage cube can list several doors (see containerTriggers, plural,
    # accumulated in _parse_instance_body since a plain dict would have
    # silently kept only the last of several same-named fields).
    for inst in instances:
        storage_obj = name_to_obj.get(inst['id'])
        if storage_obj is None:
            continue
        for trigger_name in inst['containerTriggers']:
            trigger_obj = name_to_obj.get(trigger_name)
            if trigger_obj:
                entry = storage_obj.pbd.pbd_linked_doors.add()
                entry.door = trigger_obj
            else:
                warnings.append(f"{inst['id']}: containerTrigger '{trigger_name}' not found in this file")

    if include_material:
        # Same URL/local/default-domain-fallback resolution as a
        # pbd_ref's own source= (see _resolve_to_local_file's own doc)
        # - previously just os.path.join(base_dir, include_material),
        # which only ever worked for a LOCAL .pbdmat sitting right next
        # to the .pbd; a URL include_material (see upload.php's own
        # localize_local_references, which now writes exactly this for
        # anything the server's own submissions reference) or a bare
        # filename meant to resolve against this project's default
        # host both silently found nothing before this fix - exactly
        # the reported "PBDBIN don't carry their materials in Blender"
        # symptom, worse still for a bare reference to something that
        # was never local to begin with.
        try:
            mat_path = _resolve_to_local_file(include_material, base_dir, context, budget=_budget)
        except Exception as e:
            warnings.append(f"include_material '{include_material}' could not be resolved: {e}")
            mat_path = None
        if mat_path is not None:
            if material_import_mode == 'INCLUDE':
                # Keep pointing at the SAME external reference rather
                # than copying its materials in as local entries - see
                # this function's own doc. The ORIGINAL include_material
                # string, not mat_path (which could be a resolved local
                # cache file for a URL/fallback case) - re-exporting
                # should still point at the live source, not today's
                # cached copy of it.
                src_entry = context.scene.pbd_include_material_sources.add()
                src_entry.path = include_material
            else:
                _merge_pbdmat_into_scene(context, mat_path, warnings)

    # Fourth step: group every TOP-LEVEL (no parent= in the file)
    # imported instance under one new Empty, named after the file -
    # otherwise an import with several independent top-level pieces
    # (say, a wardrobe body plus a couple of shelves that were never
    # parented to it inside the file) leaves the scene with that many
    # separate, ungrouped objects, and nothing that represents "the
    # thing I just imported" as a single selectable unit to grab,
    # rotate, or scale as a whole. This is a NEW object every import
    # creates fresh - it is never an existing object already in the
    # scene, so joining or parenting the import to this new root can't
    # accidentally catch something unrelated the way parenting to
    # whatever happened to be the active object before the import ran
    # could have. Skipped when there's only one top-level piece already
    # (it can already stand in for "the whole model" on its own) or none
    # at all (nothing to group).
    top_level = [name_to_obj[inst['id']] for inst in instances
                 if inst['id'] in name_to_obj and not inst['fields'].get('parent')]
    root_obj = None
    if len(top_level) > 1:
        root_name = display_name or os.path.splitext(os.path.basename(filepath))[0]
        root_obj = bpy.data.objects.new(root_name, None)
        root_obj.empty_display_type = 'PLAIN_AXES'
        root_obj.empty_display_size = 0.5
        context.collection.objects.link(root_obj)
        for obj in top_level:
            obj.parent = root_obj
            obj.matrix_parent_inverse.identity()

    # Select just the result of THIS import (the new root if one was
    # made, otherwise whatever the one top-level piece already was) and
    # make it active, so it can be grabbed/rotated/scaled immediately
    # rather than needing to be found and selected by hand afterward.
    for o in context.selected_objects:
        o.select_set(False)
    if root_obj is not None:
        root_obj.select_set(True)
        context.view_layer.objects.active = root_obj
    elif top_level:
        top_level[0].select_set(True)
        context.view_layer.objects.active = top_level[0]

    # "The one object that represents this whole import" - same
    # root_obj-or-single-top_level-piece-or-None logic the selection
    # code just above already computed, just also handed back to the
    # caller instead of only being used locally - needed so a pbd_ref
    # resolved RECURSIVELY (see _resolve_and_import_ref below) has
    # something concrete to parent under the reference's own Empty,
    # the same way a caller resolving a .pbdasset/.pbdbin manually
    # would otherwise have to re-derive this same result by hand.
    result_obj = root_obj if root_obj is not None else (top_level[0] if top_level else None)
    # Let Blender catch up before handing the scene back: positions, parents
    # and sizes (matrix_world, matrix_local, dimensions) come from the
    # depsgraph, which a plain Python assignment does not refresh. In the
    # interface Blender does it between two clicks; a script that imports and
    # then exports straight away (a batch conversion, a test) read stale
    # matrices and wrote wrong positions for whatever had just been created.
    context.view_layer.update()
    return len(instances), warnings, result_obj


class IMPORT_OT_pbd(bpy.types.Operator):
    """Imports a .pbd, .pbdasset, or .pbdbin scene file into the current
    Blender scene, reconstructing every instance's type, transform,
    material, modifiers, and keyframes - the inverse of File > Export >
    PBD. A .pbdasset (zip: scene.pbd + bundled materials/textures) gets
    unzipped first; a .pbdbin (gzip-compressed minified text) gets
    decompressed first - both then feed into the exact same reader a
    plain .pbd does. Neither compiled format had ANY way to be opened
    back up in Blender before this - producing one was possible, reading
    it back here wasn't.

    Source choice (local file vs URL) shows first, in a small dialog,
    rather than jumping straight into Blender's file browser - which
    had no way to offer the URL alternative at all, since ImportHelper's
    normal invoke() goes directly to fileselect_add with no stop in
    between. 'File' mode continues into the real file browser after
    that dialog closes (see execute() below); 'URL' mode fetches
    straight from execute() instead, reusing the same PbdFetcher-
    compatible cache pbd.test_reference and pbd_ref's own URL sources
    already use."""
    bl_idname = "import_scene.pbd"
    bl_label = "Import PBD"
    bl_options = {'REGISTER', 'UNDO'}

    # SKIP_SAVE on both: without it, Blender remembers these values
    # across invocations (its normal "last used operator settings"
    # behavior) - meaning a SECOND Import, from EITHER the panel button
    # or File > Import, would see filepath already set to whatever was
    # picked last time and skip straight to re-importing THAT file
    # again instead of opening the browser for a new one. Confirmed
    # exactly this way: reported as "importing a second time just
    # re-pastes the old import" - not a guess, a real reproduction.
    filepath: bpy.props.StringProperty(subtype='FILE_PATH', options={'SKIP_SAVE'})
    filter_glob: bpy.props.StringProperty(default="*.pbd;*.pbdasset;*.pbdbin", options={'HIDDEN'})
    source_mode: bpy.props.EnumProperty(
        name="Source",
        items=[('file', "Local File", "Pick a .pbd file from disk"),
               ('url', "URL", "Fetch a .pbd file from a http(s):// address")],
        default='file',
    )
    url: bpy.props.StringProperty(name="URL", default="", options={'SKIP_SAVE'},
                                   description="Full http(s):// address of a .pbd file")
    # The actual fix for the complaint that motivated this whole
    # property: importing unconditionally MERGED every instance in as
    # real Blender objects - fine for "I want to edit this scene
    # myself", actively wrong for "I want to place a community asset
    # (by its own URL, say) without duplicating its entire content into
    # my own file" - which is exactly the pbd_ref mechanism already
    # exists for. Default stays MERGE - this operator's existing,
    # already-relied-upon behavior for anyone editing their own scene -
    # rather than silently changing what a plain re-run of "Import PBD"
    # does for someone who never asked for a reference.
    import_mode: bpy.props.EnumProperty(
        name="Import As",
        items=[
            ('MERGE', "Merge (copy every instance in)",
             "Recreates every instance in this file as a real object in the current scene - "
             "edit them freely, but re-importing the same file again duplicates everything a second time"),
            ('INCLUDE', "Include (reference only)",
             "Adds a single pbd_ref pointing at this file/URL instead - nothing is duplicated into "
             "this scene, and the reference re-resolves to whatever the source currently contains "
             "every time this scene is loaded/exported. Use this for a community asset you don't "
             "intend to edit yourself"),
        ],
        default='MERGE',
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=350)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "source_mode", expand=True)
        if self.source_mode == 'url':
            layout.prop(self, "url")
        else:
            layout.label(text="Click OK, then choose a file in the browser")
            layout.label(text="that opens next.")
        layout.separator()
        layout.prop(self, "import_mode", expand=True)
        if self.import_mode == 'INCLUDE':
            box = layout.box()
            box.label(text="Adds one pbd_ref Empty - place/rotate/scale it,", icon='INFO')
            box.label(text="nothing else. See its own panel to fine-tune.")

    def execute(self, context):
        if self.source_mode == 'file' and not self.filepath:
            # Confirmed "File" in the dialog but haven't picked one yet -
            # THIS is where ImportHelper's invoke() would normally have
            # gone straight to; chaining it here instead is what lets the
            # dialog above run first. Blender re-invokes execute() once a
            # real file is chosen, this time with filepath set.
            context.window_manager.fileselect_add(self)
            return {'RUNNING_MODAL'}

        raw_source = self.url.strip() if self.source_mode == 'url' else self.filepath
        if self.source_mode == 'url' and not raw_source:
            self.report({'ERROR'}, "Enter a URL first")
            return {'CANCELLED'}

        if self.import_mode == 'INCLUDE':
            # Short-circuits everything below - no fetch, no
            # decompression, no parsing, no instance recreation at all.
            # The reference points at raw_source AS GIVEN (the URL
            # itself, or the local path chosen) - never at whatever a
            # resolved/cached/extracted path might otherwise be, since
            # the whole point is a live reference that re-resolves to
            # whatever the source currently holds, not a frozen copy of
            # today's fetch.
            bpy.ops.object.add_pbd_ref()
            ref_obj = context.active_object
            ref_obj.pbd.pbd_ref_source = raw_source
            display_name = os.path.splitext(os.path.basename(raw_source))[0]
            if display_name:
                ref_obj.name = display_name
            self.report({'INFO'}, f"Added a pbd_ref pointing at {raw_source}")
            return {'FINISHED'}

        # .pbdasset (a zip: scene.pbd + bundled materials/textures/
        # manifest - see PbdAssetFormat.java) and .pbdbin (gzip-
        # compressed minified .pbd text - see PbdBinFormat.java) both
        # need converting to a real, on-disk plain .pbd before the
        # existing import_pbd_file() below can read them - it works with
        # text-on-disk, not zip or gzip. _resolve_pbd_source handles
        # this AND the URL fetch, uniformly, in one call - no separate
        # upfront fetch step needed the way there used to be.
        display_name = os.path.splitext(os.path.basename(raw_source))[0]  # from the ORIGINAL source name, before _resolve_pbd_source below replaces import_path with a temp/extracted path
        try:
            import_path, sub_base_dir, resolve_warning = _resolve_pbd_source(raw_source, None, context, trusted_path=True)
        except (OSError, ValueError) as e:
            self.report({'ERROR'}, f"Could not resolve '{raw_source}': {e}")
            return {'CANCELLED'}
        if resolve_warning:
            self.report({'WARNING'}, resolve_warning)

        try:
            count, warnings, _ = import_pbd_file(context, import_path, display_name=display_name,
                                                  material_import_mode=self.import_mode)
        except (OSError, ValueError, ParseError) as e:     # ValueError: a file refused for its size or its names, and one that is not UTF-8
            self.report({'ERROR'}, f"Import failed: {e}")
            return {'CANCELLED'}

        for w in warnings:
            self.report({'WARNING'}, w)
        self.report({'INFO'}, f"Imported {count} instance(s) from {import_path}")
        return {'FINISHED'}


class IMPORT_OT_pbdmat(bpy.types.Operator):
    """Imports a standalone .pbdmat (materials-only) file, from a local
    path or a URL - the button that never existed before despite .pbd
    import needing to handle exactly this same file type as part of
    its own include_material handling. Same Merge/Include choice as
    IMPORT_OT_pbd, for the same reason: Merge recreates every material
    as a local EMBEDDED entry (edit them freely, but re-importing
    duplicates them and re-exporting no longer points at the original
    file); Include instead adds one include_material line pointing
    straight at this file/URL, matching how the community is meant to
    reuse a shared, deduplicated materials library by its own URL
    rather than everyone copying its content into their own scenes."""
    bl_idname = "import_scene.pbdmat"
    bl_label = "Import PBD Materials (.pbdmat)"
    bl_options = {'REGISTER', 'UNDO'}

    filepath: bpy.props.StringProperty(subtype='FILE_PATH', options={'SKIP_SAVE'})
    filter_glob: bpy.props.StringProperty(default="*.pbdmat", options={'HIDDEN'})
    source_mode: bpy.props.EnumProperty(
        name="Source",
        items=[('file', "Local File", "Pick a .pbdmat file from disk"),
               ('url', "URL", "Fetch a .pbdmat file from a http(s):// address")],
        default='file',
    )
    url: bpy.props.StringProperty(name="URL", default="", options={'SKIP_SAVE'},
                                   description="Full http(s):// address of a .pbdmat file")
    import_mode: bpy.props.EnumProperty(
        name="Import As",
        items=[
            ('MERGE', "Merge (copy every material in)",
             "Recreates every material in this file as a local EMBEDDED entry in the current scene's "
             "material list - edit them freely, but re-importing the same file again duplicates them, "
             "and re-exporting writes a fresh local copy rather than pointing back at this file"),
            ('INCLUDE', "Include (reference only)",
             "Adds one include_material line pointing at this file/URL instead of copying its content "
             "in - nothing is duplicated, and every material in it is picked up by mat= elsewhere in "
             "this scene exactly as if it had been written here directly. Use this for a shared/"
             "community materials file you don't intend to edit yourself"),
        ],
        default='MERGE',
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=350)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "source_mode", expand=True)
        if self.source_mode == 'url':
            layout.prop(self, "url")
        else:
            layout.label(text="Click OK, then choose a file in the browser")
            layout.label(text="that opens next.")
        layout.separator()
        layout.prop(self, "import_mode", expand=True)

    def execute(self, context):
        if self.source_mode == 'file' and not self.filepath:
            context.window_manager.fileselect_add(self)
            return {'RUNNING_MODAL'}

        if self.source_mode == 'url':
            if not self.url.strip():
                self.report({'ERROR'}, "Enter a URL first")
                return {'CANCELLED'}
            from .. import fetcher
            cache_dir = _shared_remote_cache_dir(context)
            try:
                local_path = fetcher.fetch(self.url.strip(), cache_dir, None, use_cache=True)
            except fetcher.FetchError as e:
                self.report({'ERROR'}, f"Fetch failed: {e}")
                return {'CANCELLED'}
            mat_path = local_path
            ref_source = self.url.strip()
        else:
            mat_path = self.filepath
            ref_source = self.filepath

        if self.import_mode == 'INCLUDE':
            entry = context.scene.pbd_include_material_sources.add()
            entry.path = ref_source
            self.report({'INFO'}, f"Added include_material pointing at {ref_source}")
            return {'FINISHED'}

        warnings = []
        _merge_pbdmat_into_scene(context, mat_path, warnings)
        for w in warnings:
            self.report({'WARNING'}, w)
        self.report({'INFO'}, f"Imported materials from {mat_path}")
        return {'FINISHED'}


def _shared_remote_cache_dir(context):
    """Same cache/remote layout PbdPaths.REMOTE_CACHE_DIR (Java) and
    ui_panel.py's own _remote_cache_dir (pbd.test_reference) use, so a
    URL fetched here, from Test Reference, or by the engine itself all
    share one cache instead of each keeping a separate copy. Duplicated
    rather than imported from ui_panel.py specifically to avoid this
    operators/ module reaching back up to import from the module that
    already imports FROM operators/ - not a circular import Python can't
    resolve, but the dependency direction it implies is backwards from
    every other import in this codebase, so kept as a small, obviously-
    matching duplicate instead. Anchored to this .blend file's own
    directory now (no more separately-configured project root setting
    to reach for), falling back to a temp directory if the file has
    never been saved."""
    base = bpy.path.abspath("//")
    if not base:
        import tempfile
        base = tempfile.gettempdir()
    return os.path.join(base, "pbd_cache", "remote")


class OBJECT_OT_pbd_clear_cache(bpy.types.Operator):
    """Deletes every file under this .blend's own pbd_cache/remote/ -
    the local cache _shared_remote_cache_dir above (and PbdFetcher.java,
    and Test Reference) all share for a fetched URL, keyed by a hash of
    the URL itself (see fetcher.py's own _cache_path_for). Needed
    because that cache is otherwise permanent: once fetched, a URL is
    served from the cache forever, so a community asset that gets
    updated on the server never re-fetches here without a way to clear
    the stale copy out first."""
    bl_idname = "pbd.clear_cache"
    bl_label = "Clear Remote Cache"
    bl_options = {'REGISTER'}

    def execute(self, context):
        cache_dir = _shared_remote_cache_dir(context)
        if not os.path.isdir(cache_dir):
            self.report({'INFO'}, "Cache is already empty (nothing at " + cache_dir + ")")
            return {'FINISHED'}
        count = 0
        for name in os.listdir(cache_dir):
            path = os.path.join(cache_dir, name)
            try:
                if os.path.isfile(path):
                    os.remove(path)
                    count += 1
            except OSError as e:
                self.report({'WARNING'}, f"Could not remove {name}: {e}")
        self.report({'INFO'}, f"Cleared {count} cached file(s) from {cache_dir}")
        return {'FINISHED'}


def _menu_func_import(self, context):
    # ONE menu entry (not three), since it's the SAME operator handling
    # all three extensions now (see IMPORT_OT_pbd's own filter_glob and
    # its .pbdasset/.pbdbin handling in execute()) - the file browser's
    # own filter already lists all three, this label just needs to say
    # so up front rather than implying only plain .pbd is accepted.
    self.layout.operator(IMPORT_OT_pbd.bl_idname, text="PBD Scene (.pbd/.pbdasset/.pbdbin)")
    self.layout.operator(IMPORT_OT_pbdmat.bl_idname, text="PBD Materials (.pbdmat)")


CLASSES = (IMPORT_OT_pbd, IMPORT_OT_pbdmat, OBJECT_OT_pbd_clear_cache)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.TOPBAR_MT_file_import.append(_menu_func_import)


def unregister():
    bpy.types.TOPBAR_MT_file_import.remove(_menu_func_import)
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
