import math
import os
import re

import bpy
import mathutils

from .. import anim_compat
from bpy_extras.io_utils import ExportHelper

# Blender is Z-up, the .pbd format is Y-up (like most real-time/GLSL
# pipelines). The conversion is done by conjugating each local transform
# with this -90 deg rotation around X. Verified independently before this
# file was written: composing the converted local transforms along a
# hierarchy gives exactly the same result as converting the world matrix
# directly (difference on the order of 1e-16).
_AXIS_CONVERSION = mathutils.Matrix.Rotation(math.radians(-90.0), 4, 'X')
_AXIS_CONVERSION_INV = _AXIS_CONVERSION.inverted()


def _to_pbd_matrix(matrix):
    return _AXIS_CONVERSION @ matrix @ _AXIS_CONVERSION_INV


# Default local dimensions of a native Blender mesh for each type
# (verified: all 6 Blender primitives fit in a 2x2x2 box, 2x2x0 for the
# flat ones (plane, disc) - none of them needs an explicit size/radius/
# depth argument for this, it is the native default).
_EXPECTED_LOCAL_DIMS = {
    'plane': (2.0, 2.0, 0.0),
    'sphere': (2.0, 2.0, 2.0),
    'cylinder': (2.0, 2.0, 2.0),
    'cone': (2.0, 2.0, 2.0),
    'cube': (2.0, 2.0, 2.0),
    'disc': (2.0, 2.0, 0.0),
    'torus': (2.0, 2.0, 0.6),
}

# The shader (see pbd.tese) defines its canonical primitives with a
# half-extent of 0.5 (unit 1x1x1 box), while a native Blender mesh has a
# half-extent of 1.0 (2x2x2 box) - without compensation, everything would
# render at exactly half the size visible in Blender. Compensated once
# here, at the source, rather than requiring every user to create their
# primitives in one exact way.
_BLENDER_TO_SHADER_SCALE = 2.0

# Types with no native-2x2x2 mesh behind them: an arbitrary mesh keeps its
# own real size, and a reference / pivot / light has no geometry at all, so
# none of them gets (or needs) the x2 correction above.
_UNSCALED_TYPES = ('mesh', 'ref', 'group', 'light')


def _shape_factor(pbd_type):
    """The engine-size / Blender-size ratio of one object's own geometry:
    2 for a canonical shape (Blender's native mesh is 2x2x2, the engine's
    shape 1x1x1), 1 for everything in _UNSCALED_TYPES."""
    return 1.0 if pbd_type in _UNSCALED_TYPES else _BLENDER_TO_SHADER_SCALE

# --------------------------------------------------------------- instance ids
#
# Blender lets an object be called anything ("front door", "porte d'entree",
# "a=b"); the engine reads an instance id as a run of characters up to the
# next space or structural character (PbdParser.readIdentifier), so
# `cube front door {` is not a file. Every id the exporter writes - the
# instance's own, a `parent =`, a `containerTrigger =`, an embed's anchor and
# the prefix of its copies - goes through _pbd_id instead of obj.name.
_ID_UNSAFE = re.compile(r'[\s{}()\[\]=,#"]+')

# Blender object name -> the id it is written under, filled in by
# export_scene_to_pbd for the objects of the export in hand.
_ids = {}


def _safe_id(name):
    """`name` with each run of characters an id cannot hold turned into one
    underscore (and none left at either end); "object" when nothing is left."""
    return _ID_UNSAFE.sub("_", name).strip("_") or "object"


def _assign_ids(names):
    """{name: id} for these Blender object names. A name that is already
    safe keeps itself; the others get their cleaned-up form, with _2, _3...
    when two names would otherwise come to the same id ("front door" next to
    "front_door"), so no two objects ever share one."""
    ids, taken = {}, set()
    for name in names:
        if _safe_id(name) == name:
            ids[name] = name
            taken.add(name)
    for name in names:
        if name in ids:
            continue
        base = candidate = _safe_id(name)
        n = 2
        while candidate in taken:
            candidate = f"{base}_{n}"
            n += 1
        ids[name] = candidate
        taken.add(candidate)
    return ids


def _pbd_id(obj_or_name):
    """The id an object is written under in the file."""
    name = obj_or_name if isinstance(obj_or_name, str) else obj_or_name.name
    return _ids.get(name) or _safe_id(name)


# Canonical PBD face codes in PatchExpander part-index order (0-5) -
# +x=0 -x=1 +y=2(top) -y=3(bottom) +z=4 -z=5. Used both for faces= export
# below and documented again at properties.py's face booleans, since
# getting this backwards would silently remove the wrong face rather than
# error.
_PBD_FACE_CODES = ["+x", "-x", "+y", "-y", "+z", "-z"]


def _quote_if_needed(s):
    """Mirrors PbdSerializer.java's own quoteIfNeeded exactly - a bare
    value can't contain a space or a tab (readRawValue's un-quoted branch
    stops at the first one), and a `#` starts a comment (an unquoted
    metadata value is read up to it: "Wardrobe#2" came back as
    "Wardrobe"), so anything that might have one needs real quotes, not
    just hoping the reader is forgiving."""
    return f'"{s}"' if (" " in s or "\t" in s or "#" in s or s == "") else s


def _quote_token(s):
    """Mirrors PbdSerializer.java's own quoteToken exactly: for a single-
    token value inside a "key=value key=value" block (a keyframe's or a
    leverArm's sound file) - bare when PbdParser's readRawValue would
    read it back as ONE token, quoted when it would not (whitespace, a
    structural character, a comment marker, or nothing at all).
    _quote_if_needed alone is not enough here: it only looks for a
    space, so a file named `creak{1}.wav` or `door#2.wav` was written
    bare and corrupted the block it sat in."""
    bare = bool(s)
    for c in s:
        if c.isspace() or c in '#"{}()[]=,':
            bare = False
            break
    return s if bare else f'"{s}"'


def _metadata_text(s):
    """What a File-box value (name, kind, an author, origin, description) is
    written as: trimmed, on one line, and with no double quote - the format has
    no escape for one, and a `"` inside a quoted value would end it early and
    corrupt the rest of the header, so it is written as an apostrophe."""
    return s.replace('"', "'").replace("\r", " ").replace("\n", " ").strip()


def _quote_metadata_value(s, minify):
    """Mirrors PbdSerializer.java's own quoteMetadataValue exactly - see
    that method's doc comment for the full story. Scene METADATA (name/
    kind/author/origin/description) is read back by PbdParser's own
    readMetadataValue(), whose UNQUOTED branch reads to the next real
    '\\n' - fine in pretty text, where one always follows, but a real
    '\\n' never appears anywhere in a fully minified file (see
    _minify_pbd_text below), so an unquoted metadata value there reads
    to end of file, silently swallowing every instance after it.

    _quote_if_needed alone (space-only) is what PRETTY mode gets to use,
    precisely because a real newline is always there as a fallback
    terminator; this project's own real blueMetalBoard.pbdbin asset was
    corrupted exactly this way (confirmed by reproduction, not guessed)
    by `kind` going through _quote_if_needed and export_scene_to_pbd's
    own header code calling it with no space-bearing value to trigger
    on, while `kind` itself was written with NO quoting call at all -
    both gaps are fixed here by routing every metadata field through
    this one function instead, with minify always winning regardless of
    content."""
    return f'"{s}"' if minify else _quote_if_needed(s)


def _removed_face_codes(pbd_props):
    """Blender-labeled face booleans -> removed canonical PBD face codes.
    Mapping verified numerically against _AXIS_CONVERSION (Blender +Z,
    Blender's own up axis, lands on the engine's +Y "top", etc.) rather
    than assumed - see this project's own axis-conversion notes.
    Blender index -> canonical part: +X->0 -X->1 +Z->2 -Z->3 -Y->4 +Y->5."""
    kept = [
        pbd_props.pbd_cube_face_posx, pbd_props.pbd_cube_face_negx,
        pbd_props.pbd_cube_face_posz, pbd_props.pbd_cube_face_negz,
        pbd_props.pbd_cube_face_negy, pbd_props.pbd_cube_face_posy,
    ]
    return [_PBD_FACE_CODES[i] for i, k in enumerate(kept) if not k]


def _expected_local_dims(prim_type):
    # Fallback matches the 2x2x2 convention every current type follows -
    # not (1,1,1), which predates that convention and would falsely flag
    # any future type left out of the table above by mistake.
    return _EXPECTED_LOCAL_DIMS.get(prim_type, (2.0, 2.0, 2.0))


def _mesh_scale_factor(obj, expected):
    """Ratio (actual mesh dimension / expected canonical dimension) on
    each non-degenerate axis, after removing the object's own scale.
    Comes out to ~1.0 everywhere for a mesh created via Add > Mesh > PBD
    ...; a mismatch flags a mesh that no longer matches the canonical
    shape - for instance resized in Edit Mode (the mesh changed, not
    obj.scale), or created via Blender's native tool whose default sizes
    differ (its default cube is 2x2x2, not 1x1x1)."""
    factors = []
    for i in range(3):
        scale_i = obj.scale[i]
        if abs(scale_i) < 1e-8 or expected[i] < 1e-8:
            continue
        local_dim = obj.dimensions[i] / scale_i
        factors.append(local_dim / expected[i])
    return factors


def _check_mesh_matches_canonical(obj):
    """None if the mesh matches the expected canonical size for its type;
    otherwise an explicit warning message. Doesn't apply to 'mesh',
    'ref', 'light' or 'group': none of the four has a canonical shape to
    measure against (a 'mesh' is deliberately whatever geometry it is;
    'ref', 'light' and 'group' have no geometry of their own at all - all
    three are Empties), so there is no "expected size" to compare
    against - every 'mesh' object would otherwise report a spurious
    mismatch."""
    if obj.pbd.pbd_type in ('mesh', 'ref', 'light', 'group'):
        return None
    factors = _mesh_scale_factor(obj, _expected_local_dims(obj.pbd.pbd_type))
    if not factors:
        return None
    avg = sum(factors) / len(factors)
    if any(abs(f - avg) > 0.05 for f in factors):
        return (f"'{obj.name}': the mesh does not match a clean canonical "
                f"{obj.pbd.pbd_type} (factor differs per axis: "
                f"{['%.2f' % f for f in factors]}) - edited in Edit Mode?")
    if abs(avg - 1.0) > 0.05:
        return (f"'{obj.name}': the mesh is about {avg:.2f}x the native "
                f"Blender size expected for a {obj.pbd.pbd_type} - check "
                f"that it wasn't resized in Edit Mode, or that a modifier "
                f"(Bevel, Subdivision...) isn't changing its bounding box.")
    return None


def _format_vec3(v, precision=6):
    # The axis conversion is a -90 degree rotation computed in floating
    # point, so a coordinate that should be exactly 0 comes out as
    # -4.37114e-08 - noise, not a position, and it ended up written into
    # every exported file. Anything under a micro-unit is written as 0.
    c = [0.0 if abs(x) < 1e-6 else x for x in (v[0], v[1], v[2])]
    return f"({c[0]:.{precision}g}, {c[1]:.{precision}g}, {c[2]:.{precision}g})"


def _pbd_parent_of(obj):
    """The native Blender parent, if it is itself a tagged PBD primitive -
    otherwise None (the object is a root in the .pbd file)."""
    parent = obj.parent
    if parent is not None and getattr(parent, "pbd", None) and parent.pbd.is_pbd_primitive:
        return parent
    return None


def _factors(obj):
    """(own, parent): _shape_factor of this object, and of its PBD parent
    (1 for a root).

    A child's exported transform is relative to its parent's EXPORTED one,
    which already carries the parent's own x2 - so a child of a canonical
    shape inherits that doubling in the engine (parent.world x child.local
    composes the whole scale) while in Blender it does not (the doubling
    lives in the parent's mesh, not in its scale). The child's local pose
    has to be exported as  F_parent^-1 . local . F_child  to land where
    Blender has it: position / parent, scale x own / parent. Without it a
    knob glued to a door panel ended up twice as far away, and twice as
    big, as in Blender - for every child of a canonical shape."""
    parent = _pbd_parent_of(obj)
    return _shape_factor(obj.pbd.pbd_type), (_shape_factor(parent.pbd.pbd_type) if parent is not None else 1.0)


def _base_matrix(obj):
    """The Blender matrix an instance's own pos=/rot=/scale= are written
    from: relative to its PBD parent when it has one (matrix_local, the
    parent-inverse already included), absolute (matrix_world) otherwise."""
    return obj.matrix_local if _pbd_parent_of(obj) is not None else obj.matrix_world


def _pose_prefix(obj, base=None):
    """The part of an object's Blender transform chain that sits ABOVE its
    own Location/Rotation/Scale properties - for a child that is its
    matrix_parent_inverse (what Ctrl+P and "Fix to Animated Object" set),
    for a root whatever untagged parents it hangs under.

    Anything exported as "this object's pose at some other moment" - a
    keyframe, a lever arm's open pose - is read from those PROPERTIES
    (f-curves, pbd_lever_arm_open_pos/rot), which know nothing about this
    prefix; the base pose written at the top of an instance is read from
    the full matrix and does. Converting the two without it put the
    closed pose and the open pose in two different frames for any object
    whose parent inverse is not the identity: the door would swing off
    to a position offset by the parent's own transform at parenting time.
    base @ matrix_basis^-1 recovers the prefix without caring how it was
    built (an identity prefix gives exactly the old behaviour)."""
    if base is None:
        base = _base_matrix(obj)
    try:
        return base @ obj.matrix_basis.inverted()
    except ValueError:  # a zero scale makes matrix_basis singular - nothing sensible to recover
        return mathutils.Matrix.Identity(4)


def _euler_near(quat, compat):
    """quat as an XYZ Euler, picked among the equivalent triples as the one
    closest to `compat` (an Euler, or None for the plain principal one).
    The engine interpolates Euler angles component by component, so
    145 deg -> -170 deg (the same orientation as 190 deg) would swing the
    long way round, 315 deg the wrong way; matching the previous pose
    keeps every step on the side the artist posed it."""
    if compat is None:
        return quat.to_euler('XYZ')
    return quat.to_euler('XYZ', compat)


def _serialize_keyframes(obj, prefix=None):
    """Reads obj's own Blender keyframes (rotation_euler, location, and
    scale f-curves) and returns `keyframe { }` block strings, one per
    unique keyframe time across those curves. Evaluates every curve (not
    just the one that actually has a keyframe point at a given frame) at
    each collected time, so a time where only one property was keyed
    still gets a consistent, curve-interpolated pose rather than a gap -
    the engine's own interpolation then only has to do plain linear
    interpolation between these already-resolved poses, not reproduce
    Blender's own curve handles/easing.

    Channel mode (obj.pbd.pbd_channel_name non-empty): rather than
    inventing a new UI for "keyframes driven by a named channel instead
    of real time" (see pbd.render.ChannelTracker on the engine side),
    the artist just keyframes Scale normally on Blender's own timeline -
    completely standard, familiar tooling - and sets a channel name plus
    a time-scale factor converting frame number to channel-value units.
    A fast, ordinary-looking Blender animation (say, frame 0 to frame 24)
    becomes a very slow one once the engine drives it by a slowly-
    accumulating channel like "humidity" instead of by playback time -
    that's the whole trick behind making a few seconds of scale
    keyframing read as vegetation growing in over days.

    Returns an empty list if obj has no animation data at all - the
    normal case, not an error.
    """
    fcurves = anim_compat.get_object_fcurves(obj)
    if not fcurves:
        return []

    rot_curves = [anim_compat.find_fcurve(fcurves, "rotation_euler", i) for i in range(3)]
    loc_curves = [anim_compat.find_fcurve(fcurves, "location", i) for i in range(3)]
    scale_curves = [anim_compat.find_fcurve(fcurves, "scale", i) for i in range(3)]
    all_curves = [c for c in rot_curves + loc_curves + scale_curves if c is not None]
    if not all_curves:
        return []

    channel_name = obj.pbd.pbd_channel_name.strip()
    frames = sorted({kp.co.x for c in all_curves for kp in c.keyframe_points})
    fps = bpy.context.scene.render.fps
    if prefix is None:
        prefix = _pose_prefix(obj)
    own_factor, parent_factor = _factors(obj)

    lines = []
    previous_euler = None
    for frame in frames:
        time = (frame * obj.pbd.pbd_channel_time_scale) if channel_name else (frame / fps)
        rot_rad = [c.evaluate(frame) if c else obj.rotation_euler[i] for i, c in enumerate(rot_curves)]
        loc = [c.evaluate(frame) if c else obj.location[i] for i, c in enumerate(loc_curves)]
        scale = [c.evaluate(frame) if c else obj.scale[i] for i, c in enumerate(scale_curves)]

        # Reuses the same proven _to_pbd_matrix + decompose path every
        # other rotation in this file goes through, rather than a
        # hand-derived per-component remap of the raw Euler values - a
        # rotation's axis conversion isn't a simple component swap the
        # way a position's is, and getting that wrong by reasoning it out
        # under time pressure is exactly the mistake that caused this
        # project's earlier rotation composition bug (see applyInstanceField's
        # "rot" case on the engine side for that story).
        euler = mathutils.Euler((rot_rad[0], rot_rad[1], rot_rad[2]), 'XYZ')
        # `prefix` puts the pose in the same frame as the base pos=/rot=
        # written at the top of the instance (see _pose_prefix).
        local_matrix = prefix @ mathutils.Matrix.Translation(mathutils.Vector(loc)) @ euler.to_matrix().to_4x4()
        pbd_matrix = _to_pbd_matrix(local_matrix)
        pbd_loc, pbd_rot_quat, _ = pbd_matrix.decompose()
        pbd_loc = pbd_loc / parent_factor  # see _factors
        pbd_euler = _euler_near(pbd_rot_quat, previous_euler)
        previous_euler = pbd_euler
        pbd_rot_deg = [math.degrees(a) for a in pbd_euler]
        # Scale isn't part of local_matrix/_to_pbd_matrix above (that
        # path is for pos/rot only) - full TRS decomposition to convert
        # a scale between the two axis conventions is what caught this
        # project's own Y/Z swap bug in the import path once already
        # (see import_pbd.py's own comment on that), so the same
        # matrix-decompose approach is used here too rather than
        # reasoning per-component under time pressure again.
        scale_ratio = own_factor / parent_factor  # see _factors
        scale_matrix = _to_pbd_matrix(mathutils.Matrix.Diagonal(
            (scale[0] * scale_ratio, scale[1] * scale_ratio, scale[2] * scale_ratio, 1.0)))
        _, _, pbd_scale = scale_matrix.decompose()

        parts = [f"time={time:.4g}"]
        if channel_name:
            parts.append(f"channel={channel_name}")
        parts.append(f"pos={_format_vec3(pbd_loc)}")
        parts.append(f"rot={_format_vec3(pbd_rot_deg)}")
        if channel_name:
            parts.append(f"scale={_format_vec3(pbd_scale)}")
        sound_file = _sound_for_time(obj, time)
        if sound_file:
            parts.append(f"sound={_quote_token(sound_file)}")
        lines.append("  keyframe { " + " ".join(parts) + " }")
    return lines


def _sound_for_time(obj, time_seconds):
    """Matches the panel's own _find_sound_entry tolerance -
    looks up without creating, since export shouldn't add new empty
    entries for keyframes that never had a sound set."""
    for entry in obj.pbd.pbd_keyframe_sounds:
        if abs(entry.time - time_seconds) < 0.001 and entry.sound_file.strip():
            return os.path.basename(entry.sound_file)
    return None


def _export_mesh_vertex_data(mesh):
    """Encodes mesh's current triangulated geometry as base64, in
    EXACTLY the binary layout pbd.format.PbdMeshData.fromBase64 expects
    (see that class's own doc comment): int32 vertexCount, int32
    indexCount, per-vertex float32 x,y,z,nx,ny,nz,u,v (32 bytes), per-index
    int32, all little-endian. Takes a Mesh DATABLOCK directly (not an
    Object) - an LOD variant's geometry lives in one that was never
    linked to any Object at all (see PbdMeshLodEntry's own doc comment),
    so obj.data wouldn't reach it.

    One vertex per triangle CORNER (no sharing across triangles, matching
    mesh_preview.py's own "fine trade-off, keeps this simple" policy for
    procedural previews) - simpler than hashing (position,normal,uv)
    tuples to dedupe, and this format has no per-instance vertex-count
    budget that would make the extra few vertices matter."""
    import struct
    mesh.calc_loop_triangles()
    uv_layer = mesh.uv_layers.active.data if mesh.uv_layers.active else None

    positions = []
    normals = []
    uvs = []
    indices = []
    next_index = 0
    for tri in mesh.loop_triangles:
        for loop_index in tri.loops:
            loop = mesh.loops[loop_index]
            v = mesh.vertices[loop.vertex_index].co
            n = loop.normal  # per-loop (split) normal - respects sharp edges/autosmooth, unlike the vertex normal
            pv = _blender_to_pbd_mesh_vec(v)
            pn = _blender_to_pbd_mesh_vec(n)
            positions.append(pv)
            normals.append(pn)
            uvs.append(tuple(uv_layer[loop_index].uv) if uv_layer else (0.0, 0.0))
            indices.append(next_index)
            next_index += 1

    vertex_count = len(positions)
    buf = bytearray()
    buf += struct.pack('<ii', vertex_count, len(indices))
    for i in range(vertex_count):
        buf += struct.pack('<8f', *positions[i], *normals[i], *uvs[i])
    for idx in indices:
        buf += struct.pack('<i', idx)
    import base64
    return base64.b64encode(bytes(buf)).decode('ascii')


def _blender_to_pbd_mesh_vec(v):
    """Same Z-up -> Y-up remap as mesh_preview.py's _blender_to_pbd,
    applied to a raw mathutils Vector rather than a plain tuple - mesh
    vertex-level geometry needs the same axis convention every other
    part of this format already uses, or an embedded mesh would render
    sideways relative to everything else in the same scene."""
    return (v.x, v.z, -v.y)


def _serialize_lever_arm_lines(obj, prefix, closed_euler=None):
    """The `leverArm { }` block for obj (see the engine's PbdInstance.
    LeverArm), or [] when it has none - an alternative to
    _serialize_keyframes for a simple closed/open motion with no Blender
    timeline involved at all.

    The open pose goes through the exact same _to_pbd_matrix ->
    decompose pipeline as the instance's own base pos=/rot= (NOT a
    hand-derived per-component remap): getting the axis conversion wrong
    here independently would put the "closed" and "open" ends in two
    different coordinate conventions, which wouldn't fail loudly, just
    swing the door through some scrambled, wrong-looking motion. `prefix`
    (see _pose_prefix) and `closed_euler` (the base rotation, so the open
    rotation is the Euler nearest to it - a closed yaw of 100 deg opening
    to 190 deg must not be written as -170 deg) keep both ends in one
    frame and on one side of the +/-180 boundary.

    Everything that is not the default is written, nothing else, so a
    plain door exports exactly the three fields it always did."""
    if not obj.pbd.pbd_lever_arm_enabled:
        return []
    open_loc_blender = mathutils.Vector(obj.pbd.pbd_lever_arm_open_pos)
    open_euler_blender = mathutils.Euler(tuple(obj.pbd.pbd_lever_arm_open_rot), 'XYZ')
    open_local_matrix = (prefix @ mathutils.Matrix.Translation(open_loc_blender)
                         @ open_euler_blender.to_matrix().to_4x4())
    open_pbd_matrix = _to_pbd_matrix(open_local_matrix)
    open_loc, open_rot_quat, _ = open_pbd_matrix.decompose()
    open_loc = open_loc / _factors(obj)[1]  # see _factors
    open_rot_deg = [math.degrees(a) for a in _euler_near(open_rot_quat, closed_euler)]
    lines = ["  leverArm {"]
    lines.append(f"    openPos = {_format_vec3(open_loc)}")
    lines.append(f"    openRot = {_format_vec3(open_rot_deg)}")
    lines.append(f"    speed = {obj.pbd.pbd_lever_arm_speed:.4g}")
    if obj.pbd.pbd_lever_arm_release == 'free':
        lines.append("    release = free")
    if obj.pbd.pbd_lever_arm_locked:
        lines.append("    locked = true")
        if obj.pbd.pbd_lever_arm_lock_at > 1e-6:
            lines.append(f"    lockAt = {obj.pbd.pbd_lever_arm_lock_at:.4g}")
    open_sound = os.path.basename(obj.pbd.pbd_lever_arm_open_sound.strip())
    if open_sound:
        lines.append(f"    openSound = {_quote_token(open_sound)}")
    close_sound = os.path.basename(obj.pbd.pbd_lever_arm_close_sound.strip())
    if close_sound:
        lines.append(f"    closeSound = {_quote_token(close_sound)}")
    lines.append("  }")
    return lines


def _check_names(context, tagged):
    """Warnings for material names the file cannot hold. An instance id is
    cleaned up silently (_pbd_id): it is only ever a label other lines
    point at. A material name is matched against the .pbdmat file and the
    shared library by its exact spelling, so it is reported instead of
    rewritten - rename it (letters, digits, _ - . only is always safe)."""
    msgs = []
    def bad(name):
        return bool(name) and bool(_ID_UNSAFE.search(name))
    for obj in tagged:
        for name in (obj.pbd.pbd_material if obj.pbd.pbd_type not in ('ref', 'light', 'group') else "",
                     obj.pbd.pbd_ref_mat_override.strip() if obj.pbd.pbd_type == 'ref' else ""):
            if bad(name):
                msgs.append(f"'{obj.name}': the material name '{name}' holds a space or one of {{ }} ( ) [ ] = , # \" - "
                            f"the file will not load; rename the material")
    for entry in context.scene.pbd_materials:
        if bad(entry.name):
            msgs.append(f"material '{entry.name}' (in the PBD Materials list): its name holds a space or one of "
                        f"{{ }} ( ) [ ] = , # \" - the file will not load; rename it")
    return msgs


def _check_motion_setup(obj):
    """Warnings (a list of strings, usually empty) for the things an
    artist can set up that the engine will silently not do what they
    expect with. Reported next to the canonical-mesh check, in the
    exported file's header and in Blender's own report area."""
    msgs = []
    pbd = obj.pbd
    if pbd.pbd_lever_arm_enabled:
        if pbd.pbd_type in ('ref', 'light'):
            msgs.append(f"'{obj.name}': a {pbd.pbd_type} cannot carry a Lever Arm "
                        f"(it is not exported) - put it on a Pivot and parent this object to the pivot")
        else:
            same_pos = (mathutils.Vector(pbd.pbd_lever_arm_open_pos) - obj.location).length < 1e-5
            same_rot = all(abs(a - b) < 1e-5 for a, b in zip(pbd.pbd_lever_arm_open_rot, obj.rotation_euler))
            if same_pos and same_rot:
                msgs.append(f"'{obj.name}': the Lever Arm's open pose equals its current (closed) pose - "
                            f"nothing will move; pose it open and click Capture Current Pose as Open")
            if anim_compat.get_object_fcurves(obj):
                msgs.append(f"'{obj.name}': has both keyframes and a Lever Arm - the engine "
                            f"plays the keyframes and ignores the arm")
    if pbd.pbd_type == 'group' and any(abs(s - 1.0) > 1e-4 for s in obj.scale):
        msgs.append(f"'{obj.name}': a pivot's scale is {tuple(round(s, 3) for s in obj.scale)}, not 1 - "
                    f"everything parented to it inherits that scale (in Blender and in the engine)")
    if pbd.pbd_type == 'ref' and pbd.pbd_indestructible:
        msgs.append(f"'{obj.name}': Indestructible is not exported for a pbd_ref (the engine's pbd_ref "
                    f"block has no such field and would refuse the file) - set it on the referenced "
                    f"file's own objects")
    return msgs


def _serialize_instance(obj):
    # Root -> matrix_world (absolute position); PBD child -> matrix_local
    # (already relative to the parent, Blender's matrix_parent_inverse included).
    has_pbd_parent = _pbd_parent_of(obj) is not None
    matrix = obj.matrix_local if has_pbd_parent else obj.matrix_world
    pbd_matrix = _to_pbd_matrix(matrix)
    loc, rot_quat, scale = pbd_matrix.decompose()
    closed_euler = rot_quat.to_euler('XYZ')
    euler_deg = [math.degrees(a) for a in closed_euler]
    prefix = _pose_prefix(obj, matrix)  # for the poses read from properties (keyframes, lever arm) - see _pose_prefix
    # The x2 of a canonical shape (see _BLENDER_TO_SHADER_SCALE), relative to
    # what the parent already carries (see _factors). Replaces the old
    # per-branch "scale_factor": 'mesh', 'ref', 'group' and 'light' have
    # their own factor 1, every other type 2.
    own_factor, parent_factor = _factors(obj)
    loc = loc / parent_factor
    scale = [s * own_factor / parent_factor for s in scale]

    if obj.pbd.pbd_type == 'ref':
        # No `_BLENDER_TO_SHADER_SCALE` compensation here - a ref isn't a
        # native-2x2x2-sized mesh, its scale is a plain multiplier on
        # whatever the referenced file's own content already is, so it
        # should pass straight through, not be silently doubled.
        lines = [f"pbd_ref {_pbd_id(obj)} {{"]
        # Quoted when it has a space (a Windows folder called "My Assets",
        # say): a bare value stops at the first one, and the engine would
        # then read the rest of the path as a field name.
        lines.append(f"  source = {_quote_if_needed(obj.pbd.pbd_ref_source)}")
        if obj.pbd.pbd_ref_fallback.strip():
            lines.append(f"  fallback = {_quote_if_needed(obj.pbd.pbd_ref_fallback.strip())}")
        if obj.pbd.pbd_ref_mat_override.strip():
            lines.append(f"  mat    = {_quote_if_needed(obj.pbd.pbd_ref_mat_override.strip())}")
        lines.append(f"  pos    = {_format_vec3(loc)}")
        if any(abs(a) > 1e-4 for a in euler_deg):
            lines.append(f"  rot    = {_format_vec3(euler_deg)}")
        if any(abs(s - 1.0) > 1e-4 for s in scale):
            lines.append(f"  scale  = {_format_vec3(list(scale))}")
        if has_pbd_parent:
            lines.append(f"  parent = {_pbd_id(obj.parent)}")
        if obj.pbd.pbd_lod_enabled:
            lines.append(f"  lod    = {obj.pbd.pbd_lod}")
        if obj.pbd.pbd_category:
            lines.append(f"  category = {_quote_if_needed(obj.pbd.pbd_category)}")
        # indestructible/hardness/resistance are deliberately NOT written:
        # PbdParser.parsePbdRef knows no such field and refuses the whole
        # file with "Unknown pbd_ref field" (_check_motion_setup warns).
        lines.append("}")
        return "\n".join(lines)

    if obj.pbd.pbd_type == 'group':
        # A pivot (see OBJECT_OT_add_pbd_group): the engine's zero-geometry
        # `group` instance - a transform other instances are parented to,
        # most usefully a door's hinge carrying the lever arm. No mat=, and
        # no _BLENDER_TO_SHADER_SCALE compensation for the same reason
        # 'ref' has none above: there is no native 2x2x2 mesh behind it, its
        # scale is passed through as-is (and inherited by its children).
        lines = [f"group {_pbd_id(obj)} {{"]
        lines.append(f"  pos   = {_format_vec3(loc)}")
        if any(abs(a) > 1e-4 for a in euler_deg):
            lines.append(f"  rot   = {_format_vec3(euler_deg)}")
        lines.append(f"  scale = {_format_vec3(list(scale))}")
        if has_pbd_parent:
            lines.append(f"  parent = {_pbd_id(obj.parent)}")
        if obj.pbd.pbd_lod_enabled:
            lines.append(f"  lod   = {obj.pbd.pbd_lod}")
        if obj.pbd.pbd_category:
            lines.append(f"  category = {_quote_if_needed(obj.pbd.pbd_category)}")
        lines.extend(_serialize_keyframes(obj, prefix))
        lines.extend(_serialize_lever_arm_lines(obj, prefix, closed_euler))
        if obj.pbd.pbd_link_group:
            lines.append(f"  linkGroup = {_quote_if_needed(obj.pbd.pbd_link_group)}")
        if obj.pbd.pbd_loop_animation:
            lines.append("  loop = true")
        lines.append("}")
        return "\n".join(lines)

    if obj.pbd.pbd_type == 'light':
        # Same "no _BLENDER_TO_SHADER_SCALE, no mat=" reasoning as 'ref'
        # just above - a light isn't a native-2x2x2 shape either, and
        # has no material of its own to shade (it emits, doesn't
        # receive).
        lines = [f"light {_pbd_id(obj)} {{"]
        lines.append(f"  pos    = {_format_vec3(loc)}")
        if any(abs(a) > 1e-4 for a in euler_deg):
            lines.append(f"  rot    = {_format_vec3(euler_deg)}")
        if has_pbd_parent:
            lines.append(f"  parent = {_pbd_id(obj.parent)}")
        lines.append(f"  lightMode = {obj.pbd.pbd_light_mode}")
        if not obj.pbd.pbd_light_enabled:
            lines.append("  lightEnabled = false")
        lines.append(f"  lightColor = {_format_vec3(list(obj.pbd.pbd_light_color))}")
        lines.append(f"  lightIntensity = {obj.pbd.pbd_light_intensity:.4g}")
        lines.append(f"  lightRange = {obj.pbd.pbd_light_range:.4g}")
        if obj.pbd.pbd_light_mode == 'spot':
            lines.append(f"  lightSpotAngle = {math.degrees(obj.pbd.pbd_light_spot_angle):.4g}")
        if obj.pbd.pbd_category:
            lines.append(f"  category = {_quote_if_needed(obj.pbd.pbd_category)}")
        lines.append("}")
        return "\n".join(lines)

    lines = [f"{obj.pbd.pbd_type} {_pbd_id(obj)} {{"]
    lines.append(f"  pos   = {_format_vec3(loc)}")
    if any(abs(a) > 1e-4 for a in euler_deg):
        lines.append(f"  rot   = {_format_vec3(euler_deg)}")
    # "mesh" skips the x2 compensation for the same reason "ref" does
    # (see that branch above, which returns before reaching here): the
    # canonical-primitive-at-native-2x-size assumption this factor
    # corrects for doesn't apply to arbitrary embedded geometry, which
    # was already exported at its own real, unmodified local scale. That
    # is _shape_factor's job now, applied once at the top of this function.
    lines.append(f"  scale = {_format_vec3(scale)}")
    if has_pbd_parent:
        lines.append(f"  parent = {_pbd_id(obj.parent)}")
    if obj.pbd.pbd_lod_enabled:
        lines.append(f"  lod   = {obj.pbd.pbd_lod}")
    if obj.pbd.pbd_category:
        lines.append(f"  category = {_quote_if_needed(obj.pbd.pbd_category)}")
    if obj.pbd.pbd_indestructible:
        lines.append("  indestructible = true")
        lines.append(f"  hardness = {obj.pbd.pbd_hardness:.4g}")
        lines.append(f"  resistance = {obj.pbd.pbd_resistance:.4g}")
    lines.append(f"  mat   = {obj.pbd.pbd_material}")
    if obj.pbd.pbd_type in ('cylinder', 'cone') and obj.pbd.pbd_cap != 'both':
        lines.append(f"  cap   = {obj.pbd.pbd_cap}")
    if obj.pbd.pbd_type == 'cube':
        sx, sy, sz = obj.pbd.pbd_cube_smooth_x, obj.pbd.pbd_cube_smooth_y, obj.pbd.pbd_cube_smooth_z
        if max(sx, sy, sz) > 0.001:
            lines.append(f"  smoothX = {sx:.4g}")
            lines.append(f"  smoothY = {sy:.4g}")
            lines.append(f"  smoothZ = {sz:.4g}")
        removed_codes = _removed_face_codes(obj.pbd)
        if removed_codes:
            lines.append(f"  faces = ({','.join(removed_codes)})")
    if obj.pbd.pbd_type == 'mesh':
        encoded = _export_mesh_vertex_data(obj.data)
        lines.append(f'  vertexData = "base64:{encoded}"')
        for entry in obj.pbd.pbd_mesh_lod_sources:
            if entry.mesh_data is None:
                continue
            lod_encoded = _export_mesh_vertex_data(entry.mesh_data)  # this LOD tier's own stored shape, not obj's current one
            lines.append(f'  vertexDataLod{entry.lod} = "base64:{lod_encoded}"')
    if obj.pbd.pbd_bend_enabled:
        # pbd_bend_angle is stored/returned in radians (subtype='ANGLE') -
        # the .pbd format's modifier fields are in degrees, matching `rot=`.
        lines.append("  modifier bend { axis=%s angle=%.4g }" % (
            obj.pbd.pbd_bend_axis.lower(), math.degrees(obj.pbd.pbd_bend_angle)))
    if obj.pbd.pbd_shear_enabled:
        lines.append("  modifier shear { factorX=%.4g factorY=%.4g factorZ=%.4g }" % (
            obj.pbd.pbd_shear_factor_x, obj.pbd.pbd_shear_factor_y, obj.pbd.pbd_shear_factor_z))
    if obj.pbd.pbd_taper_enabled:
        lines.append("  modifier taper { bottomScale=%.4g topScale=%.4g }" % (
            obj.pbd.pbd_taper_bottom_scale, obj.pbd.pbd_taper_top_scale))
    lines.extend(_serialize_keyframes(obj, prefix))
    lines.extend(_serialize_lever_arm_lines(obj, prefix, closed_euler))
    if obj.pbd.pbd_link_group:
        lines.append(f"  linkGroup = {_quote_if_needed(obj.pbd.pbd_link_group)}")
    if obj.pbd.pbd_metadata:
        lines.append("  metadata = true")
        for entry in obj.pbd.pbd_linked_doors:
            if entry.door:
                lines.append(f"  containerTrigger = {_pbd_id(entry.door)}")
    if obj.pbd.pbd_loop_animation:
        lines.append("  loop = true")
    # Channel-mode keyframes (see _serialize_keyframes) already carry
    # channel=/scale= per keyframe when obj.pbd.pbd_channel_name is set -
    # nothing extra needed on the instance block itself.
    lines.append("}")
    return "\n".join(lines)


def _write_pbdmat(context, pbd_filepath):
    """Writes EMBEDDED-source entries from scene.pbd_materials to <same
    base name>.pbdmat next to the .pbd file. SHARED-source entries are
    skipped here entirely - they're not duplicated into a per-scene
    file, they get their own include_material line pointing straight at
    the project-wide materials/NAME.pbdmat instead (see material_source
    on PbdMaterialEntry). Returns a list of include_material targets (0
    or more) - a completely empty catalog, or one where every entry is
    shared, are both normal cases, not errors.
    """
    embedded = [e for e in context.scene.pbd_materials if e.material_source == 'EMBEDDED']
    shared = [e for e in context.scene.pbd_materials if e.material_source == 'SHARED']

    includes = []

    if embedded:
        base, _ = os.path.splitext(pbd_filepath)
        mat_filepath = base + ".pbdmat"
        lines = []
        # Same author(s) as the .pbd's own File metadata box, written
        # automatically - a .pbdmat can be included by OTHER scenes too
        # (include_material doesn't care which .pbd first wrote it), so
        # it needs its own attribution rather than relying on whichever
        # .pbd happens to sit next to it at the moment - see
        # PbdMatParser's own doc for why this is required, not merely
        # optional, the way it is on the .pbd side.
        for author in context.scene.pbd_scene_authors.split(","):
            author = author.strip()
            if author:
                lines.append(f"author = {_quote_if_needed(author)}")
        if lines:
            lines.append("")
        for entry in embedded:
            lines.append(f"material {entry.name} {{")
            lines.append("  color     = (%.4g, %.4g, %.4g)" % tuple(entry.color))
            lines.append(f"  shininess = {entry.shininess:.4g}")
            lines.append(f"  specular  = {entry.specular:.4g}")
            if entry.texture_path:
                lines.append(f"  texture   = {os.path.basename(entry.texture_path)}")
                if abs(entry.uv_scale_u - 1.0) > 0.001 or abs(entry.uv_scale_v - 1.0) > 0.001:
                    if abs(entry.uv_scale_u - entry.uv_scale_v) < 0.001:
                        lines.append(f"  uvScale   = {entry.uv_scale_u:.4g}")  # both axes match - the shorter, backward-compatible single-value form
                    else:
                        lines.append(f"  uvScaleU  = {entry.uv_scale_u:.4g}")
                        lines.append(f"  uvScaleV  = {entry.uv_scale_v:.4g}")
            if entry.normal_map_path:
                lines.append(f"  normalMap = {os.path.basename(entry.normal_map_path)}")
            if entry.roughness_map_path:
                lines.append(f"  roughnessMap = {os.path.basename(entry.roughness_map_path)}")
            if entry.displacement_map_path:
                lines.append(f"  displacementMap = {os.path.basename(entry.displacement_map_path)}")
                lines.append(f"  displacementScale = {entry.displacement_scale:.4g}")
            if entry.reflectivity > 0.001:
                lines.append(f"  reflectivity = {entry.reflectivity:.4g}")
            if entry.transparency > 0.001:
                lines.append(f"  transparency = {entry.transparency:.4g}")
            lines.append("}")
            lines.append("")
        with open(mat_filepath, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))
        includes.append(os.path.basename(mat_filepath))

    if shared:
        materials_dir = _resolve_materials_dir(context)
        pbd_dir = os.path.dirname(os.path.abspath(pbd_filepath))
        for entry in shared:
            shared_path = os.path.join(materials_dir, f"{entry.name}.pbdmat")
            if not os.path.exists(shared_path):
                # Not fatal - the exported .pbd just won't find this
                # material until the file shows up (a scrape/conversion
                # run away from finishing, say) - report it rather than
                # silently reference a path that doesn't resolve.
                print(f"[PBD export] WARNING: shared material '{entry.name}' not found at {shared_path}")
            rel = os.path.relpath(shared_path, pbd_dir)
            includes.append(rel.replace(os.sep, "/"))

    return includes


def _find_gradle_root_from(start_path):
    """Walks up from start_path (a file or directory) looking for
    build.gradle.kts. Replaces pbd_project_root, a separate persistent
    setting the user had to configure by hand and could easily point at
    the wrong place (the add-on's own install folder rather than the
    actual Gradle project - which is exactly what happened). Derived
    instead from wherever the user actually chooses to save/browse each
    time, via Blender's own file browser - which already remembers the
    last-used directory per operator across sessions on its own, so
    repeat exports into the same project don't need a separately-
    remembered setting to stay convenient."""
    current = os.path.abspath(start_path)
    if not os.path.isdir(current):
        current = os.path.dirname(current)
    for _ in range(25):  # bounded - a symlink loop or similar shouldn't spin forever
        if os.path.isfile(os.path.join(current, "build.gradle.kts")):
            return current
        parent = os.path.dirname(current)
        if parent == current:  # reached the filesystem root
            return None
        current = parent
    return None


def _find_gradle_root_with_blend_fallback(chosen_path):
    """_find_gradle_root_from(chosen_path), falling back to walking up
    from THIS .blend file's own saved location if that comes up empty -
    covers the common case of a .blend kept inside the project while
    its content gets exported somewhere else entirely (a separate
    'model' or 'assets' folder outside the Gradle project, say):
    without this, that's a hard failure with nothing to do but move the
    export inside the project after all, even though the actual answer
    (which project this belongs to) was sitting right there in
    bpy.data.filepath the whole time. Returns None if neither works,
    same as _find_gradle_root_from alone."""
    root = _find_gradle_root_from(chosen_path)
    if root is not None:
        return root
    if bpy.data.filepath:
        return _find_gradle_root_from(bpy.data.filepath)
    return None


def _resolve_materials_dir(context):
    """scene.pbd_materials_folder if set (a dedicated setting,
    independent of anything else - see materials.py's register()),
    else a best-effort guess relative to this .py file's own location,
    which only works if the add-on happens to be installed from inside a
    checkout of this project rather than Blender's own separate add-ons
    folder (the normal case). In the checkout this file is
    tools/blender-addon/pbd_tools/pbd_tools/operators/export_pbd.py, so the
    project root is FIVE folders up from the folder it sits in (it was four,
    counted for a layout one folder shallower, and landed in
    tools/src/main/resources/materials, which does not exist)."""
    if context.scene.pbd_materials_folder:
        return context.scene.pbd_materials_folder
    return os.path.normpath(os.path.join(os.path.dirname(__file__), "..", "..", "..", "..", "..",
                                          "src", "main", "resources", "materials"))


def _is_url(text):
    return text.strip().lower().startswith(('http://', 'https://'))


def _rebase_reference(ref, origin, export_dir):
    """A relative file reference found INSIDE an embedded file (a nested
    pbd_ref's source=, an include_material), rewritten so it still points
    at the same file from the exported file's own folder. `origin` is where
    the embedded file itself was read from: a local folder, a URL (then the
    reference is resolved against it like any relative URL), or None when
    that is unknown - the reference is then left as it was. URLs and
    absolute references need nothing."""
    if _is_url(ref) or origin is None:
        return ref
    kind, where = origin
    if kind == 'url':
        from urllib.parse import urljoin
        return urljoin(where, ref)
    absolute = os.path.normpath(os.path.join(where, ref))
    if export_dir is None:
        return absolute.replace(os.sep, '/')
    try:
        return os.path.relpath(absolute, export_dir).replace(os.sep, '/')
    except ValueError:  # another drive on Windows - no relative path exists
        return absolute.replace(os.sep, '/')


def _resolve_embed_source(source, export_dir):
    """(text_file_path, origin, note) for a pbd_ref's source=, or
    (None, None, why) when it cannot be read. Understands all three file
    formats and a URL (import_pbd._resolve_pbd_source does the unwrapping),
    and a local path relative to the .blend OR the exported file - the two
    places an artist is likely to have meant."""
    from . import import_pbd
    raw = source.strip()
    if not raw:
        return None, None, "no source set"
    try:
        if _is_url(raw):
            path, _base, _warn = import_pbd._resolve_pbd_source(raw, None, bpy.context)
            return path, ('url', raw), None
        candidates = [bpy.path.abspath(raw)]
        if export_dir:
            candidates.append(os.path.join(export_dir, raw))
        for candidate in candidates:
            if os.path.isfile(candidate):
                path, base_dir, _warn = import_pbd._resolve_pbd_source(candidate, None, bpy.context)
                note = None
                if candidate.lower().endswith('.pbdasset'):
                    note = ("the materials bundled inside a .pbdasset are not carried over by embedding - "
                            "use a normal pbd_ref, or include its .pbdmat yourself")
                    base_dir = None
                return path, (('dir', base_dir) if base_dir else None), note
        return None, None, f"not found: {candidates[0]}"
    except Exception as e:
        return None, None, str(e)


def _keyframe_dict_line(kf):
    """One `keyframe { }` line from a keyframe parsed by import_pbd's
    _keyframe_from_fields - every field the format has (the old embed
    wrote time/pos/rot only and dropped scale, channel and sound)."""
    parts = [f"time={kf['time']:.6g}"]
    if kf.get('channel'):
        parts.append(f"channel={kf['channel']}")
    if kf.get('pos') is not None:
        parts.append(f"pos={_format_vec3(kf['pos'])}")
    if kf.get('rot') is not None:
        parts.append(f"rot={_format_vec3(kf['rot'])}")
    if kf.get('scale') is not None:
        parts.append(f"scale={_format_vec3(kf['scale'])}")
    if kf.get('sound'):
        parts.append(f"sound={_quote_token(kf['sound'])}")
    return f"  keyframe {{ {' '.join(parts)} }}"


def _lever_arm_dict_lines(arm):
    """The `leverArm { }` block of an instance parsed by import_pbd
    (_lever_arm_from_fields), all of its fields - the parsed-dict twin of
    _serialize_lever_arm_lines (which works from a Blender object). Its
    sounds are file names, not ids inside the embedded file, so nothing
    here is prefixed."""
    lines = ["  leverArm {"]
    if arm.get('openPos') is not None:
        lines.append(f"    openPos = {_format_vec3(arm['openPos'])}")
    if arm.get('openRot') is not None:
        lines.append(f"    openRot = {_format_vec3(arm['openRot'])}")
    lines.append(f"    speed = {arm.get('speed', 1.0):.6g}")
    if arm.get('release') == 'free':
        lines.append("    release = free")
    if arm.get('locked'):
        lines.append("    locked = true")
    if arm.get('lockAt'):
        lines.append(f"    lockAt = {arm['lockAt']:.6g}")
    if arm.get('openSound'):
        lines.append(f"    openSound = {_quote_token(arm['openSound'])}")
    if arm.get('closeSound'):
        lines.append(f"    closeSound = {_quote_token(arm['closeSound'])}")
    lines.append("  }")
    return lines


def _embedded_field_value(key, value):
    """A parsed field value (its quotes were stripped by the reader) back
    into text: a tuple stays as it is, vertexData keeps the quotes the
    exporter always gives it, anything else is quoted when it has a space
    (a category like "wall panel" would otherwise end at "wall")."""
    if key.startswith('vertexData'):
        return f'"{value}"'
    if value.startswith('(') and value.endswith(')'):
        return value
    return _quote_if_needed(value)


def _serialize_embedded_ref(obj, export_dir=None, includes_out=None):
    """Embeds a referenced file's instances directly into this export
    instead of a pbd_ref pointing externally at it - and does it the way
    the engine's own inlining does (PbdParser.parsePbdRef), so the two
    produce the same scene:

      * a zero-geometry `group` carrying this object's own transform
        stands for the reference (it used to be a metadata cube, which
        the engine also reads as a container volume);
      * every instance of the referenced file is copied in with its id
        prefixed `<this object's name>.` - two embeds of the same file
        cannot collide, which unprefixed ids made a hard "Duplicate
        instance id" error - and its roots are parented to the group,
        deeper ones keep their (prefixed) parent;
      * every id-valued reference follows the prefix: containerTrigger
        and linkGroup (so two placements of one wardrobe do not open
        together);
      * a mat= on this object overrides every copy's material;
      * all of an instance's fields travel - modifiers, keyframes with
        their scale/channel/sound, the whole leverArm (release, lock,
        sounds), lights, meshes, indestructible - not just a hand-picked
        subset (the old copy dropped the lever arm and half of each
        keyframe);
      * the referenced file's include_material lines are handed back
        through `includes_out` (relative to `export_dir`), so the copied
        instances keep their materials, and nested pbd_ref sources are
        rebased the same way.

    The engine's hierarchy composition does the placement itself, so
    nothing here composes a matrix."""
    from . import import_pbd

    has_parent = _pbd_parent_of(obj) is not None
    pbd_matrix = _to_pbd_matrix(_base_matrix(obj))
    loc, rot_quat, scale = pbd_matrix.decompose()
    euler_deg = [math.degrees(a) for a in rot_quat.to_euler('XYZ')]
    _own, parent_factor = _factors(obj)  # the anchor is a group (own factor 1) - see _factors
    loc = loc / parent_factor
    scale = [s / parent_factor for s in scale]

    anchor_name = _pbd_id(obj)
    lines = [f"group {anchor_name} {{"]
    lines.append(f"  pos    = {_format_vec3(loc)}")
    if any(abs(a) > 1e-4 for a in euler_deg):
        lines.append(f"  rot    = {_format_vec3(euler_deg)}")
    lines.append(f"  scale  = {_format_vec3(list(scale))}")
    if has_parent:
        lines.append(f"  parent = {_pbd_id(obj.parent)}")
    if obj.pbd.pbd_lod_enabled:
        lines.append(f"  lod    = {obj.pbd.pbd_lod}")
    if obj.pbd.pbd_category:
        lines.append(f"  category = {_quote_if_needed(obj.pbd.pbd_category)}")
    lines.append("}")

    source_path, origin, note = _resolve_embed_source(obj.pbd.pbd_ref_source, export_dir)
    if source_path is None:
        lines.append(f"# WARNING: embed source '{obj.pbd.pbd_ref_source}' unreadable at export time: {note}")
        return "\n".join(lines)
    if note:
        lines.append(f"# WARNING: {note}")

    try:
        scene_meta, _last_include, instances = import_pbd.parse_pbd_file(source_path)
    except Exception as e:
        lines.append(f"# WARNING: failed to read embed source '{obj.pbd.pbd_ref_source}': {e}")
        return "\n".join(lines)

    if includes_out is not None and origin is not None:
        for include in scene_meta.get('include_materials', []):
            includes_out.append(_rebase_reference(include, origin, export_dir))

    prefix = anchor_name + "."
    mat_override = obj.pbd.pbd_ref_mat_override.strip()
    for inst in instances:
        block = [f"{inst['type']} {prefix}{inst['id']} {{"]
        fields = inst['fields']
        for key, value in fields.items():
            if key in ('parent', 'linkGroup'):
                continue  # rewritten below
            if key == 'mat' and mat_override:
                continue  # replaced below
            if key == 'source' and inst['type'] in ('pbd_ref', 'ref', 'group'):
                value = _rebase_reference(value, origin, export_dir)  # a nested reference's path was relative to the EMBEDDED file
            block.append(f"  {key} = {_embedded_field_value(key, value)}")
        if mat_override and inst['type'] not in ('light', 'group'):
            block.append(f"  mat = {_quote_if_needed(mat_override)}")
        parent_id = fields.get('parent')
        block.append(f"  parent = {prefix + parent_id if parent_id else anchor_name}")
        if 'linkGroup' in fields:
            block.append(f"  linkGroup = {_quote_if_needed(prefix + fields['linkGroup'])}")
        for trigger in inst.get('containerTriggers', []):
            block.append(f"  containerTrigger = {prefix}{trigger}")
        for mod in inst['modifiers']:
            params_str = " ".join(f"{k}={v}" for k, v in mod['params'].items())
            block.append(f"  modifier {mod['type']} {{ {params_str} }}")
        for kf in inst['keyframes']:
            block.append(_keyframe_dict_line(kf))
        if inst.get('leverArm'):
            block.extend(_lever_arm_dict_lines(inst['leverArm']))
        block.append("}")
        lines.append("\n".join(block))

    return "\n".join(lines)


def _minify_pbd_text(text):
    """Mirrors PbdSerializer.java's pretty/minified distinction for this
    add-on's own independent Python export (it builds pretty text
    directly and never goes through the Java serializer at all) - every
    separator trimmed to the minimum PbdParser can still read
    unambiguously: no indentation, fields space- rather than
    newline-separated, comment lines dropped entirely (PbdParser's
    skipWhitespaceAndComments treats them as nothing regardless, so they
    only add size, never meaning, to a minified file).

    Works line-by-line against export_pbd.py's own consistent, known
    output shape (a block-opener line ending in "{", a bare "}" closer,
    an ordinary "  key = value" field line, or an already-compact
    "keyframe { ... }" line whose own internal fields use a bare "="
    with no spaces, distinguishing it from an ordinary field line here)
    rather than attempting a general-purpose reformatter - this only
    ever needs to handle what THIS module itself writes, not arbitrary
    hand-authored .pbd text.
    """
    out_tokens = []
    for raw_line in text.split("\n"):
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.endswith("{") or line == "}":
            out_tokens.append(line)
        elif " = " in line:
            key, _, value = line.partition(" = ")
            key = key.rstrip()  # pretty-formatting pads keys for column alignment ("pos   = ..."), which partition on " = " leaves attached to the key otherwise - not wrong to parse (readIdentifier stops at the first space either way) but not actually minimal either
            value = value.lstrip()
            # Collapse ", " -> "," inside a parenthesized tuple value
            # (pos/scale/rot/faces all use this shape), matching
            # PbdSerializer's own minified vec3 formatting.
            if value.startswith("("):
                value = value.replace(", ", ",")
            out_tokens.append(f"{key}={value}")
        else:
            # Already-compact lines pass through unchanged: a
            # "keyframe { time=0 sound=foo.wav }" block (its own fields
            # use bare "=", never " = ", specifically so this branch
            # catches it), "pbd_version 1", "include_material foo.pbdmat".
            out_tokens.append(line)
    return " ".join(out_tokens) + "\n"


def export_scene_to_pbd(context, filepath):
    # Everything below reads matrix_world / matrix_local / dimensions, which
    # come from Blender's depsgraph - and a plain Python assignment does not
    # refresh it (the interface does, between two clicks). Without this, a
    # script that built or changed objects and exported straight away got the
    # positions of before the change; this makes the export right whoever calls it.
    context.view_layer.update()
    tagged = [obj for obj in context.scene.objects
              if getattr(obj, "pbd", None) and obj.pbd.is_pbd_primitive]
    # No longer any need to exclude LOD-source objects from this list -
    # an LOD variant's geometry now lives in a Mesh datablock stored
    # directly on the entry (see PbdMeshLodEntry), never as a second
    # Object in the scene at all, so there is nothing here that could
    # double-count it.
    if not tagged:
        return 0, [], 0

    _ids.clear()
    _ids.update(_assign_ids([obj.name for obj in tagged]))

    warnings = [msg for obj in tagged if not obj.pbd.pbd_shear_enabled and obj.pbd.pbd_type not in ('ref', 'light', 'group')
                for msg in [_check_mesh_matches_canonical(obj)] if msg]
    for obj in tagged:
        warnings.extend(_check_motion_setup(obj))
    warnings.extend(_check_names(context, tagged))
    for obj in tagged:
        if _ids[obj.name] != obj.name:
            warnings.append(f"'{obj.name}' is written as '{_ids[obj.name]}': a name in the file cannot hold a space "
                            f"or any of {{ }} ( ) [ ] = , # \" (the object keeps its name in Blender)")

    # Parents must appear before their children - the .pbd parser knows
    # how to re-sort them (PbdScene.resolveHierarchy), but an already-
    # ordered export stays more readable by hand.
    ordered = []
    seen = set()

    def visit(obj):
        if obj.name in seen:
            return
        parent = _pbd_parent_of(obj)
        if parent is not None:
            visit(parent)
        seen.add(obj.name)
        ordered.append(obj)

    for obj in tagged:
        visit(obj)

    export_dir = os.path.dirname(os.path.abspath(filepath))
    embed_includes = []  # include_material lines the embedded files bring with them
    blocks = []
    for obj in ordered:
        if obj.pbd.pbd_type == 'ref' and obj.pbd.pbd_ref_embed and obj.pbd.pbd_ref_source:
            blocks.append(_serialize_embedded_ref(obj, export_dir, embed_includes))
        else:
            blocks.append(_serialize_instance(obj))
    keyframe_count = sum(block.count("keyframe {") for block in blocks)

    mat_includes = list(_write_pbdmat(context, filepath))
    for include in embed_includes:
        if include not in mat_includes:
            mat_includes.append(include)

    # Decided BEFORE the header is built, not after: every metadata
    # field below must know now whether minified output is coming, since
    # that - not whether the value happens to contain a space - is what
    # decides whether it needs quoting (_quote_metadata_value's own doc).
    minify = bool(getattr(context.scene, "pbd_export_minify", False))

    header = "pbd_version 1\n"
    # File-level metadata (PbdScene.java's own name/kind/authors/origin)
    # - describes the FILE as a whole, so read from the SCENE, not from
    # any one object, and written once here rather than per-instance.
    name = _metadata_text(context.scene.pbd_scene_name)
    if name:
        header += f'name = {_quote_metadata_value(name, minify)}\n'
    kind = _metadata_text(context.scene.pbd_scene_kind)
    if kind:
        header += f'kind = {_quote_metadata_value(kind, minify)}\n'
    for author in context.scene.pbd_scene_authors.split(","):
        author = _metadata_text(author)
        if author:
            header += f'author = {_quote_metadata_value(author, minify)}\n'
    origin = _metadata_text(context.scene.pbd_scene_origin)
    if origin:
        header += f'origin = {_quote_metadata_value(origin, minify)}\n'
    description = _metadata_text(context.scene.pbd_scene_description)
    if description:
        header += f'description = {_quote_metadata_value(description, minify)}\n'
    for include in mat_includes:
        header += f"include_material {_quote_if_needed(include)}\n"  # quoted when a folder name has a space (an embedded file's include can come from anywhere)
    # Extra include_material lines from PbdIncludeMaterialSource entries
    # - see that class's own doc for why this exists as a third
    # mechanism alongside EMBEDDED/SHARED material_source above. Quoted
    # (unlike mat_includes' own entries, which are always a locally-
    # computed relative path with no spaces) since these come straight
    # from whatever the user typed or picked in IMPORT_OT_pbdmat's own
    # Include-mode dialog - a URL or a hand-typed path is less
    # controlled input than a path this add-on computed itself.
    for src in context.scene.pbd_include_material_sources:
        if src.path.strip():
            header += f'include_material {_quote_if_needed(src.path.strip())}\n'
    if warnings:
        header += "\n# WARNING - please check before using this file:\n"
        for msg in warnings:
            header += f"#   {msg}\n"
    text = header + "\n" + "\n\n".join(blocks) + "\n"
    if getattr(context.scene, "pbd_export_minify", False):
        text = _minify_pbd_text(text)

    with open(filepath, "w", encoding="utf-8") as f:
        f.write(text)

    return len(ordered), warnings, keyframe_count


class EXPORT_OT_pbd(bpy.types.Operator, ExportHelper):
    """Exports the scene's PBD-tagged objects to a .pbd file"""

    bl_idname = "export_scene.pbd"
    bl_label = "Export PBD"
    filename_ext = ".pbd"

    filter_glob: bpy.props.StringProperty(default="*.pbd", options={'HIDDEN'})

    def execute(self, context):
        count, warnings, keyframe_count = export_scene_to_pbd(context, self.filepath)
        if count == 0:
            self.report({'WARNING'}, "No PBD-tagged object in the scene")
            return {'CANCELLED'}
        for msg in warnings:
            self.report({'WARNING'}, msg)
        suffix = f" - {len(warnings)} warning(s) above" if warnings else ""
        # Says explicitly when zero keyframes were found, rather than
        # just going quiet about animation - if an object was keyframed
        # in Blender but this reads 0, that's the direct signal something
        # about reading its f-curves failed (see anim_compat.py), not
        # "nothing to report".
        anim_note = f", {keyframe_count} keyframe(s) across all objects" if keyframe_count else ", 0 keyframes found on any object"
        self.report({'INFO'}, f"{count} primitive(s) exported to {self.filepath}{anim_note}{suffix}")
        return {'FINISHED'}


def menu_func_export(self, context):
    self.layout.operator(EXPORT_OT_pbd.bl_idname, text="PBD (.pbd)")


CLASSES = (EXPORT_OT_pbd,)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.TOPBAR_MT_file_export.append(menu_func_export)


def unregister():
    bpy.types.TOPBAR_MT_file_export.remove(menu_func_export)
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
