"""
Scene-level material catalog, backing a .pbdmat file (see PbdMatParser on
the engine side). Each pbd_materials entry is one `material NAME { ... }`
block; editing a field here immediately updates a real Blender Material
so every object using that name previews with the right color in the
viewport - not just at export time.
"""

import bpy
import os


class OBJECT_OT_pbd_refresh(bpy.types.Operator):
    """Re-syncs every PBD material's Blender representation and switches
    Solid-shading viewports to display texture images.

    Solid mode (Blender's default viewport shading) only ever shows a
    material's flat diffuse_color - it has no node graph to read, so an
    Image Texture node being correctly wired to Base Color (which is all
    _sync_material_to_blender sets up) is invisible there no matter how
    correct it is. Material Preview / Rendered modes DO read the node
    graph and would already show it - but Solid is what most people are
    looking at by default, and there's no obvious UI hint that a
    different display mode exists. Solid mode also has its own texture
    display, toggled per-viewport via Viewport Shading > Color >
    Texture - scripted here rather than left as a manual step to find.
    """
    bl_idname = "pbd.refresh"
    bl_label = "Refresh PBD Materials"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Re-applies every PBD material's color/texture/etc to its Blender material, and switches viewports to show textures in Solid shading"

    def execute(self, context):
        for entry in context.scene.pbd_materials:
            _sync_material_to_blender(entry)
        for obj in bpy.data.objects:
            if obj.type == 'MESH' and getattr(obj, "pbd", None) and obj.pbd.pbd_material:
                assign_material_to_object(obj, obj.pbd.pbd_material)

        switched = 0
        for window in context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D':
                    for space in area.spaces:
                        if space.type == 'VIEW_3D':
                            space.shading.color_type = 'TEXTURE'
                            switched += 1

        self.report({'INFO'}, f"Refreshed {len(context.scene.pbd_materials)} material(s), "
                               f"switched {switched} viewport(s) to texture display")
        return {'FINISHED'}


def _sync_material_to_blender(entry):
    """Finds or creates a Blender Material matching this entry's name and
    pushes color/specular/texture into it. diffuse_color drives Solid
    shading (proven in this add-on's own test renders); an Image Texture
    node wired into Principled BSDF's Base Color drives Material Preview /
    Rendered shading, so a texture_path actually shows there - a flat
    Base Color value alone can never display an image, no matter what
    that value is."""
    mat_name = "pbd_mat_" + entry.name
    mat = bpy.data.materials.get(mat_name)
    if mat is None:
        mat = bpy.data.materials.new(name=mat_name)
        mat.use_nodes = True

    mat.diffuse_color = (entry.color[0], entry.color[1], entry.color[2], 1.0)
    mat.specular_intensity = entry.specular

    if mat.use_nodes:
        nodes = mat.node_tree.nodes
        links = mat.node_tree.links
        bsdf = nodes.get("Principled BSDF")
        if bsdf is not None:
            if "Specular IOR Level" in bsdf.inputs:  # property name changed across Blender versions
                bsdf.inputs["Specular IOR Level"].default_value = entry.specular
            elif "Specular" in bsdf.inputs:
                bsdf.inputs["Specular"].default_value = entry.specular

            tex_node = nodes.get("PBD Texture")
            mapping_node = nodes.get("PBD UVScale")
            if entry.texture_path:
                if tex_node is None:
                    tex_node = nodes.new("ShaderNodeTexImage")
                    tex_node.name = "PBD Texture"
                    tex_node.location = (bsdf.location.x - 500, bsdf.location.y)
                if mapping_node is None:
                    mapping_node = nodes.new("ShaderNodeMapping")
                    mapping_node.name = "PBD UVScale"
                    mapping_node.location = (bsdf.location.x - 700, bsdf.location.y)
                    coord_node = nodes.new("ShaderNodeTexCoord")
                    coord_node.name = "PBD TexCoord"
                    coord_node.location = (bsdf.location.x - 900, bsdf.location.y)
                    links.new(coord_node.outputs["UV"], mapping_node.inputs["Vector"])
                mapping_node.inputs["Scale"].default_value = (entry.uv_scale_u, entry.uv_scale_v, 1.0)
                links.new(mapping_node.outputs["Vector"], tex_node.inputs["Vector"])
                try:
                    image = bpy.data.images.load(bpy.path.abspath(entry.texture_path), check_existing=True)
                    tex_node.image = image
                    links.new(tex_node.outputs["Color"], bsdf.inputs["Base Color"])
                except RuntimeError as e:
                    print(f"[PBD] Could not load texture '{entry.texture_path}': {e}")
                    bsdf.inputs["Base Color"].default_value = (entry.color[0], entry.color[1], entry.color[2], 1.0)
            else:
                if tex_node is not None:
                    nodes.remove(tex_node)
                if mapping_node is not None:
                    nodes.remove(mapping_node)
                coord_node = nodes.get("PBD TexCoord")
                if coord_node is not None:
                    nodes.remove(coord_node)
                bsdf.inputs["Base Color"].default_value = (entry.color[0], entry.color[1], entry.color[2], 1.0)

            # Normal map: needs a dedicated Normal Map node between the
            # image and the BSDF (Blender doesn't accept a raw image color
            # as a normal input - that node is what un-remaps the
            # 0..1-encoded tangent-space vector back into a usable normal).
            normal_tex_node = nodes.get("PBD NormalTexture")
            normal_map_node = nodes.get("PBD NormalMap")
            if entry.normal_map_path:
                if normal_tex_node is None:
                    normal_tex_node = nodes.new("ShaderNodeTexImage")
                    normal_tex_node.name = "PBD NormalTexture"
                    normal_tex_node.location = (bsdf.location.x - 500, bsdf.location.y - 300)
                if normal_map_node is None:
                    normal_map_node = nodes.new("ShaderNodeNormalMap")
                    normal_map_node.name = "PBD NormalMap"
                    normal_map_node.location = (bsdf.location.x - 300, bsdf.location.y - 300)
                try:
                    normal_image = bpy.data.images.load(bpy.path.abspath(entry.normal_map_path), check_existing=True)
                    normal_image.colorspace_settings.name = 'Non-Color'  # normal maps are data, not sRGB color
                    normal_tex_node.image = normal_image
                    links.new(normal_tex_node.outputs["Color"], normal_map_node.inputs["Color"])
                    links.new(normal_map_node.outputs["Normal"], bsdf.inputs["Normal"])
                except RuntimeError as e:
                    print(f"[PBD] Could not load normal map '{entry.normal_map_path}': {e}")
            else:
                if normal_tex_node is not None:
                    nodes.remove(normal_tex_node)
                if normal_map_node is not None:
                    nodes.remove(normal_map_node)

            if "Roughness" in bsdf.inputs:
                # No real reflection probe in Blender's viewport, and no
                # single "reflectivity" input on Principled BSDF either -
                # lower roughness reads as glossier/more mirror-like,
                # which is the closer single-slider approximation of "more
                # reflective" than Transmission (which means see-through,
                # not reflective) would be. Same "close visual
                # approximation, not physically exact" policy as this
                # add-on's bend/smooth previews.
                bsdf.inputs["Roughness"].default_value = max(0.05, 0.5 - entry.reflectivity * 0.45)

            mat.blend_method = 'BLEND' if entry.transparency > 0.001 else 'OPAQUE'
            if "Alpha" in bsdf.inputs:
                bsdf.inputs["Alpha"].default_value = 1.0 - entry.transparency
    return mat


def _sync_material_entry(self, context):
    _sync_material_to_blender(self)
    # Re-push to every object currently using this material by name, so
    # a rename or color edit is visible immediately, not just for
    # objects assigned to it afterward.
    for obj in bpy.data.objects:
        if obj.type == 'MESH' and getattr(obj, "pbd", None) and obj.pbd.pbd_material == self.name:
            assign_material_to_object(obj, self.name)


def assign_material_to_object(obj, material_name):
    """Finds-or-creates the Blender material for material_name (from the
    scene catalog if present, else a neutral fallback) and makes it the
    object's only material slot. Called whenever pbd_material changes
    (see properties.py) and whenever a catalog entry it's using is edited
    (see _sync_material_entry above)."""
    scene = bpy.context.scene
    entry = scene.pbd_materials.get(material_name)
    if entry is not None:
        mat = _sync_material_to_blender(entry)
    else:
        # Not in the catalog - likely one of the engine's hard-coded
        # names (wood/metal/plastic) or a name from an included .pbdmat
        # this session hasn't loaded. Neutral grey placeholder rather
        # than refusing the name.
        mat_name = "pbd_mat_" + material_name
        mat = bpy.data.materials.get(mat_name)
        if mat is None:
            mat = bpy.data.materials.new(name=mat_name)
            mat.diffuse_color = (0.65, 0.65, 0.68, 1.0)

    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


class PbdIncludeMaterialSource(bpy.types.PropertyGroup):
    """One entry = one include_material line written VERBATIM at export
    - the path or URL exactly as given when it was added (by
    IMPORT_OT_pbdmat's own Include mode, or by hand via the panel), no
    name-convention assumption the way SHARED material_source entries
    make (materials/<name>.pbdmat) and no per-material field
    duplication the way EMBEDDED entries make. This is the mechanism
    that actually satisfies "reference an arbitrary external .pbdmat
    (local OR a URL) without copying its content into this scene" -
    SHARED only ever covers this PROJECT's own conventionally-named
    shared folder, not an arbitrary community asset fetched by its own
    URL."""
    path: bpy.props.StringProperty(name="Path or URL", default="")


class PbdMaterialEntry(bpy.types.PropertyGroup):
    # Named "name" (not e.g. "mat_name") specifically so prop_search can
    # search this collection directly - see ui_panel.py's use of it on
    # pbd_material - and so bpy.data-style `scene.pbd_materials["wood"]`
    # lookup by name works, both being standard Blender conventions for
    # entries meant to be found by name rather than only by index.
    name: bpy.props.StringProperty(name="Name", default="material", update=_sync_material_entry)
    color: bpy.props.FloatVectorProperty(
        name="Color", subtype='COLOR', size=3, min=0.0, max=1.0,
        default=(0.7, 0.7, 0.7), update=_sync_material_entry,
    )
    shininess: bpy.props.FloatProperty(name="Shininess", default=8.0, min=0.0, soft_max=128.0, update=_sync_material_entry)
    specular: bpy.props.FloatProperty(name="Specular", default=0.1, min=0.0, max=1.0, update=_sync_material_entry)
    texture_path: bpy.props.StringProperty(name="Texture", default="", subtype='FILE_PATH', update=_sync_material_entry)
    normal_map_path: bpy.props.StringProperty(name="Normal Map", default="", subtype='FILE_PATH', update=_sync_material_entry)
    roughness_map_path: bpy.props.StringProperty(name="Roughness Map", default="", subtype='FILE_PATH', update=_sync_material_entry)
    displacement_map_path: bpy.props.StringProperty(name="Displacement Map", default="", subtype='FILE_PATH', update=_sync_material_entry)
    displacement_scale: bpy.props.FloatProperty(name="Displacement Scale", default=0.02, min=0.0, soft_max=0.5, update=_sync_material_entry,
        description="World-space height at a fully-white texel - matches PbdRenderer's own default of 0.02 when this field is omitted from a .pbdmat")
    material_source: bpy.props.EnumProperty(
        name="Material Source",
        items=[
            ('EMBEDDED', "Embed in this .pbd", "Writes this material into a .pbdmat generated alongside this scene's .pbd file"),
            ('SHARED', "Reference materials/ folder", "Points include_material at the shared, project-wide materials/NAME.pbdmat instead of duplicating it here - use for a material that's shared across many assets (ambientcg-derived, say)"),
        ],
        default='EMBEDDED',
    )
    reflectivity: bpy.props.FloatProperty(name="Reflectivity", default=0.0, min=0.0, max=1.0, update=_sync_material_entry)
    transparency: bpy.props.FloatProperty(name="Transparency", default=0.0, min=0.0, max=1.0, update=_sync_material_entry)
    # Split from a single uv_scale (which scaled both axes identically,
    # via a Mapping node's Scale input set to (v,v,v)) into independent
    # U/V control - a non-square texture on a non-square surface needs
    # to tile at a DIFFERENT rate per axis, which a single shared value
    # can never express regardless of what number it's set to. The old
    # combined field's name and meaning are preserved as uvScale= on
    # export/import ONLY when both axes still match (see export_pbd.py/
    # import_pbd.py) - not written as a separate concept alongside the
    # two axis values, since that would just be redundant data that
    # could disagree with them.
    uv_scale_u: bpy.props.FloatProperty(name="UV Scale U", default=1.0, min=0.01, soft_max=20.0, update=_sync_material_entry,
        description="Tiling repeat factor across the surface, U (horizontal) axis - 1.0 = texture spans the surface once, higher = smaller/more repeated tiles")
    uv_scale_v: bpy.props.FloatProperty(name="UV Scale V", default=1.0, min=0.01, soft_max=20.0, update=_sync_material_entry,
        description="Tiling repeat factor across the surface, V (vertical) axis")


class OBJECT_OT_pbd_material_add(bpy.types.Operator):
    bl_idname = "pbd.material_add"
    bl_label = "Add PBD Material"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        entry = context.scene.pbd_materials.add()
        base = "material"
        name, i = base, 1
        existing = {m.name for m in context.scene.pbd_materials}
        while name in existing:
            i += 1
            name = f"{base}{i}"
        entry.name = name
        context.scene.pbd_materials_active_index = len(context.scene.pbd_materials) - 1
        return {'FINISHED'}


class OBJECT_OT_pbd_material_remove(bpy.types.Operator):
    bl_idname = "pbd.material_remove"
    bl_label = "Remove PBD Material"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        idx = scene.pbd_materials_active_index
        if 0 <= idx < len(scene.pbd_materials):
            scene.pbd_materials.remove(idx)
            scene.pbd_materials_active_index = min(idx, len(scene.pbd_materials) - 1)
        return {'FINISHED'}


class OBJECT_OT_pbd_material_sync_from_objects(bpy.types.Operator):
    """Adds a catalog entry (default color/shininess, no texture) for
    every distinct pbd_material name already set on a PBD object that
    doesn't have one yet - the exact gap that makes a typed-but-not-added
    material's fields (UV scale, texture, normal map...) invisible: they
    only exist on catalog entries, and typing a name directly (prop_search
    allows free text) never creates one."""
    bl_idname = "pbd.material_sync_from_objects"
    bl_label = "Sync PBD Materials From Objects"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        existing = {m.name for m in context.scene.pbd_materials}
        used = {
            obj.pbd.pbd_material
            for obj in bpy.data.objects
            if obj.type == 'MESH' and getattr(obj, "pbd", None)
            and obj.pbd.is_pbd_primitive and obj.pbd.pbd_material
        }
        missing = sorted(used - existing)
        for name in missing:
            entry = context.scene.pbd_materials.add()
            entry.name = name
        self.report({'INFO'}, f"Added {len(missing)} material(s): {', '.join(missing) if missing else '(none missing)'}")
        return {'FINISHED'}


class OBJECT_OT_pbd_material_load(bpy.types.Operator):
    """Loads a .pbdmat file's entries into the scene catalog, on top of
    (not replacing) whatever's already there - reuses the engine's own
    grammar directly rather than a second parser, since it's a small,
    line-oriented format (see the docstring on the parsing helper below)."""
    bl_idname = "pbd.material_load"
    bl_label = "Load .pbdmat"
    bl_options = {'REGISTER', 'UNDO'}

    filepath: bpy.props.StringProperty(subtype='FILE_PATH')

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        try:
            materials = _parse_pbdmat(self.filepath)
        except OSError as e:
            self.report({'ERROR'}, f"Could not read {self.filepath}: {e}")
            return {'CANCELLED'}

        scene = context.scene
        for name, fields in materials.items():
            entry = scene.pbd_materials.get(name)
            if entry is None:
                entry = scene.pbd_materials.add()
                entry.name = name
            if "color" in fields:
                entry.color = fields["color"]
            if "shininess" in fields:
                entry.shininess = fields["shininess"]
            if "specular" in fields:
                entry.specular = fields["specular"]
            mat_dir = os.path.dirname(os.path.abspath(self.filepath))
            if "texture" in fields:
                entry.texture_path = os.path.join(mat_dir, fields["texture"])
            if "normalMap" in fields:
                entry.normal_map_path = os.path.join(mat_dir, fields["normalMap"])
            if "roughnessMap" in fields:
                entry.roughness_map_path = os.path.join(mat_dir, fields["roughnessMap"])
            if "displacementMap" in fields:
                entry.displacement_map_path = os.path.join(mat_dir, fields["displacementMap"])
            if "displacementScale" in fields:
                entry.displacement_scale = fields["displacementScale"]
            if "uvScale" in fields:
                entry.uv_scale_u = entry.uv_scale_v = float(fields["uvScale"])
            if "uvScaleU" in fields:
                entry.uv_scale_u = float(fields["uvScaleU"])
            if "uvScaleV" in fields:
                entry.uv_scale_v = float(fields["uvScaleV"])
            if "reflectivity" in fields:
                entry.reflectivity = fields["reflectivity"]
            if "transparency" in fields:
                entry.transparency = fields["transparency"]
        self.report({'INFO'}, f"Loaded {len(materials)} material(s) from {self.filepath}")
        return {'FINISHED'}


def _parse_pbdmat(filepath):
    """Minimal reader for `material NAME { key=value ... }` blocks -
    deliberately small and line-oriented rather than importing the
    engine's own tokenizer logic wholesale, since this only needs to
    handle the handful of fields this panel edits (color/shininess/
    specular/texture), not the full grammar PbdMatParser.java supports."""
    materials = {}
    with open(filepath, "r", encoding="utf-8") as f:
        text = f.read()

    pos = 0
    while True:
        idx = text.find("material", pos)
        if idx == -1:
            break
        brace_open = text.find("{", idx)
        brace_close = text.find("}", brace_open)
        if brace_open == -1 or brace_close == -1:
            break
        name = text[idx + len("material"):brace_open].strip()
        body = text[brace_open + 1:brace_close]
        fields = {}
        for line in body.splitlines():
            line = line.split("#", 1)[0].strip()
            if "=" not in line:
                continue
            key, _, raw = line.partition("=")
            key, raw = key.strip(), raw.strip()
            if key == "color":
                inner = raw.strip("()")
                parts = [float(p.strip()) for p in inner.split(",")]
                fields["color"] = tuple(parts) if len(parts) == 3 else (parts[0],) * 3
            elif key in ("shininess", "specular"):
                fields[key] = float(raw)
            elif key in ("texture", "normalMap", "roughnessMap", "displacementMap"):
                fields[key] = raw
            elif key in ("uvScale", "reflectivity", "transparency", "displacementScale"):
                fields[key] = float(raw)
        materials[name] = fields
        pos = brace_close + 1
    return materials


class OBJECT_OT_pbd_material_save(bpy.types.Operator):
    bl_idname = "pbd.material_save"
    bl_label = "Save .pbdmat"
    bl_options = {'REGISTER', 'UNDO'}

    filepath: bpy.props.StringProperty(subtype='FILE_PATH', default="materials.pbdmat")

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        lines = []
        for entry in context.scene.pbd_materials:
            lines.append(f"material {entry.name} {{")
            lines.append("  color     = (%.4g, %.4g, %.4g)" % tuple(entry.color))
            lines.append(f"  shininess = {entry.shininess:.4g}")
            lines.append(f"  specular  = {entry.specular:.4g}")
            if entry.texture_path:
                lines.append(f"  texture   = {os.path.basename(entry.texture_path)}")
            if abs(entry.uv_scale_u - 1.0) > 0.001 or abs(entry.uv_scale_v - 1.0) > 0.001:
                if abs(entry.uv_scale_u - entry.uv_scale_v) < 0.001:
                    lines.append(f"  uvScale   = {entry.uv_scale_u:.4g}")  # both axes match - the shorter, backward-compatible single-value form
                else:
                    lines.append(f"  uvScaleU  = {entry.uv_scale_u:.4g}")
                    lines.append(f"  uvScaleV  = {entry.uv_scale_v:.4g}")
            if entry.normal_map_path:
                lines.append(f"  normalMap = {os.path.basename(entry.normal_map_path)}")
            if entry.roughness_map_path:
                lines.append(f"  roughnessMap = {os.path.basename(entry.roughness_map_path)}")
            if entry.displacement_map_path:
                lines.append(f"  displacementMap = {os.path.basename(entry.displacement_map_path)}")
                lines.append(f"  displacementScale = {entry.displacement_scale:.4g}")
            if entry.reflectivity > 0.001:
                lines.append(f"  reflectivity = {entry.reflectivity:.4g}")
            if entry.transparency > 0.001:
                lines.append(f"  transparency = {entry.transparency:.4g}")
            lines.append("}")
            lines.append("")
        try:
            with open(self.filepath, "w", encoding="utf-8") as f:
                f.write("\n".join(lines))
        except OSError as e:
            self.report({'ERROR'}, f"Could not write {self.filepath}: {e}")
            return {'CANCELLED'}
        self.report({'INFO'}, f"Saved {len(context.scene.pbd_materials)} material(s) to {self.filepath}")
        return {'FINISHED'}


class OBJECT_OT_pbd_include_material_remove(bpy.types.Operator):
    """Removes one entry from scene.pbd_include_material_sources by
    index - the equivalent of OBJECT_OT_pbd_material_remove for THIS
    collection, kept as its own tiny operator rather than reusing that
    one, since the two collections hold structurally different things
    (a full material's worth of fields vs. a single path string)."""
    bl_idname = "pbd.include_material_remove"
    bl_label = "Remove Included Material Source"
    bl_options = {'REGISTER', 'UNDO'}

    index: bpy.props.IntProperty()

    def execute(self, context):
        sources = context.scene.pbd_include_material_sources
        if 0 <= self.index < len(sources):
            sources.remove(self.index)
        return {'FINISHED'}


CLASSES = (
    PbdIncludeMaterialSource,
    OBJECT_OT_pbd_include_material_remove,
    PbdMaterialEntry,
    OBJECT_OT_pbd_material_add,
    OBJECT_OT_pbd_material_remove,
    OBJECT_OT_pbd_material_load,
    OBJECT_OT_pbd_material_save,
    OBJECT_OT_pbd_material_sync_from_objects,
    OBJECT_OT_pbd_refresh,
)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.pbd_materials = bpy.props.CollectionProperty(type=PbdMaterialEntry)
    bpy.types.Scene.pbd_materials_active_index = bpy.props.IntProperty(default=0)
    bpy.types.Scene.pbd_export_minify = bpy.props.BoolProperty(
        name="Minify",
        default=False,
        description="Write the .pbd text minified (every separator trimmed to the minimum "
                    "the parser can still read - no indentation, fields space-separated "
                    "instead of one per line) instead of the human-readable pretty form. "
                    "Smaller file, harder to hand-edit or diff - matches PbdSerializer.java's "
                    "own pretty/minified distinction, now available from the add-on's own "
                    "text export too, not just via the separate .pbdbin compiled format",
    )
    # Scene-level TEXTUAL metadata - describing the FILE as a whole
    # (matching PbdScene.java's own name/kind/authors/origin/description fields),
    # not any one primitive in it. Previously had no UI at all despite
    # being fully supported by the parser/serializer for as long as
    # those existed - distinct from pbd_metadata (a per-OBJECT boolean
    # marking an invisible storage-volume primitive, entirely unrelated
    # despite the similar name) and from the new pbd_category below
    # (also per-object, a free-form semantic tag, not a file description).
    bpy.types.Scene.pbd_scene_name = bpy.props.StringProperty(
        name="Name", default="",
        description="Human-readable label for the whole file ('Wardrobe', 'Rain Barrel') - not the same thing as any instance's own object name",
    )
    bpy.types.Scene.pbd_scene_kind = bpy.props.StringProperty(
        name="Kind", default="",
        description="Free-form category for the whole file ('furniture', 'container', 'decoration') - not validated against a fixed list",
    )
    bpy.types.Scene.pbd_scene_authors = bpy.props.StringProperty(
        name="Authors", default="",
        description="Comma-separated if more than one - each becomes its own author= line on export (PbdScene.authors is a list, a single field would lose all but the last of several credited authors)",
    )
    bpy.types.Scene.pbd_scene_origin = bpy.props.StringProperty(
        name="Origin", default="",
        description="The URL this file was fetched from, if any - normally set automatically by whatever fetched it (see PbdFetcher), not something to fill in by hand for a locally-authored file. A file with no origin was authored locally",
    )
    bpy.types.Scene.pbd_scene_description = bpy.props.StringProperty(
        name="Description", default="",
        description="Free-form text about the whole file ('Oak wardrobe, two doors, the left one sticks') - what the site's search reads along with the name and the kind. One line; a double quote is written as an apostrophe, since the format has no way to escape it. Leave empty for none",
    )
    bpy.types.Scene.pbd_materials_folder = bpy.props.StringProperty(
        name="Materials Folder",
        subtype='DIR_PATH',
        default="",
        description="Where the project-wide shared materials/ folder is - set INDEPENDENTLY of anything else (there is no longer one combined 'project root' setting - each thing that needs a folder gets its own, since a single shared setting was easy to point at the wrong place for whichever purpose wasn't foremost in mind at the time). Leave empty to fall back to guessing relative to this add-on's own install location, which only works if it happens to be installed from inside a checkout of this project",
    )
    bpy.types.Scene.pbd_include_material_sources = bpy.props.CollectionProperty(
        type=PbdIncludeMaterialSource,
        name="Included Material Files",
        description="Extra include_material lines written verbatim at export, beyond what EMBEDDED/SHARED material entries already produce - see PbdIncludeMaterialSource's own doc for why this exists as a THIRD mechanism rather than folding into either of those",
    )


def unregister():
    del bpy.types.Scene.pbd_include_material_sources
    del bpy.types.Scene.pbd_materials_folder
    del bpy.types.Scene.pbd_scene_description
    del bpy.types.Scene.pbd_scene_origin
    del bpy.types.Scene.pbd_scene_authors
    del bpy.types.Scene.pbd_scene_kind
    del bpy.types.Scene.pbd_scene_name
    del bpy.types.Scene.pbd_export_minify
    del bpy.types.Scene.pbd_materials_active_index
    del bpy.types.Scene.pbd_materials
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
