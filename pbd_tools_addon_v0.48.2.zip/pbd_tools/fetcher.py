"""Fetches a PBD/PBDMAT/PBDBIN asset from a URL, with local caching and a
fallback URL for a 404 - the Blender-side counterpart to pbd.net.PbdFetcher
in the Java engine, under the same rules (safety.py is the Python side of
pbd.net.FetchPolicy, and the regression suite puts the same addresses through
both):

  * only https, with no user name in the address, a sane port, and a host that
    is not the person's own network - a private, loopback or link-local address,
    a name that only means something inside one network, or a name that
    RESOLVES to such an address;
  * exactly one HTTP method (GET, nothing that writes or deletes anything
    remote), and redirects are NOT followed - a server-controlled redirect
    silently retargeting a fetch is exactly the kind of thing a "keep it
    simple" security posture should avoid doing on a caller's behalf;
  * a download is read with a cap decided before it starts (the engine's 64 MB):
    a server that never stops sending ends in a message, not in Blender going
    down; the file reaches the cache only when it arrived whole.

User-Agent identifies this as addon traffic specifically (distinct from
the Java engine's own string) so server-side metrics can tell the two
apart.
"""

import hashlib
import os
import urllib.error
import urllib.request

from . import safety

# The project's own host - THE one place the add-on names it. The user agent, the default host a bare filename is retried
# against, the upload and version addresses and the labels of the upload button all derive from this constant, so a change of
# domain is a change of this line (pbd.net.FetchPolicy.SITE_HOST in the engine and PBD_SITE_HOST in server/pbd_metadata.php are
# the other two; the regression suites compare all three).
PBD_SITE_HOST = "pbd.aptheo.fr"

USER_AGENT = f"PrimitiveBasedDescription Blender ({PBD_SITE_HOST})"

#: Plain http to THIS machine is accepted when True - for the tests of the add-on, and nothing else (the engine's
#: PbdFetcher.Settings.allowLoopbackHttp). Every other plain-http address is refused whatever this says.
ALLOW_LOOPBACK_HTTP = False

#: A name is looked up and refused when it points into the person's own network (the engine's checkResolvedAddresses).
CHECK_RESOLVED_ADDRESSES = True

#: How a host name is looked up: a function from the name to the addresses (4 or 16 bytes each) - replaced by the tests, which must
#: not depend on a network.
RESOLVER = None


class FetchError(OSError):
    """A fetch that failed (no network, a 404, a redirect, an address that is not allowed). An OSError on purpose: the
    importer documents - and catches - OSError/ValueError for "this source cannot be read", and a plain Exception
    slipped through every one of those handlers: an import with one unreachable pbd_ref stopped with a traceback
    instead of importing the rest and leaving that reference as an empty placeholder with a warning."""


def fetch(url, cache_dir, fallback_url=None, use_cache=True):
    """Returns the local cached file path for url. Uses the cache
    directly (no request at all) if a copy already exists and use_cache
    is True. On 404 or any other failure, tries fallback_url if given,
    then finally an existing stale cache entry, before raising."""
    os.makedirs(cache_dir, exist_ok=True)
    cache_path = _cache_path_for(url, cache_dir)

    if use_cache and os.path.exists(cache_path):
        return cache_path

    try:
        return _do_fetch(url, cache_path)
    except FetchError as primary_failure:
        if fallback_url:
            try:
                print(f"[fetcher] '{safety.printable(url)}' failed ({primary_failure}) - trying fallback: {safety.printable(fallback_url)}")
                return _do_fetch(fallback_url, cache_path)
            except FetchError as fallback_failure:
                print(f"[fetcher] Fallback also failed: {fallback_failure}")
        if os.path.exists(cache_path):
            print(f"[fetcher] Using stale cached copy of '{safety.printable(url)}' after fetch failure")
            return cache_path
        raise


def _system_resolver(host):
    """The addresses the system's name resolution gives a host; none when it gives none."""
    import socket
    addresses = []
    try:
        for family, _type, _proto, _canon, sockaddr in socket.getaddrinfo(host, None, type=socket.SOCK_STREAM):
            if family in (socket.AF_INET, socket.AF_INET6):
                addresses.append(socket.inet_pton(family, sockaddr[0].split("%")[0]))
    except (OSError, ValueError, UnicodeError):
        pass     # not resolvable: the request itself then fails with a clear message
    return addresses


def refusal_for(url):
    """Why ``url`` must not be fetched, or None: the address itself (safety.refuse), then the addresses its host name resolves to."""
    why = safety.refuse(url, PBD_SITE_HOST, ALLOW_LOOPBACK_HTTP)
    if why:
        return why
    if CHECK_RESOLVED_ADDRESSES:
        host = safety.host_of(url)
        return safety.refuse_resolved(host, RESOLVER or _system_resolver, PBD_SITE_HOST)
    return None


def _do_fetch(url, cache_path):
    why = refusal_for(url)
    if why:
        raise FetchError(f"Refused to fetch '{safety.printable(url)}': {why}")

    request = urllib.request.Request(url, method="GET", headers={"User-Agent": USER_AGENT})
    try:
        # Explicitly built with no redirect handler installed beyond
        # urllib's own default opener behavior - urllib.request DOES
        # follow redirects by default via HTTPRedirectHandler, which
        # this project's own security preference (see PbdFetcher.java's
        # own doc comment) would rather avoid. A custom opener with
        # redirect handling disabled keeps this consistent with the
        # Java side: a redirect is treated as a failure, not resolved
        # transparently.
        opener = build_opener()
        with opener.open(request, timeout=30) as response:
            status = getattr(response, "status", 200)
            if status != 200:
                raise FetchError(f"HTTP {status} fetching '{safety.printable(url)}'")
            announced = _announced_length(response)
            if announced is not None and announced > safety.MAX_FETCH_BYTES:
                raise FetchError(f"'{safety.printable(url)}' announces {safety.describe(announced)}, more than the "
                                 f"{safety.describe(safety.MAX_FETCH_BYTES)} a fetched file may weigh - refused")
            data = safety.read_capped(response, safety.MAX_FETCH_BYTES, f"'{safety.printable(url)}'")
    except safety.Refused as e:
        raise FetchError(str(e)) from e
    except urllib.error.HTTPError as e:
        if e.code == 404:
            raise FetchError(f"404 Not Found: {safety.printable(url)}") from e
        if 300 <= e.code < 400:
            raise FetchError(f"Redirect ({e.code}) not followed for '{safety.printable(url)}' - this fetcher never follows redirects automatically") from e
        raise FetchError(f"HTTP {e.code} fetching '{safety.printable(url)}'") from e
    except urllib.error.URLError as e:
        raise FetchError(f"Network error fetching '{safety.printable(url)}': {e.reason}") from e

    _write_atomically(cache_path, data)
    return cache_path


def _announced_length(response):
    """The size the server announces for the body, or None when it announces none (or nonsense)."""
    try:
        value = response.headers.get("Content-Length")
        return int(value) if value is not None and value.strip().isdigit() else None
    except (AttributeError, ValueError):
        return None


def _write_atomically(path, data):
    """The file appears under its name whole or not at all: a reader (another import, the engine, sharing this cache) never sees half a
    download, and a failure half-way leaves the previous copy in place."""
    temporary = f"{path}.part{os.getpid()}"
    try:
        with open(temporary, "wb") as f:
            f.write(data)
        os.replace(temporary, path)
    except OSError:
        try:
            os.unlink(temporary)
        except OSError:
            pass
        raise


class _NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None  # returning None tells urllib to treat this as a terminal response, not follow it


def build_opener():
    """The one way this add-on talks to a server (a fetch, the version check, the upload): urllib's own opener with redirects switched
    off, so that an answer that points somewhere else is a failure and not a request made on the person's behalf to another host."""
    return urllib.request.build_opener(_NoRedirectHandler)


def _cache_path_for(url, cache_dir):
    """Cache filename is a hash of the URL, not its own path segment -
    avoids collisions between two different URLs sharing a filename, and
    sidesteps sanitizing arbitrary URL characters into a valid filename."""
    hash_hex = hashlib.sha256(url.encode("utf-8")).hexdigest()[:32]
    return os.path.join(cache_dir, hash_hex + ".cache")
