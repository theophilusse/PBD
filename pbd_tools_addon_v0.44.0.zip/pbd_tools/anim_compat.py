"""
Reads an object's rotation/location f-curves across Blender's animation
API versions. Blender 4.4 introduced Action Slots: f-curves moved from
`action.fcurves` into a per-slot Channelbag. `action.fcurves` kept
working through the 4.x series as a deprecated proxy for the first
slot/layer/strip - but per Blender's own migration docs, that proxy is
"considered deprecated, and will be removed in Blender 5.0", and by 5.0
`action.fcurves` raises AttributeError outright ('Action' object has no
attribute 'fcurves').

The project's own test Blender is 4.0.2 (pre-slots: the legacy path, which is
what the add-on was written and used with). `tools/regression/blender_real_check.py`
keys a door in a real scene, exports it, reads it back and has the engine play
it; it has been run on Blender 4.2 (pre-slots: the same legacy path as 4.0),
4.5 (slots, the deprecated `action.fcurves` still there), 5.0, 5.1 and 5.2
(slots, no `action.fcurves`). Not run: 4.0 itself (no `bpy` module of it
exists), 4.1, 4.3 and 4.4 - if keyframes don't export/show on one of them, this
is the first place to look.
"""

import bpy


def get_object_fcurves(obj):
    """Every f-curve on obj's active action, regardless of Blender's
    animation-data API version. Returns [] if obj has no action at all -
    the normal case, not an error."""
    if not obj.animation_data or not obj.animation_data.action:
        return []
    action = obj.animation_data.action

    # Blender 4.4+: f-curves live in a channelbag tied to a specific
    # slot, not directly on the action. action_slot only exists on 4.4+
    # AnimData - its absence means this is pre-4.4, where the legacy
    # path below is simply the normal, correct API, not a fallback.
    action_slot = getattr(obj.animation_data, "action_slot", None)
    if action_slot is not None:
        try:
            from bpy_extras import anim_utils
            channelbag = anim_utils.action_get_channelbag_for_slot(action, action_slot)
            if channelbag is not None and list(channelbag.fcurves):
                return list(channelbag.fcurves)
        except (ImportError, AttributeError):
            pass  # fall through to the legacy path below

    # Pre-4.4 Blender, or 4.4-4.x if the slot lookup above didn't apply
    # (e.g. no slot got auto-assigned - a known rough edge in early 4.4,
    # see Blender's own release notes) - action.fcurves still works here
    # as either the real API (pre-4.4) or the deprecated proxy (4.4-4.x).
    # Removed outright in 5.0, so this must stay wrapped in try/except:
    # letting that AttributeError propagate would take the whole export
    # down with it, not just silently skip this object's keyframes.
    try:
        legacy = list(action.fcurves)
        if legacy:
            return legacy
    except AttributeError:
        pass

    # Last-resort fallback, 4.4+ only: the slot lookup can come back
    # empty if a slot exists but never got its own channelbag populated
    # correctly (the "known rough edge" above) - rather than reporting
    # zero keyframes when the action demonstrably has SOME, sweep every
    # layer/strip/channelbag in the action and return whatever's there.
    # Not precise for a multi-object action sharing several slots (it
    # would return every slot's curves, not just this object's), but for
    # the common case - one object, one action - "all curves in the
    # action" and "this object's curves" are the same thing, and getting
    # a false "no keyframes" wrong is worse for this add-on's purposes
    # (an entire panel section silently disappearing) than occasionally
    # showing a keyframe count from the wrong slot in a shared-action
    # scene, which is a set-up this add-on doesn't otherwise support yet.
    try:
        found = []
        for layer in getattr(action, "layers", []):
            for strip in getattr(layer, "strips", []):
                for channelbag in getattr(strip, "channelbags", []):
                    found.extend(channelbag.fcurves)
        return found
    except AttributeError:
        return []


def find_fcurve(fcurves, data_path, index):
    """list.find() equivalent for the plain list get_object_fcurves returns (fcurves.find() is a method on Blender's own FCurves collection, not on a plain Python list)."""
    for fc in fcurves:
        if fc.data_path == data_path and fc.array_index == index:
            return fc
    return None
