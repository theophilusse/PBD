"""What a file may ask of the add-on - the Blender side of pbd.format.PbdLimits, pbd.net.FetchPolicy and pbd.net.CappedRead.

A scene is data from anywhere, and the person who imports it did not write the names in it: a ``pbd_ref`` names another file, a
material names a picture, a bundle names its entries. This module is the list of what such a name, and such a file, may be - decided
without touching the network or the disk (except where a function says it reads or writes), so that every rule can be tested line
by line, and checked against the engine's own Java rules (tools/regression/blender_addon_check.py runs the same addresses and entry
names through both).

  * an address is fetched only when it is **https**, carries no user name, has a sane port and a host that is not the person's own
    network (a private, loopback or link-local address, a name that only means something inside one network);
  * a file reference is read from the disk only when it is not a network path (``\\\\host\\share`` makes Windows hand the person's
    credentials to that host), not an address of another kind and not an alternate data stream;
  * a download, a decompressor and a text are read with the memory they may take decided BEFORE they start;
  * a bundle (``.pbdasset``) is unpacked only when every entry name is a plain relative path that stays inside the folder, and its
    entries, their size and their sum are counted as they are read;
  * a scene that includes scenes that include scenes... is counted: the instances and the files of a whole import share one budget.

No ``bpy`` in here on purpose: it is plain Python, run by the tests without Blender.
"""

import os
import unicodedata
import zlib

# ---- the numbers (the engine's own: pbd.format.PbdLimits, pbd.net.FetchPolicy; tools/regression compares them) --------------------------------------

#: The longest address, or reference, that is looked at: a longer one is not a file name.
MAX_REFERENCE_LENGTH = 2048
#: The most one fetched file may weigh: the download stops there.
MAX_FETCH_BYTES = 64 * 1024 * 1024
#: The most distinct files one import may open through references (the engine's FetchPolicy.MAX_FETCHES_PER_LOAD).
MAX_FETCHES_PER_LOAD = 256
#: The longest text one scene or material file may be (the engine reads 64 million characters).
MAX_TEXT_BYTES = 64 * 1024 * 1024
#: How far a compiled scene (.pbdbin) may expand when it is decompressed.
MAX_DECOMPRESSED_BYTES = 64 * 1024 * 1024
#: A bundled asset (.pbdasset): the most entries, the most one entry may weigh, the most all of them may weigh together.
MAX_ASSET_ENTRIES = 512
MAX_ASSET_ENTRY_BYTES = 64 * 1024 * 1024
MAX_ASSET_TOTAL_BYTES = 256 * 1024 * 1024
#: The longest name an entry of a bundle may have.
MAX_ENTRY_NAME_LENGTH = 255
#: How deep ``pbd_ref`` may nest in an import (the engine allows 8; Blender makes an object of everything, so less).
MAX_INCLUDE_DEPTH = 6
#: The most instances one import may create, every file it includes counting for what it brings (the site accepts 50 000 once expanded).
MAX_IMPORT_INSTANCES = 50_000


class Refused(ValueError):
    """A file, an address or a reference the add-on will not follow. A ValueError on purpose: the importer catches (OSError, ValueError)
    for "this source cannot be read" and goes on with the rest of the scene, leaving the reference as an empty placeholder."""


def describe(nbytes):
    """'64 MB', '512 KB', '700 bytes', '1 byte' - as CappedRead.describe in the engine."""
    if nbytes >= 1024 * 1024:
        return f"{nbytes // (1024 * 1024)} MB"
    if nbytes >= 1024:
        return f"{nbytes // 1024} KB"
    return "1 byte" if nbytes == 1 else f"{nbytes} bytes"


def printable(text, limit=80, keep_lines=False):
    """A name as it is put in a message: a hostile one can be long and can hold characters that act instead of being shown - control
    characters (a terminal reads them as commands), the invisible ones that reorder or hide the text around them (``\\u202e`` makes
    "gpj.exe" read "exe.jpg") and the line and paragraph separators. All of them are shown as ``?``. ``keep_lines``: a text of several
    lines (what a server answers) keeps its line ends and tabs."""
    cut = text if len(text) <= limit else text[:limit] + "..."
    keep = "\n\t" if keep_lines else ""
    return "".join("?" if (unicodedata.category(c) in ("Cc", "Cf", "Zl", "Zp") and c not in keep) else c for c in cut)


# ---- the host --------------------------------------------------------------------------------------------------------------------------------------
#
# java.net.URI decides whether an address has a host, and the engine's FetchPolicy asks it. Python has no equivalent that reads the same
# way, and a parser that is merely "close" is how an address gets through one and not the other - so the reading below follows the
# grammar of java.net.URI (RFC 2396 with the brackets of RFC 2732) component by component, and tools/regression/blender_addon_check.py puts
# the same few thousand addresses through both and compares the answers.

_ALNUM = frozenset("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789")
_ALPHA = frozenset("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz")
_DIGIT = frozenset("0123456789")
_HEX = frozenset("0123456789abcdefABCDEF")
_UNRESERVED = _ALNUM | frozenset("-_.!~*'()")
_URIC = _UNRESERVED | frozenset(";/?:@&=+$,[]")                  # a query, a fragment, the part of an address that is not a path
_PATH = _UNRESERVED | frozenset(":@&=+$,;/")                      # a path: no brackets, and '?' and '#' end it
_USERINFO = _UNRESERVED | frozenset(";:&=+$,")
_SERVER = _USERINFO | frozenset(".:@[]%")                         # what an authority may hold to be read as [user@]host[:port]
_SCHEME_REST = _ALNUM | frozenset("+-.")
_SCOPE_ID = _ALNUM | frozenset("_.")                              # after the '%' of an IPv6 address


def is_trusted_host(host, site_host):
    """True for the project's own host (upper or lower case); not for a sub-domain of it, not for the same name with a dot added."""
    return host is not None and host.lower() == site_host.lower()


def _legal(text, allowed):
    """True when every character of ``text`` is in ``allowed`` or is half of a ``%hh`` escape pair - java.net.URI's test of a component."""
    i, n = 0, len(text)
    while i < n:
        c = text[i]
        if c in allowed:
            i += 1
        elif c == "%" and i + 2 < n and text[i + 1] in _HEX and text[i + 2] in _HEX:
            i += 3
        else:
            return False
    return True


def _uri_authority(url):
    """``(scheme, authority, problem)`` as java.net.URI reads ``url``: the authority is None when the address has none, and ``problem`` is
    the text of what makes it not an address at all. Only characters that are not controls or spaces arrive here."""
    n = len(url)
    colon = -1
    for i, c in enumerate(url):
        if c in "/?#":
            break
        if c == ":":
            colon = i
            break
    scheme = None
    p = 0
    if colon >= 0:
        if colon == 0:
            return None, None, "expected a scheme name"
        if url[0] not in _ALPHA or any(c not in _SCHEME_REST for c in url[1:colon]):
            return None, None, "illegal character in the scheme name"
        scheme = url[:colon]
        p = colon + 1
        if not (p < n and url[p] == "/"):                        # "mailto:x": an opaque address, which has no host
            q = url.find("#", p)
            q = n if q < 0 else q
            if q <= p:
                return scheme, None, "expected a scheme-specific part"
            if not _legal(url[p:q], _URIC):
                return scheme, None, "illegal character in the opaque part"
            p = q
            return _check_fragment(scheme, None, url, p)
    authority = None
    if url.startswith("//", p):
        p += 2
        q = p
        while q < n and url[q] not in "/?#":
            q += 1
        if q > p:
            authority = url[p:q]
            if not _legal_authority(authority):
                return scheme, None, "illegal character in the authority"
            p = q
        elif q >= n:
            return scheme, None, "expected an authority"        # "https://"
    q = p
    while q < n and url[q] not in "?#":
        q += 1
    if not _legal(url[p:q], _PATH):
        return scheme, authority, "illegal character in the path"
    p = q
    if p < n and url[p] == "?":
        p += 1
        q = url.find("#", p)
        q = n if q < 0 else q
        if not _legal(url[p:q], _URIC):
            return scheme, authority, "illegal character in the query"
        p = q
    return _check_fragment(scheme, authority, url, p)


def _check_fragment(scheme, authority, url, p):
    if p < len(url) and url[p] == "#":
        if not _legal(url[p + 1:], _URIC):
            return scheme, authority, "illegal character in the fragment"
    return scheme, authority, None


def _legal_authority(authority):
    """An authority is read as a server ([user@]host[:port]) or as a registry name; one that is neither is not an address. Only the
    characters are looked at here (the structure is _parse_server's)."""
    return all(c in _SERVER for c in authority) or _legal(authority, _UNRESERVED | frozenset("$,;:@&=+"))


class _Malformed(Exception):
    """The text is not an IPv6 address as java.net.URI reads one."""


class _V6Syntax:
    """The grammar java.net.URI applies to what is between the brackets of an IPv6 address: hexadecimal groups of one to four digits, at
    most one ``::``, 16 bytes in all (fewer with ``::``), and a dotted IPv4 address, in decimal, standing for the last 32 bits."""

    def __init__(self, text):
        self.t = text
        self.n = len(text)
        self.count = 0

    def _run(self, p, allowed):
        q = p
        while q < self.n and self.t[q] in allowed:
            q += 1
        return q

    def _at(self, p, s):
        return self.t.startswith(s, p)

    def _hex_seq(self, p):
        q = self._run(p, _HEX)
        if q <= p or self._at(q, "."):
            return -1
        if q > p + 4:
            raise _Malformed
        self.count += 2
        p = q
        while p < self.n:
            if not self._at(p, ":") or self._at(p + 1, ":"):
                break
            p += 1
            q = self._run(p, _HEX)
            if q <= p:
                raise _Malformed
            if self._at(q, "."):
                p -= 1
                break
            if q > p + 4:
                raise _Malformed
            self.count += 2
            p = q
        return p

    def _take_ipv4(self, p):
        m = self._run(p, _DIGIT | {"."})
        if m <= p or m != self.n:
            raise _Malformed
        parts = self.t[p:m].split(".")
        if len(parts) != 4 or any(not x or int(x) > 255 for x in parts):
            raise _Malformed
        return m

    def _hex_post(self, p):
        if p == self.n:
            return p
        q = self._hex_seq(p)
        if q > p:
            p = q
            if self._at(p, ":"):
                p = self._take_ipv4(p + 1)
                self.count += 4
        else:
            p = self._take_ipv4(p)
            self.count += 4
        return p

    def valid(self):
        try:
            p = 0
            compressed = False
            q = self._hex_seq(p)
            if q > p:
                p = q
                if self._at(p, "::"):
                    compressed = True
                    p = self._hex_post(p + 2)
                elif self._at(p, ":"):
                    p = self._take_ipv4(p + 1)
                    self.count += 4
            elif self._at(p, "::"):
                compressed = True
                p = self._hex_post(p + 2)
            if p < self.n or self.count > 16:
                return False
            if not compressed and self.count < 16:
                return False
            return not (compressed and self.count == 16)
        except _Malformed:
            return False


def _ipv4_quad_end(a, p, n):
    """End of a dotted IPv4 address (four numbers up to 255, any number of digits) that starts at ``p`` and is followed by the end or a ':'
    - or -1: java.net.URI then tries the text as a host name."""
    m = p
    while m < n and (a[m] in _DIGIT or a[m] == "."):
        m += 1
    if m <= p:
        return -1
    parts = a[p:m].split(".")
    if len(parts) != 4 or any(not x or int(x) > 255 for x in parts):
        return -1
    if m < n and a[m] != ":":
        return -1
    return m


def _hostname_end(a, start, n):
    """End of a host name in a[start:n] (labels of letters, digits and inner '-', separated by dots; one dot may end it; a last label that
    is not the only one starts with a letter), or -1. It stops at the ':' of a port."""
    p = start
    last = -1
    while True:
        q = p
        while q < n and a[q] in _ALNUM:
            q += 1
        if q <= p:
            break
        last = p
        p = q
        while q < n and (a[q] in _ALNUM or a[q] == "-"):
            q += 1
        if q > p:
            if a[q - 1] == "-":
                return -1
            p = q
        if not (p < n and a[p] == "."):
            break
        p += 1
        if p >= n:
            break
    if p < n and a[p] != ":":
        return -1
    if last < 0:
        return -1
    if last > start and a[last] not in _ALPHA:
        return -1
    return p


def _parse_server(authority):
    """``(user, host, port)`` when java.net.URI reads ``authority`` as [user@]host[:port], else None (a registry name, or nothing: the
    address then has no host). ``port`` is -1 when there is none."""
    n = len(authority)
    if any(c not in _SERVER for c in authority):
        return None
    p = 0
    user = None
    at = authority.find("@")
    if at >= 0:
        if not _legal(authority[:at], _USERINFO):
            return None
        user = authority[:at]
        p = at + 1
    if p < n and authority[p] == "[":
        close = authority.find("]", p + 1)
        if close <= p + 1:
            return None
        inner = authority[p + 1:close]
        pct = inner.find("%")
        if pct > 0:
            scope = inner[pct + 1:]
            if not scope or any(c not in _SCOPE_ID for c in scope):
                return None
            inner = inner[:pct]
        if not _V6Syntax(inner).valid():
            return None
        host = authority[p:close + 1]
        p = close + 1
    else:
        q = _ipv4_quad_end(authority, p, n)
        if q <= p:
            q = _hostname_end(authority, p, n)
        if q <= p:
            return None
        host = authority[p:q]
        p = q
    port = -1
    if p < n:
        if authority[p] != ":":
            return None
        digits = authority[p + 1:]
        if digits:
            if not all(c in _DIGIT for c in digits) or int(digits) > 0x7FFFFFFF:
                return None
            port = int(digits)
        p = n
    return user, host, port


def host_of(url):
    """The host of an address, or None when it has none or cannot be read."""
    if not url or len(url) > MAX_REFERENCE_LENGTH or any(ord(c) <= 0x20 or ord(c) >= 0x7F for c in url):
        return None
    scheme, authority, problem = _uri_authority(url)
    if problem is not None or authority is None:
        return None
    parsed = _parse_server(authority)
    return None if parsed is None else parsed[1]


def refuse(url, site_host, allow_loopback_http=False):
    """Why ``url`` must not be fetched, or None when it may be. It looks at the address only (no network).

    ``allow_loopback_http``: tests, and a person running their own asset server on this machine - a plain http address whose host is the
    loopback address is accepted (nothing else ever is)."""
    if not url:
        return "the address is empty"
    if len(url) > MAX_REFERENCE_LENGTH:
        return f"the address is longer than {MAX_REFERENCE_LENGTH} characters"
    for c in url:
        if ord(c) <= 0x20 or ord(c) >= 0x7F:
            return "the address contains a space, a control character or a non-ASCII character"
        if c == "\\":
            return "the address contains a backslash"
    scheme, authority, problem = _uri_authority(url)
    if problem is not None:
        return f"the address is not well formed ({problem})"
    if scheme is None:
        return "the address has no scheme"
    scheme = scheme.lower()
    parsed = None if authority is None else _parse_server(authority)
    if parsed is None:
        return "the address has no host"
    user, host, port = parsed
    if user is not None:
        return "the address carries a user name (user@host): it is how an address is made to look like another"
    if port == 0 or port > 65535:
        return "the port is out of range"
    # "localhost." is "localhost": the root dot never changes what a host is, so it never changes the verdict
    bare = host[:-1] if host.endswith(".") else host
    loopback = _is_loopback_host(bare)
    if scheme == "http":
        if not (allow_loopback_http and loopback):
            return "only https addresses are fetched"
        return None
    if scheme != "https":
        return f"only https addresses are fetched (not {scheme}:)"
    if is_trusted_host(host, site_host):
        if port != -1 and port != 443:
            return "the project's own host is only reached on the standard port"
        return None
    bracketed = bare.startswith("[")
    literal = literal_address(bare)
    if literal is not None:
        if not is_public_address(literal):
            return "the host is an address of a private or local network"
        if not bracketed and parse_dotted_decimal(bare) is None:
            return "the host is an address written in an unusual form (only a.b.c.d is fetched)"
        return None
    if bracketed:
        return "the host is a malformed IPv6 address"
    if ends_with_number(bare):
        return "the host looks like an IP address but is not a valid one"
    if _is_local_name(bare):
        return "the host is a name of the person's own machine or network"
    return None


def ends_with_number(host):
    """True when the last part of the host (after its last dot) is only digits, or ``0x`` and hexadecimal digits: how every resolver
    tells an address from a name."""
    last = host[host.rfind(".") + 1:]
    if not last:
        return False
    if all(c in _DIGIT for c in last):
        return True
    return len(last) >= 2 and last[0] == "0" and last[1] in "xX" and all(c in _HEX for c in last[2:])


def parse_dotted_decimal(text):
    """The four bytes of ``a.b.c.d`` written the one way nobody reads two ways - four decimal numbers of one to three digits, from 0 to
    255, without a zero in front (octal to some tools, decimal to others) - or None for anything else."""
    parts = text.split(".")
    if len(parts) != 4:
        return None
    out = []
    for p in parts:
        if not p or len(p) > 3 or (len(p) > 1 and p[0] == "0") or any(c not in _DIGIT for c in p):
            return None
        v = int(p)
        if v > 255:
            return None
        out.append(v)
    return bytes(out)


def _is_local_name(host):
    """localhost, and the names that only mean something inside one network (.local, .internal, .localhost, .lan, .home.arpa)."""
    h = host.lower()
    return (h.endswith(".localhost") or h.endswith(".local") or h.endswith(".internal") or h.endswith(".lan")
            or h.endswith(".home.arpa") or "." not in h)       # a single label ("localhost", "router") is never a public name


def _is_loopback_host(host):
    if host.lower() == "localhost":
        return True
    literal = literal_address(host)
    if literal is None:
        return False
    if len(literal) == 4:
        return literal[0] == 127
    return all(b == 0 for b in literal[:15]) and literal[15] == 1


def describe_address(address):
    """'127.0.0.1' / '::1' for the 4 or 16 bytes of an address (an address that is neither is just called one)."""
    import socket
    try:
        return socket.inet_ntop(socket.AF_INET if len(address) == 4 else socket.AF_INET6, bytes(address))
    except (OSError, ValueError):
        return "an address"


def refuse_resolved(host, resolver, site_host):
    """Why the host NAME of an address must not be fetched from, judged by the addresses it resolves to - or None. A name that points into
    the person's own network (a name made to answer 127.0.0.1) is as much a way in as the address itself. Nothing is looked up for the
    project's own host, nor for a host written as an address (``refuse`` has judged those). ``resolver(host)`` returns the addresses
    (4 or 16 bytes each) the system gives the name - none when it gives none (the request itself then fails with its own message).

    Not covered, and said so in the documentation: a name that answers differently when the request is made than when it was checked
    (DNS rebinding) - the same limit as the engine's."""
    if is_trusted_host(host, site_host) or literal_address(host) is not None:
        return None
    for address in resolver(host):
        if not is_public_address(address):
            return f"'{printable(host)}' resolves to {describe_address(address)}, an address of a private or local network"
    return None


# ---- addresses -------------------------------------------------------------------------------------------------------------------------------------

def literal_address(host):
    """The bytes of a host that is written as an IP address, in any of the forms an operating system reads (dotted quad, one decimal
    number, octal or hexadecimal parts, an IPv6 literal in brackets); None when it is a name. Nothing is looked up."""
    if host is None:
        return None
    if host.startswith("[") and host.endswith("]"):
        return parse_ipv6(host[1:-1])
    if ":" in host:
        return parse_ipv6(host)
    return parse_loose_ipv4(host)


def _digit(c, radix):
    try:
        v = int(c, 36) if c.isascii() and c.isalnum() else -1
    except ValueError:
        return -1
    return v if 0 <= v < radix else -1


def parse_loose_ipv4(host):
    """inet_aton's reading: one to four parts, each decimal, 0-octal or 0x-hexadecimal; the last part fills the remaining bytes. None for a name."""
    parts = host.split(".")
    if len(parts) < 1 or len(parts) > 4:
        return None
    values = []
    for p in parts:
        if p == "":
            return None
        radix, digits = 10, p
        if len(p) > 1 and (p.startswith("0x") or p.startswith("0X")):
            radix, digits = 16, p[2:]
            if not digits:
                return None
        elif len(p) > 1 and p.startswith("0"):
            radix, digits = 8, p[1:]
        for c in digits:
            if _digit(c, radix) < 0:
                return None           # a letter or an out-of-radix digit: this is a name
        if len(digits) > 11:
            return None
        values.append(int(digits, radix))
    last = len(parts) - 1
    limit_last = 1 << (8 * (4 - last))
    for v in values[:last]:
        if v > 255:
            return None
    if values[last] >= limit_last:
        return None
    total = values[last]
    for i in range(last):
        total |= values[i] << (8 * (3 - i))
    return bytes([(total >> 24) & 0xFF, (total >> 16) & 0xFF, (total >> 8) & 0xFF, total & 0xFF])


def _split_groups(s):
    if s == "":
        return []
    groups = s.split(":")
    return None if any(g == "" for g in groups) else groups


def _hex_word(g):
    if len(g) > 4:
        return -1
    v = 0
    for c in g:
        d = _digit(c, 16)
        if d < 0:
            return -1
        v = v * 16 + d
    return v


def parse_ipv6(text):
    """An IPv6 literal (without brackets, may end in a dotted IPv4) as 16 bytes; None when it is not one."""
    zone = text.find("%")
    if zone >= 0:
        text = text[:zone]
    last_colon = text.rfind(":")
    tail = text[last_colon + 1:]
    if "." in tail:
        v4 = parse_dotted_decimal(tail)      # inside an IPv6 address the four bytes are decimal numbers, never octal or hexadecimal
        if v4 is None:
            return None
        text = text[:last_colon + 1] + format((v4[0] << 8) | v4[1], "x") + ":" + format((v4[2] << 8) | v4[3], "x")
    dbl = text.find("::")
    head = _split_groups(text[:dbl]) if dbl >= 0 else _split_groups(text)
    rest = _split_groups(text[dbl + 2:]) if dbl >= 0 else []
    if head is None or rest is None:
        return None
    groups = len(head) + len(rest)
    if (groups > 7) if dbl >= 0 else (groups != 8):
        return None
    words = [0] * 8
    for i, g in enumerate(head):
        words[i] = _hex_word(g)
    for i, g in enumerate(rest):
        words[8 - len(rest) + i] = _hex_word(g)
    if any(w < 0 for w in words):
        return None
    out = bytearray()
    for w in words:
        out.append((w >> 8) & 0xFF)
        out.append(w & 0xFF)
    return bytes(out)


def is_public_address(address):
    """True when ``address`` (4 bytes, IPv4, or 16 bytes, IPv6) belongs to the public internet; False for everything that is only
    reachable from inside a network: this machine, a private range, link-local (169.254.x.x, which holds cloud metadata services), shared
    address space, documentation, multicast, reserved ranges - and an IPv6 address that wraps one of those."""
    if address is None:
        return False
    if len(address) == 4:
        return _is_public_v4(address)
    if len(address) != 16:
        return False
    if all(b == 0 for b in address[:10]) and address[10] == 0xFF and address[11] == 0xFF:
        return _is_public_v4(address[12:16])           # ::ffff:a.b.c.d is the IPv4 address a.b.c.d
    b0, b1, b2, b3 = address[0], address[1], address[2], address[3]
    if b0 == 0x00 and b1 == 0x64 and b2 == 0xFF and b3 == 0x9B:       # 64:ff9b::/96 (NAT64) carries an IPv4 address
        return all(b == 0 for b in address[4:12]) and _is_public_v4(address[12:16])
    # Of the rest, only global unicast (2000::/3) is the public internet
    if (b0 & 0xE0) != 0x20:
        return False
    if b0 == 0x20 and b1 == 0x01 and b2 == 0x00 and b3 == 0x00:
        return False                                    # 2001::/32 Teredo
    if b0 == 0x20 and b1 == 0x01 and b2 == 0x0D and b3 == 0xB8:
        return False                                    # 2001:db8::/32 documentation
    if b0 == 0x20 and b1 == 0x01 and b2 == 0x00 and b3 == 0x02 and address[4] == 0 and address[5] == 0:
        return False                                    # 2001:2::/48 benchmarking
    if b0 == 0x3F and b1 == 0xFF and (b2 & 0xF0) == 0:
        return False                                    # 3fff::/20 documentation
    if b0 == 0x20 and b1 == 0x02:
        return _is_public_v4(address[2:6])              # 2002::/16 (6to4) carries an IPv4 address
    return True


def _is_public_v4(a):
    b0, b1, b2 = a[0], a[1], a[2]
    if b0 == 0 or b0 == 10 or b0 == 127:
        return False                                    # this network, private, loopback
    if b0 >= 224:
        return False                                    # multicast and everything reserved above it
    if b0 == 100 and 64 <= b1 <= 127:
        return False                                    # 100.64/10 carrier-grade NAT
    if b0 == 169 and b1 == 254:
        return False                                    # link-local, cloud metadata
    if b0 == 172 and 16 <= b1 <= 31:
        return False                                    # private
    if b0 == 192 and b1 == 168:
        return False                                    # private
    if b0 == 192 and b1 == 0 and b2 == 0:
        return False                                    # IETF protocol assignments
    if b0 == 192 and b1 == 0 and b2 == 2:
        return False                                    # documentation
    if b0 == 192 and b1 == 88 and b2 == 99:
        return False                                    # 6to4 relay anycast
    if b0 == 198 and b1 in (18, 19):
        return False                                    # benchmarking
    if b0 == 198 and b1 == 51 and b2 == 100:
        return False                                    # documentation
    if b0 == 203 and b1 == 0 and b2 == 113:
        return False                                    # documentation
    return True


# ---- file references -------------------------------------------------------------------------------------------------------------------------------

def refuse_local_reference(reference):
    """Why ``reference`` must not be read as a file on the disk, or None when it may be. A reference is the text after ``source =`` or
    ``include_material``: written by whoever wrote the scene. A relative path or an ordinary absolute one is the person's own business;
    a network path, an address of another kind and an alternate data stream are not a file of theirs at all."""
    if not reference:
        return "the reference is empty"
    if len(reference) > MAX_REFERENCE_LENGTH:
        return f"the reference is longer than {MAX_REFERENCE_LENGTH} characters"
    for c in reference:
        if ord(c) < 0x20 or ord(c) == 0x7F:
            return "the reference contains a control character"
    c0 = reference[0]
    c1 = reference[1] if len(reference) > 1 else "\0"
    if c0 in "\\/" and c1 in "\\/":
        return "the reference is a network path (\\\\host\\share or //host/share)"
    start = 2 if (c1 == ":" and c0.isalpha()) else 0       # "C:" is a drive; any other ':' is not part of a file name
    colon = reference.find(":", start)
    if colon >= 0:
        if reference.startswith("//", colon + 1):
            return f"the reference is an address ({reference[:colon + 1]}), not a file"
        return "the reference contains a ':' (an address of another kind, or an alternate data stream)"
    return None


# ---- reading with a cap ----------------------------------------------------------------------------------------------------------------------------

def read_capped(stream, limit, what):
    """Reads ``stream`` to its end, but never more than ``limit`` bytes: one byte over and it stops with a Refused that names ``what``."""
    chunks = []
    total = 0
    while True:
        chunk = stream.read(64 * 1024)
        if not chunk:
            break
        total += len(chunk)
        if total > limit:
            raise Refused(f"{what} is larger than {describe(limit)} - refused")
        chunks.append(chunk)
    return b"".join(chunks)


def read_file_capped(path, limit, what=None):
    """The bytes of a file on the disk, refused (before a byte of it is read) when it is larger than ``limit``."""
    what = what or f"'{os.path.basename(path)}'"
    size = os.path.getsize(path)
    if size > limit:
        raise Refused(f"{what} is larger than {describe(limit)} - refused")
    with open(path, "rb") as f:
        return read_capped(f, limit, what)


def read_text_capped(path, limit=MAX_TEXT_BYTES):
    """The text of a scene or material file (UTF-8), refused when it is larger than ``limit`` bytes."""
    return read_file_capped(path, limit).decode("utf-8")


def gunzip_capped(data, limit, what):
    """The gzip stream ``data`` decompressed - to at most ``limit`` bytes: a small file that expands to gigabytes ends in a message, not
    in Blender going down. Members written one after the other are read as one stream, as every gzip reader does."""
    out = []
    total = 0
    pending = data
    members = 0
    while pending:
        decoder = zlib.decompressobj(16 + zlib.MAX_WBITS)
        try:
            chunk = decoder.decompress(pending, limit - total + 1)
        except zlib.error as e:
            raise Refused(f"{what} is not a valid gzip stream ({e})") from e
        total += len(chunk)
        if total > limit:       # (the chunk is cut at one byte over: a stream that goes on is not read further)
            raise Refused(f"{what} is larger than {describe(limit)} once decompressed - refused")
        if not decoder.eof:
            raise Refused(f"{what} is a gzip stream that ends too early")
        out.append(chunk)
        members += 1
        pending = decoder.unused_data
    if members == 0:
        raise Refused(f"{what} holds no gzip data")
    return b"".join(out)


def is_within(root, path):
    """True when ``path`` is ``root`` or lies below it, both made absolute and normalised (no link is followed: what is checked is the
    name, and the names inside a bundle are the ones this module wrote)."""
    base = os.path.normcase(os.path.abspath(root))
    target = os.path.normcase(os.path.abspath(path))
    return target == base or target.startswith(base.rstrip(os.sep) + os.sep)


_BUNDLE_ROOTS = []


def register_bundle_root(folder):
    """Remembers a folder a bundle was unpacked into: a file inside it may refer to files of the bundle and to nothing outside it
    (``bundle_root_of`` tells, and the readers of references refuse the rest) - as the engine's PbdParser does with its sandbox."""
    root = os.path.abspath(folder)
    if root not in _BUNDLE_ROOTS:
        _BUNDLE_ROOTS.append(root)
    return root


def forget_bundle_root(folder):
    """The folder is not a bundle's any more (its unpacking failed and it was removed)."""
    root = os.path.abspath(folder)
    if root in _BUNDLE_ROOTS:
        _BUNDLE_ROOTS.remove(root)


def bundle_root_of(path):
    """The unpacked bundle ``path`` is inside, or None."""
    for root in _BUNDLE_ROOTS:
        if is_within(root, path):
            return root
    return None


# ---- bundles ---------------------------------------------------------------------------------------------------------------------------------------

def is_windows_device_name(segment):
    """CON, PRN, AUX, NUL, COM1-9, LPT1-9, with or without an extension, in any case: names Windows gives to devices."""
    stem = segment.split(".", 1)[0].upper()
    if stem in ("CON", "PRN", "AUX", "NUL"):
        return True
    return len(stem) == 4 and stem[:3] in ("COM", "LPT") and "1" <= stem[3] <= "9"


def entry_target(root, entry_name):
    """Where the bundle entry ``entry_name`` may be written below ``root``, or None when its name is not a plain relative path that
    stays inside: an absolute path, a drive, a backslash, a ``..`` segment, an empty segment, a control character, a name too long -
    and, whatever the name looks like, a path that resolves outside ``root``.

    Windows reads a name differently from the way a Unix writes it: it drops the dots and spaces that end a name and answers to the
    names of its devices instead of making a file. A bundle is made on one system and opened on another, so a name that means
    something else somewhere is refused everywhere."""
    if not entry_name or len(entry_name.encode("utf-16-le")) // 2 > MAX_ENTRY_NAME_LENGTH:
        return None
    if entry_name.startswith("/") or "\\" in entry_name or ":" in entry_name:
        return None
    if any(ord(c) < 0x20 or ord(c) == 0x7F for c in entry_name):
        return None
    for segment in entry_name.split("/"):
        if segment == "":
            return None                                  # "a//b", a name that ends with "/"
        if segment.endswith(".") or segment.endswith(" "):
            return None                                  # ".", "..", "a.", ".. "
        if is_windows_device_name(segment):
            return None
    base = os.path.abspath(root)
    target = os.path.normpath(os.path.join(base, entry_name))
    if target == base or not target.startswith(base.rstrip(os.sep) + os.sep):
        return None
    return target


def unpack_asset(zip_path, out_dir, max_entries=MAX_ASSET_ENTRIES, max_entry_bytes=MAX_ASSET_ENTRY_BYTES,
                 max_total_bytes=MAX_ASSET_TOTAL_BYTES):
    """Extracts a ``.pbdasset`` into ``out_dir``, keeping the archive's own relative paths. A bundle comes from anywhere: what an entry
    is called decides where it is written, and what it weighs is not what its header says - so every name is checked before the first
    byte is written, and the bytes are counted as they are read (each entry, and all of them together), never held in memory whole.
    Returns {entry name: written path}; raises Refused for a bundle that asks for too much or cannot be read - and then nothing of it
    is left in ``out_dir``. What the archive says about an entry other than its name and its bytes (a permission, a link) is ignored:
    an entry is always written as a plain file."""
    import zipfile
    label = os.path.basename(zip_path)
    try:
        archive = zipfile.ZipFile(zip_path)
    except zipfile.BadZipFile as e:
        raise Refused(f"'{label}' is not a valid bundle ({e})") from e
    created = []
    written = {}
    try:
        with archive:
            files = [info for info in archive.infolist() if not info.is_dir()]
            if len(files) > max_entries:
                raise Refused(f"'{label}' holds more than {max_entries} files - refused")
            targets = []
            for info in files:
                target = entry_target(out_dir, info.filename)
                if target is None:
                    raise Refused(f"'{label}' has an entry whose name is not a plain relative path ({printable(info.filename)}) - refused")
                targets.append(target)
            os.makedirs(out_dir, exist_ok=True)
            total = 0
            for info, target in zip(files, targets):
                shown = printable(info.filename)
                size = 0
                os.makedirs(os.path.dirname(target), exist_ok=True)
                if os.path.islink(target) or not is_within(os.path.realpath(out_dir), os.path.realpath(os.path.dirname(target))):
                    raise Refused(f"the entry '{shown}' of '{label}' would be written through a link - refused")
                with archive.open(info) as source, open(target, "wb") as out:
                    created.append(target)
                    while True:
                        chunk = source.read(64 * 1024)
                        if not chunk:
                            break
                        size += len(chunk)
                        total += len(chunk)
                        if size > max_entry_bytes:
                            raise Refused(f"the entry '{shown}' of '{label}' is larger than {describe(max_entry_bytes)} - refused")
                        if total > max_total_bytes:
                            raise Refused(f"'{label}' expands to more than {describe(max_total_bytes)} - refused")
                        out.write(chunk)
                written[info.filename] = target
    except (zipfile.BadZipFile, zlib.error, EOFError, NotImplementedError, RuntimeError) as e:
        # a damaged entry, a compression this Python cannot read, an entry that wants a password
        _remove_all(created)
        raise Refused(f"'{label}' cannot be unpacked ({e})") from e
    except BaseException:
        _remove_all(created)
        raise
    return written


def _remove_all(paths):
    for path in paths:
        try:
            os.remove(path)
        except OSError:
            pass


# ---- one budget for a whole import -----------------------------------------------------------------------------------------------------------------

class ImportBudget:
    """What one import (a scene and everything its ``pbd_ref`` blocks bring in) may ask in all: instances created and files opened. A
    scene that includes ten copies of a scene that includes ten copies of a scene is a few lines for a billion instances; the
    depth limit alone does not stop it, a shared count does."""

    def __init__(self, max_instances=MAX_IMPORT_INSTANCES, max_files=MAX_FETCHES_PER_LOAD):
        self.max_instances = max_instances
        self.max_files = max_files
        self.instances = 0
        self.files = 0

    def open_file(self, what):
        """Counts a file opened through a reference; raises Refused when it is one too many."""
        self.files += 1
        if self.files > self.max_files:
            raise Refused(f"this import opens more than {self.max_files} files (at '{printable(what)}') - refused")

    def add_instances(self, count, what):
        """Counts the instances a file is about to create; raises Refused when the import would hold more than it may."""
        if self.instances + count > self.max_instances:
            raise Refused(f"this import would create more than {self.max_instances} objects ('{printable(what)}' brings {count} more "
                          f"to the {self.instances} already made) - refused")
        self.instances += count
