bl_info = {
    "name": "PBD Format Tools",
    "author": "pbd-benchmark",
    "version": (0, 48, 2),
    "blender": (4, 0, 0),
    "location": "View3D > Sidebar > PBD tab, Add > Mesh, File > Export",
    "description": "Create and export PBD (Primitive Based Description) primitives",
    "category": "Import-Export",
}

import sys


def _forget_loaded_submodules():
    """Blender keeps an add-on's modules in memory. A newer copy installed over a running one, and the add-on switched off and on again, makes
    Blender run THIS file once more (it reloads the package) - and the imports below then find the OLD sub-modules still there: `from . import
    ui_panel` does not read a file when the package already has an attribute of that name, it hands that one back. The new package would run on
    the old panel and the old buttons, and a title read from bl_info (this file) would name the new version over the old code. So the modules
    are let go of first, from the table Python keeps and from the package's own names, and the imports read the files that are on disk now.
    The first time the package is imported there is nothing to let go of."""
    prefix = __name__ + "."
    for name in [n for n in sys.modules if n.startswith(prefix)]:
        del sys.modules[name]
        globals().pop(name[len(prefix):].split(".")[0], None)


_forget_loaded_submodules()

from . import materials
from . import properties
from . import ui_panel
from .operators import add_mechanism
from .operators import add_primitive
from .operators import export_pbd
from .operators import import_pbd
from .operators import upload_server

_MODULES = (materials, properties, add_primitive, add_mechanism, export_pbd, import_pbd, upload_server, ui_panel)


def register():
    for module in _MODULES:
        module.register()


def unregister():
    for module in reversed(_MODULES):
        module.unregister()
