"""
Imports a .pbd file (and its include_material .pbdmat, if any) into the
current Blender scene, reconstructing objects with the right type,
transform, material, modifiers, keyframes, and PBD-specific flags
(metadata, linkGroup) - the inverse of export_pbd.py.

The text parser below is a small hand-rolled recursive-descent reader
matching PbdParser.java's own grammar (see that file for the
authoritative spec) - not a wrapper around it, since this runs inside
Blender's own Python with no JVM available. Kept deliberately close to
the Java parser's structure (same field names, same block shapes) so the
two stay easy to compare and keep in sync by hand if the format changes.
"""

import math
import os
import tempfile

import bmesh
import bpy
import mathutils

from .. import anim_compat
from . import export_pbd  # for _BLENDER_TO_SHADER_SCALE and _to_pbd_matrix - see below
from .. import materials as materials_module
from .. import mesh_preview  # for _pbd_to_blender - mesh vertex data needs the same axis remap as everything else


# ---------------------------------------------------------------------
# Tokenizing / low-level parsing helpers
# ---------------------------------------------------------------------

class ParseError(Exception):
    pass


class _Reader:
    """Character-index cursor over the whole file text, mirroring
    PbdParser.java's own reader style (skip whitespace/comments, read an
    identifier, expect a specific character) rather than a line-oriented
    approach - this format nests braces and puts multiple fields on one
    line freely, so a line-by-line reader would need most of the same
    logic anyway."""

    def __init__(self, text):
        self.text = text
        self.pos = 0

    def peek(self):
        self._skip_ws()
        return self.text[self.pos] if self.pos < len(self.text) else ''

    def _skip_ws(self):
        while self.pos < len(self.text):
            c = self.text[self.pos]
            if c in ' \t\r\n':
                self.pos += 1
            elif c == '#':
                nl = self.text.find('\n', self.pos)
                self.pos = len(self.text) if nl == -1 else nl + 1
            elif self.text.startswith('//', self.pos):
                nl = self.text.find('\n', self.pos)
                self.pos = len(self.text) if nl == -1 else nl + 1
            else:
                break

    def at_end(self):
        self._skip_ws()
        return self.pos >= len(self.text)

    def expect(self, ch):
        self._skip_ws()
        if self.pos >= len(self.text) or self.text[self.pos] != ch:
            got = self.text[self.pos:self.pos + 20] if self.pos < len(self.text) else '<EOF>'
            raise ParseError(f"Expected '{ch}' at position {self.pos}, got: {got!r}")
        self.pos += 1

    def read_identifier(self):
        self._skip_ws()
        start = self.pos
        while self.pos < len(self.text) and (self.text[self.pos].isalnum() or self.text[self.pos] in '_.'):
            self.pos += 1
        if start == self.pos:
            raise ParseError(f"Expected identifier at position {self.pos}, got: {self.text[self.pos:self.pos+20]!r}")
        return self.text[start:self.pos]

    def read_raw_value(self):
        """A quoted string, a (a,b,c)/[a,b,c] tuple, or a bare word/number
        - read up to (but not past) the next unescaped comma or closing
        brace at THIS nesting level. Mirrors PbdParser.readRawValue: the
        exact delimiter set matters (comma is a value separator inside a
        modifier/keyframe block's single line, e.g. 'axis=x angle=30' has
        no commas at all, but 'pos=(1,2,3)' does inside the parens)."""
        self._skip_ws()
        start = self.pos
        if self.pos < len(self.text) and self.text[self.pos] == '"':
            self.pos += 1
            s = self.pos
            while self.pos < len(self.text) and self.text[self.pos] != '"':
                self.pos += 1
            value = self.text[s:self.pos]
            self.pos += 1  # closing quote
            return value
        depth = 0
        while self.pos < len(self.text):
            c = self.text[self.pos]
            if c in '([':
                depth += 1
            elif c in ')]':
                depth -= 1
            elif c == '}' and depth <= 0:
                break
            elif c in ' \t\r\n' and depth <= 0:
                # a bare word ends at whitespace UNLESS we're still inside
                # a tuple's parens (spaces after commas are common: "(1, 2, 3)")
                break
            self.pos += 1
        return self.text[start:self.pos].strip()


def _apply_removed_faces(pbd_props, raw):
    """Inverse of export_pbd.py's _removed_face_codes: raw is the faces=
    value, e.g. '(-y,+z)' - strip the parens, split on comma, and
    uncheck whichever Blender-labeled boolean corresponds to each
    canonical PBD code (same index table as export, just written the
    other direction: canonical -> Blender rather than Blender -> canonical).
    Unrecognized codes are ignored with a print rather than raising, so a
    hand-edited file with a typo doesn't block the whole import."""
    inner = raw.strip()
    if inner.startswith('(') and inner.endswith(')'):
        inner = inner[1:-1]
    code_to_blender_attr = {
        '+x': 'pbd_cube_face_posx', '-x': 'pbd_cube_face_negx',
        '+y': 'pbd_cube_face_posz', '-y': 'pbd_cube_face_negz',
        '+z': 'pbd_cube_face_negy', '-z': 'pbd_cube_face_posy',
    }
    for token in inner.split(','):
        code = token.strip().lower()
        if not code:
            continue
        attr = code_to_blender_attr.get(code)
        if attr is None:
            print(f"[import_pbd] Unknown face code '{code}' in faces={raw!r} - skipped")
            continue
        setattr(pbd_props, attr, False)


def _parse_vec3(raw):
    inner = raw.strip()
    if inner.startswith('(') and inner.endswith(')'):
        inner = inner[1:-1]
    parts = [p.strip() for p in inner.split(',')]
    return tuple(float(p) for p in parts)


# ---------------------------------------------------------------------
# Top-level .pbd parsing
# ---------------------------------------------------------------------

def _decompress_pbdbin(pbdbin_path):
    """Inverse of PbdBinFormat.java's write(): 4-byte 'PBDB' magic + 1
    version byte, then gzip-compressed minified .pbd text. Returns
    (decompressed_pbd_path, warning_or_None).

    Writes the decompressed text to a temp .pbd file NEXT TO the
    original .pbdbin (not an unrelated system temp directory) - that
    placement is what actually matters here, not just a detail: a
    relative include_material= inside the decompressed text resolves
    against wherever THIS file lands, so writing it anywhere other than
    beside the original .pbdbin (where the referenced .pbdmat actually
    lives) silently breaks materials, exactly the same bug the Java side
    had before PbdBinFormat.read() was fixed to pass a real baseDir -
    caught here by actually running this against a real materials-
    referencing .pbdbin rather than assuming the same fix pattern
    carried over automatically. Named after the ORIGINAL .pbdbin (not a
    random temp suffix) so a multi-top-level-instance import's grouping
    root (see import_pbd_file's own doc) gets a sensible name instead of
    an opaque temp filename. Falls back to a real system temp directory
    (with a warning) if the original's directory isn't writable - a
    shared/distributed read-only asset, say - which still imports the
    instances themselves, just without a relative include_material=
    resolving correctly. Caller is responsible for deleting the
    returned path once import is done, if leaving it around isn't
    wanted - not deleted here, since deleting SOMETHING'S source-of-
    truth file while import_pbd_file might still be about to re-read it
    (materials in particular) would be its own bug."""
    import gzip
    with open(pbdbin_path, 'rb') as f:
        data = f.read()
    if len(data) < 5 or data[:4] != b'PBDB':
        raise ValueError("missing PBDB magic header - not a .pbdbin file")
    version = data[4]
    if version != 1:
        raise ValueError(f".pbdbin version {version} is not supported (this reader only knows version 1)")
    text = gzip.decompress(data[5:]).decode('utf-8')
    base = os.path.splitext(os.path.basename(pbdbin_path))[0]
    sibling_path = os.path.join(os.path.dirname(os.path.abspath(pbdbin_path)), f".{base}_decompressed.pbd")
    try:
        with open(sibling_path, 'w', encoding='utf-8') as f:
            f.write(text)
        return sibling_path, None
    except OSError:
        # Read-only location (a shared/distributed asset, say) - falls
        # back to a system temp dir, which WILL break a relative
        # include_material= (nothing to be done about that without write
        # access next to the original), but at least still imports the
        # instances themselves rather than failing outright.
        fd, tmp_path = tempfile.mkstemp(suffix='.pbd', prefix=f'{base}_decompressed_')
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            f.write(text)
        return tmp_path, (f"Could not write next to {pbdbin_path} (read-only?) - used a temp "
                           f"location instead, so a relative include_material= inside it won't "
                           f"resolve correctly")


def parse_pbd_file(filepath):
    """Returns (scene_meta_dict, include_material_filename_or_None,
    [instance_dict, ...]). scene_meta_dict has whichever of
    name/kind/authors(list)/origin were present - mirrors PbdParser.java's
    own top-level loop, which special-cases these exactly the same way
    (expects "=" then a value) rather than treating them as the start of
    a "TYPE NAME {" instance block the way every other top-level keyword
    is. Missing this case here specifically would have made this
    Python-side reader crash on any file this add-on's OWN exporter now
    writes, the moment scene-level metadata was added on the export side
    without a matching update here.

    Each instance dict has: type, id, fields (plain key->raw-string map),
    modifiers (list of {type, params}), keyframes (list of {time, pos, rot})."""
    with open(filepath, 'r', encoding='utf-8') as f:
        text = f.read()
    reader = _Reader(text)
    scene_meta = {}
    include_material = None
    instances = []

    while not reader.at_end():
        keyword = reader.read_identifier()
        if keyword == 'pbd_version':
            reader.read_raw_value()
            continue
        if keyword == 'include_material':
            include_material = reader.read_raw_value().strip('"')
            continue
        if keyword == 'name':
            reader.expect('=')
            scene_meta['name'] = reader.read_raw_value().strip('"')
            continue
        if keyword == 'kind':
            reader.expect('=')
            scene_meta['kind'] = reader.read_raw_value().strip('"')
            continue
        if keyword == 'author':
            reader.expect('=')
            scene_meta.setdefault('authors', []).append(reader.read_raw_value().strip('"'))
            continue
        if keyword == 'origin':
            reader.expect('=')
            scene_meta['origin'] = reader.read_raw_value().strip('"')
            continue
        # Otherwise: TYPE NAME { ... } - covers every primitive type and pbd_ref
        prim_type = keyword
        name = reader.read_identifier()
        inst = _parse_instance_body(reader, prim_type, name)
        instances.append(inst)

    return scene_meta, include_material, instances


def _parse_instance_body(reader, prim_type, name):
    inst = {'type': prim_type, 'id': name, 'fields': {}, 'modifiers': [], 'keyframes': [], 'containerTriggers': []}
    reader.expect('{')
    while reader.peek() != '}':
        key = reader.read_identifier()
        reader.expect('=') if reader.peek() == '=' else None
        # Some blocks (keyframe) use bare "key { ... }" with no '=' before
        # the brace - check for that before assuming a value follows.
        # "modifier" doesn't hit this case: its grammar is
        # "modifier TYPE { ... }" (a type word always comes between the
        # keyword and the brace), so it falls through to the raw-value
        # read below like any other field, with "modifier" handled
        # specially there once its raw value (the type word) is known.
        if reader.peek() == '{':
            body = _read_brace_block_fields(reader)
            if key == 'keyframe':
                inst['keyframes'].append(_keyframe_from_fields(body))
            continue
        raw = reader.read_raw_value()
        if key == 'modifier':
            # raw is actually the modifier's type word (e.g. "bend"),
            # read immediately before its own '{' - re-read properly:
            mod_type = raw
            reader.expect('{')
            params = {}
            while reader.peek() != '}':
                pkey = reader.read_identifier()
                reader.expect('=')
                params[pkey] = reader.read_raw_value()
                if reader.peek() == ',':
                    reader.pos += 1
            reader.expect('}')
            inst['modifiers'].append({'type': mod_type, 'params': params})
            continue
        if key == 'containerTrigger':
            inst['containerTriggers'].append(raw)
        else:
            inst['fields'][key] = raw
        if reader.peek() == ',':
            reader.pos += 1
    reader.expect('}')
    return inst


def _read_brace_block_fields(reader):
    reader.expect('{')
    fields = {}
    while reader.peek() != '}':
        key = reader.read_identifier()
        reader.expect('=')
        fields[key] = reader.read_raw_value()
        if reader.peek() == ',':
            reader.pos += 1
    reader.expect('}')
    return fields


def _keyframe_from_fields(fields):
    kf = {'time': float(fields.get('time', 0.0))}
    if 'pos' in fields:
        kf['pos'] = _parse_vec3(fields['pos'])
    if 'rot' in fields:
        kf['rot'] = _parse_vec3(fields['rot'])
    if 'scale' in fields:
        kf['scale'] = _parse_vec3(fields['scale'])
    if 'channel' in fields:
        kf['channel'] = fields['channel']
    if 'sound' in fields:
        kf['sound'] = fields['sound']
    return kf


# ---------------------------------------------------------------------
# PBD -> Blender axis conversion (inverse of export_pbd._to_pbd_matrix)
# ---------------------------------------------------------------------

def _to_blender_matrix(pbd_matrix):
    """Inverse of export_pbd._to_pbd_matrix - same axis-conversion
    matrix, applied on the opposite side. _to_pbd_matrix computes
    AXIS @ blender_matrix @ AXIS_INV; undoing that is AXIS_INV @
    pbd_matrix @ AXIS, i.e. swap which side AXIS and AXIS_INV go on. Not
    re-derived by hand here on purpose - see this project's own history
    of getting rotation axis conversions wrong when reasoned out fresh
    under time pressure; reusing the one place that conversion is
    already proven is the safer move."""
    axis = export_pbd._AXIS_CONVERSION
    axis_inv = axis.inverted()
    return axis_inv @ pbd_matrix @ axis


def _decode_mesh_data(raw_vertex_data, name):
    """Inverse of export_pbd.py's _export_mesh_vertex_data - decodes the
    same binary layout pbd.format.PbdMeshData uses (int32 vertexCount,
    int32 indexCount, per-vertex float32 x,y,z,nx,ny,nz,u,v, per-index
    int32, little-endian) and builds a real Blender Mesh DATABLOCK from
    it (not yet an Object - see _create_mesh_object_from_field below for
    the base/LOD-0 case, which wraps one in an Object; an LOD variant
    stays a bare datablock, never linked to any Object at all, matching
    how Capture/Apply store one on PbdMeshLodEntry). Indices come in
    groups of 3 (one per triangle corner, matching the export side's "no
    vertex sharing" choice), so reconstruction is a straight triangle
    fan, no face-merging needed."""
    import struct, base64
    if raw_vertex_data is None:
        raise ParseError(f"'mesh' instance '{name}' has no vertexData= field")
    encoded = raw_vertex_data[len('base64:'):] if raw_vertex_data.startswith('base64:') else raw_vertex_data
    buf = base64.b64decode(encoded)
    vertex_count, index_count = struct.unpack_from('<ii', buf, 0)
    offset = 8
    positions, normals, uvs = [], [], []
    for _ in range(vertex_count):
        x, y, z, nx, ny, nz, u, v = struct.unpack_from('<8f', buf, offset)
        offset += 32
        positions.append(mesh_preview._pbd_to_blender((x, y, z)))
        normals.append(mesh_preview._pbd_to_blender((nx, ny, nz)))
        uvs.append((u, v))
    indices = list(struct.unpack_from(f'<{index_count}i', buf, offset))

    bm = bmesh.new()
    bm_verts = [bm.verts.new(p) for p in positions]
    bm.verts.ensure_lookup_table()
    uv_layer = bm.loops.layers.uv.new("UVMap")
    for i in range(0, len(indices), 3):
        tri = indices[i:i + 3]
        try:
            face = bm.faces.new([bm_verts[j] for j in tri])
        except ValueError:
            continue  # degenerate/duplicate triangle - skip rather than fail the whole import
        for loop, vi in zip(face.loops, tri):
            loop[uv_layer].uv = uvs[vi]
    bm.normal_update()

    mesh = bpy.data.meshes.new(name + "_mesh")
    bm.to_mesh(mesh)
    bm.free()
    return mesh


def _create_mesh_object_from_field(raw_vertex_data, name):
    """The base/LOD-0 case: decodes and wraps the result in a real,
    linked, visible Object - unlike an LOD variant's mesh (see
    _decode_mesh_data), which stays an unlinked datablock forever."""
    mesh = _decode_mesh_data(raw_vertex_data, name)
    obj = bpy.data.objects.new(name, mesh)
    bpy.context.collection.objects.link(obj)
    bpy.context.view_layer.objects.active = obj
    for o in bpy.context.selected_objects:
        o.select_set(False)
    obj.select_set(True)
    return obj


def _pbd_transform_to_blender(pos, rot_deg, scale, apply_native_scale=True):
    """pos/rot_deg/scale as parsed from the .pbd text (PBD space) ->
    (blender_location, blender_euler, blender_scale). Builds the full
    TRS matrix in PBD space and decomposes the conjugated result for all
    three at once - mirroring _serialize_instance's own
    pbd_matrix.decompose() on the export side exactly. Scale can't be
    converted as 3 independent numbers the way position's axis remap
    works: it's expressed along the object's OWN rotated local axes, so
    it has to go through the same rotation-aware conjugation as
    position/rotation, not a separate per-component pass - the first
    version of this function did that and silently swapped Y/Z scale on
    any object with a non-trivial rotation, caught by round-tripping a
    rotated test object rather than only checking axis-aligned ones.

    apply_native_scale=False for 'mesh'/'ref' instances, whose export
    side never multiplied by _BLENDER_TO_SHADER_SCALE in the first place
    (see export_pbd.py's own scale_factor branch) - halving it back here
    regardless of type would shrink an imported mesh to half its real
    size."""
    rx, ry, rz = (math.radians(a) for a in rot_deg)
    rot_matrix = (mathutils.Matrix.Rotation(rz, 4, 'Z')
                  @ mathutils.Matrix.Rotation(ry, 4, 'Y')
                  @ mathutils.Matrix.Rotation(rx, 4, 'X'))
    scale_matrix = mathutils.Matrix.Diagonal((scale[0], scale[1], scale[2], 1.0))
    pbd_matrix = mathutils.Matrix.Translation(mathutils.Vector(pos)) @ rot_matrix @ scale_matrix
    blender_matrix = _to_blender_matrix(pbd_matrix)
    loc, rot_quat, blender_scale = blender_matrix.decompose()
    if apply_native_scale:
        blender_scale = tuple(s * 0.5 for s in blender_scale)  # inverse of _BLENDER_TO_SHADER_SCALE=2.0
    return loc, rot_quat.to_euler('XYZ'), blender_scale


# ---------------------------------------------------------------------
# Scene reconstruction
# ---------------------------------------------------------------------

_CAP_TYPES = {'cylinder', 'cone'}


def _create_object_for_instance(inst, base_dir):
    prim_type = inst['type']
    fields = inst['fields']
    name = inst['id']

    if prim_type in ('group', 'pbd_ref'):
        # 'pbd_ref' is the ACTUAL keyword any real file (Blender's own
        # export included - it never resolves a reference, just writes
        # it as-is) contains; 'group' is what the JAVA parser produces
        # internally ONLY after resolving one, never written to a file
        # by any serializer - this check used to only recognize 'group',
        # meaning it never matched a single real file, only ever an
        # in-memory Java structure this Python reader never receives.
        # Confirmed via a real reported failure: "Unknown primitive type
        # 'pbd_ref'".
        bpy.ops.object.add_pbd_ref()  # the DEDICATED ref-creation operator - add_pbd_primitive's own prim_type enum only lists procedural shapes (plane/sphere/.../torus), calling it with prim_type='ref' throws
        obj = bpy.context.active_object
        obj.pbd.pbd_type = 'ref'
    elif prim_type == 'mesh':
        obj = _create_mesh_object_from_field(fields.get('vertexData'), name)
        obj.pbd.is_pbd_primitive = True
        obj.pbd.pbd_type = 'mesh'
        # Reconstruct each vertexDataLod<N>= as a hidden Mesh datablock
        # stored directly on its pbd_mesh_lod_sources entry (see
        # PbdMeshLodEntry's own doc comment) - never linked to its own
        # Object/collection, so re-importing a file with LOD variants
        # doesn't fill the scene with extra visible objects the way an
        # earlier version of this (one full Object per variant) did.
        for key, raw in fields.items():
            if not key.startswith('vertexDataLod'):
                continue
            try:
                lod_n = int(key[len('vertexDataLod'):])
            except ValueError:
                continue
            lod_mesh = _decode_mesh_data(raw, f"{name}_LOD{lod_n}")
            lod_mesh.use_fake_user = True  # keeps it alive with zero Object users - that's the point, not an orphan to be purged
            entry = obj.pbd.pbd_mesh_lod_sources.add()
            entry.lod = lod_n
            entry.mesh_data = lod_mesh
    elif prim_type not in ('plane', 'sphere', 'cylinder', 'cone', 'cube', 'disc', 'torus'):
        raise ParseError(f"Unknown primitive type '{prim_type}' for instance '{name}' - "
                          "add it to both PrimitiveRegistry.java and this import module together")
    else:
        bpy.ops.object.add_pbd_primitive(prim_type=prim_type)
        obj = bpy.context.active_object

    obj.name = name

    pos = _parse_vec3(fields['pos']) if 'pos' in fields else (0.0, 0.0, 0.0)
    rot = _parse_vec3(fields['rot']) if 'rot' in fields else (0.0, 0.0, 0.0)
    scale = _parse_vec3(fields['scale']) if 'scale' in fields else (1.0, 1.0, 1.0)
    # 'mesh' and 'ref'/'group' never got the x2 _BLENDER_TO_SHADER_SCALE
    # factor applied on export (see export_pbd.py's scale_factor branch
    # and its "ref isn't a native-2x2x2-sized mesh" comment) - halving it
    # back here regardless of type used to silently shrink both to half
    # size on import, for 'ref' since this function was first written and
    # for 'mesh' it would have from the moment 'mesh' import existed.
    apply_native_scale = prim_type not in ('mesh', 'group')
    loc, euler, bscale = _pbd_transform_to_blender(pos, rot, scale, apply_native_scale)
    obj.location = loc
    obj.rotation_euler = euler
    obj.scale = bscale

    if 'mat' in fields:
        obj.pbd.pbd_material = fields['mat']
    if 'cap' in fields and prim_type in _CAP_TYPES:
        obj.pbd.pbd_cap = fields['cap']
    if prim_type == 'cube':
        for axis in ('X', 'Y', 'Z'):
            key = f'smooth{axis}'
            if key in fields:
                # NOTE: was 'pbd_smooth_{axis}' (missing 'cube_') before -
                # that attribute doesn't exist on the property group, so
                # this raised AttributeError on any file actually using
                # smoothX/Y/Z. Fixed to match properties.py's real name.
                setattr(obj.pbd, f'pbd_cube_smooth_{axis.lower()}', float(fields[key]))
        if 'faces' in fields:
            _apply_removed_faces(obj.pbd, fields['faces'])
    if prim_type == 'ref' or prim_type == 'group':
        if 'source' in fields:
            obj.pbd.pbd_ref_source = fields['source'].strip('"')
        if 'fallback' in fields:
            obj.pbd.pbd_ref_fallback = fields['fallback'].strip('"')
    if fields.get('metadata') == 'true':
        obj.pbd.pbd_metadata = True
    if 'lod' in fields:
        try:
            obj.pbd.pbd_lod = int(fields['lod'])
            obj.pbd.pbd_lod_enabled = True
        except ValueError:
            pass  # malformed lod= in a hand-edited file - not worth failing the whole import over
    if 'category' in fields:
        obj.pbd.pbd_category = fields['category'].strip('"')
    if 'linkGroup' in fields:
        obj.pbd.pbd_link_group = fields['linkGroup']
    if fields.get('loop') == 'true':
        obj.pbd.pbd_loop_animation = True
    # growthDays no longer exists as of the generic channel system
    # (see PbdInstance.Keyframe's channel field) - not read here even if
    # an OLD file still has it, since nothing on the engine side
    # consumes it anymore either.

    for mod in inst['modifiers']:
        _apply_modifier(obj, mod)

    for kf in inst['keyframes']:
        _apply_keyframe(obj, kf)

    # Once a keyframe touches location/rotation/scale, Blender's f-curve
    # for that property re-evaluates and overwrites it on every
    # subsequent frame change - by the time the loop above finishes, the
    # object's own base values (set once, above) may silently reflect
    # whatever frame the last keyframe happened to land on instead. This
    # doesn't re-key anything, just restores the STATIC values this
    # instance's own scale=/pos=/rot= fields should show on export.
    if inst['keyframes']:
        obj.location = loc
        obj.rotation_euler = euler
        obj.scale = bscale
        # matrix_world/matrix_local (what _serialize_instance actually
        # reads, not these properties directly) come from Blender's
        # depsgraph, which doesn't refresh itself immediately after a
        # plain Python assignment - without this, the restored values
        # above are correct when read directly but export would still
        # see whatever matrix the last keyframe's frame left evaluated.
        bpy.context.view_layer.update()

    return obj


def _apply_modifier(obj, mod):
    mtype = mod['type']
    params = mod['params']
    if mtype == 'bend':
        obj.pbd.pbd_bend_enabled = True
        if 'axis' in params:
            obj.pbd.pbd_bend_axis = params['axis'].upper()
        if 'angle' in params:
            obj.pbd.pbd_bend_angle = math.radians(float(params['angle']))  # .pbd stores degrees, pbd_bend_angle (subtype='ANGLE') stores radians
    elif mtype == 'shear':
        obj.pbd.pbd_shear_enabled = True
        for axis in ('X', 'Y', 'Z'):
            key = f'factor{axis}'
            if key in params:
                setattr(obj.pbd, f'pbd_shear_factor_{axis.lower()}', float(params[key]))
    elif mtype == 'taper':
        obj.pbd.pbd_taper_enabled = True
        if 'bottomScale' in params:
            obj.pbd.pbd_taper_bottom_scale = float(params['bottomScale'])
        if 'topScale' in params:
            obj.pbd.pbd_taper_top_scale = float(params['topScale'])
    # twist/curve are documented no-ops engine-side (see roadmap notes) -
    # nothing meaningful to reconstruct in Blender for them yet.


def _apply_keyframe(obj, kf):
    """Inserts a real Blender keyframe reproducing the imported
    rotation/scale - this feeds back into the SAME f-curves
    _serialize_keyframes/anim_compat already read, so a round-tripped
    file keeps working with the existing keyframe panel, goto/delete
    buttons, and export untouched.

    Channel-mode keyframes (kf.get('channel') set): the ORIGINAL Blender
    frame number can't be recovered here - export only ever writes the
    already-converted channel value (time = frame * time_scale), never
    the factor itself, so there's no way back to the artist's original
    frame numbers from the file alone. This uses the channel value
    directly as the frame number instead, and sets THIS object's own
    pbd_channel_time_scale to 1.0 - a re-export immediately after import
    reproduces the same channel values exactly (round-trip preserved at
    the level that actually matters, the channel's own numbers), even
    though the Blender timeline no longer matches whatever frames the
    original artist actually keyframed on.
    """
    scene = bpy.context.scene
    channel = kf.get('channel')
    if channel:
        obj.pbd.pbd_channel_name = channel
        obj.pbd.pbd_channel_time_scale = 1.0
        frame = round(kf['time'])
    else:
        frame = round(kf['time'] * scene.render.fps)
    scene.frame_set(frame)
    if 'rot' in kf:
        _, euler, _ = _pbd_transform_to_blender(
            kf.get('pos', (0, 0, 0)), kf['rot'], (1, 1, 1))
        obj.rotation_euler = euler
    obj.keyframe_insert(data_path='rotation_euler', frame=frame)
    if 'scale' in kf:
        _, _, blender_scale = _pbd_transform_to_blender((0, 0, 0), (0, 0, 0), kf['scale'])
        obj.scale = blender_scale
        obj.keyframe_insert(data_path='scale', frame=frame)
    if 'sound' in kf:
        entry = obj.pbd.pbd_keyframe_sounds.add()
        entry.time = kf['time']
        entry.sound_file = kf['sound']


def import_pbd_file(context, filepath, display_name=None):
    """Returns (instance_count, warning_list). display_name, if given,
    names the grouping root instead of filepath's own basename - for a
    .pbdbin/.pbdasset, filepath by this point is a decompressed/
    extracted TEMP file (see IMPORT_OT_pbd.execute()), whose name is an
    implementation detail (a hidden ".x_decompressed.pbd" sibling, or
    always literally "scene" inside every .pbdasset) rather than
    anything the user would recognize as what they imported."""
    warnings = []
    base_dir = os.path.dirname(os.path.abspath(filepath))
    scene_meta, include_material, instances = parse_pbd_file(filepath)
    if 'name' in scene_meta:
        context.scene.pbd_scene_name = scene_meta['name']
    if 'kind' in scene_meta:
        context.scene.pbd_scene_kind = scene_meta['kind']
    if 'authors' in scene_meta:
        context.scene.pbd_scene_authors = ", ".join(scene_meta['authors'])
    if 'origin' in scene_meta:
        context.scene.pbd_scene_origin = scene_meta['origin']

    name_to_obj = {}
    for inst in instances:
        try:
            obj = _create_object_for_instance(inst, base_dir)
        except ParseError as e:
            warnings.append(f"{inst.get('id', '?')}: {e}")
            continue
        name_to_obj[inst['id']] = obj

    # Second pass for parenting - every object must exist first, since a
    # child can be listed before its parent isn't guaranteed by the
    # format (the engine's own PbdScene.resolveHierarchy handles this by
    # sorting, this just needs both ends to exist before linking).
    for inst in instances:
        parent_name = inst['fields'].get('parent')
        if parent_name:
            child = name_to_obj.get(inst['id'])
            parent = name_to_obj.get(parent_name)
            if child and parent:
                child.parent = parent
                # Identity, not parent.matrix_world.inverted(): the
                # parsed pos/rot/scale are already the LOCAL (parent-
                # relative) transform - matching what _serialize_instance
                # exports via matrix_local for a parented object in the
                # first place - so they should combine normally with the
                # parent's own world transform via Blender's usual
                # parent.matrix_world @ matrix_parent_inverse @
                # matrix_basis formula. Setting matrix_parent_inverse to
                # the parent's own inverse cancels the parent transform
                # out entirely instead.
                child.matrix_parent_inverse.identity()
            elif child:
                warnings.append(f"{inst['id']}: parent '{parent_name}' not found in this file")

    # Third pass for container trigger references - same reasoning as
    # parenting above: a referenced door object might be listed before
    # or after the storage cube referencing it, so resolve names to
    # actual objects only once every object in the file exists. A
    # storage cube can list several doors (see containerTriggers, plural,
    # accumulated in _parse_instance_body since a plain dict would have
    # silently kept only the last of several same-named fields).
    for inst in instances:
        storage_obj = name_to_obj.get(inst['id'])
        if storage_obj is None:
            continue
        for trigger_name in inst['containerTriggers']:
            trigger_obj = name_to_obj.get(trigger_name)
            if trigger_obj:
                entry = storage_obj.pbd.pbd_linked_doors.add()
                entry.door = trigger_obj
            else:
                warnings.append(f"{inst['id']}: containerTrigger '{trigger_name}' not found in this file")

    if include_material:
        mat_path = os.path.join(base_dir, include_material)
        if os.path.exists(mat_path):
            try:
                parsed = materials_module._parse_pbdmat(mat_path)
                mat_dir = os.path.dirname(mat_path)
                for mname, mfields in parsed.items():
                    entry = context.scene.pbd_materials.get(mname)
                    if entry is None:
                        entry = context.scene.pbd_materials.add()
                        entry.name = mname
                    if 'color' in mfields:
                        entry.color = mfields['color']
                    if 'shininess' in mfields:
                        entry.shininess = mfields['shininess']
                    if 'specular' in mfields:
                        entry.specular = mfields['specular']
                    if 'texture' in mfields:
                        entry.texture_path = os.path.join(mat_dir, mfields['texture'])
                    if 'normalMap' in mfields:
                        entry.normal_map_path = os.path.join(mat_dir, mfields['normalMap'])
                    if 'roughnessMap' in mfields:
                        entry.roughness_map_path = os.path.join(mat_dir, mfields['roughnessMap'])
                    if 'displacementMap' in mfields:
                        entry.displacement_map_path = os.path.join(mat_dir, mfields['displacementMap'])
                    if 'displacementScale' in mfields:
                        entry.displacement_scale = mfields['displacementScale']
                    if 'uvScale' in mfields:
                        entry.uv_scale = mfields['uvScale']
                    if 'reflectivity' in mfields:
                        entry.reflectivity = mfields['reflectivity']
                    if 'transparency' in mfields:
                        entry.transparency = mfields['transparency']
            except OSError as e:
                warnings.append(f"Could not read materials from {mat_path}: {e}")
        else:
            warnings.append(f"include_material '{include_material}' not found next to the .pbd file")

    # Fourth step: group every TOP-LEVEL (no parent= in the file)
    # imported instance under one new Empty, named after the file -
    # otherwise an import with several independent top-level pieces
    # (say, a wardrobe body plus a couple of shelves that were never
    # parented to it inside the file) leaves the scene with that many
    # separate, ungrouped objects, and nothing that represents "the
    # thing I just imported" as a single selectable unit to grab,
    # rotate, or scale as a whole. This is a NEW object every import
    # creates fresh - it is never an existing object already in the
    # scene, so joining or parenting the import to this new root can't
    # accidentally catch something unrelated the way parenting to
    # whatever happened to be the active object before the import ran
    # could have. Skipped when there's only one top-level piece already
    # (it can already stand in for "the whole model" on its own) or none
    # at all (nothing to group).
    top_level = [name_to_obj[inst['id']] for inst in instances
                 if inst['id'] in name_to_obj and not inst['fields'].get('parent')]
    root_obj = None
    if len(top_level) > 1:
        root_name = display_name or os.path.splitext(os.path.basename(filepath))[0]
        root_obj = bpy.data.objects.new(root_name, None)
        root_obj.empty_display_type = 'PLAIN_AXES'
        root_obj.empty_display_size = 0.5
        context.collection.objects.link(root_obj)
        for obj in top_level:
            obj.parent = root_obj
            obj.matrix_parent_inverse.identity()

    # Select just the result of THIS import (the new root if one was
    # made, otherwise whatever the one top-level piece already was) and
    # make it active, so it can be grabbed/rotated/scaled immediately
    # rather than needing to be found and selected by hand afterward.
    for o in context.selected_objects:
        o.select_set(False)
    if root_obj is not None:
        root_obj.select_set(True)
        context.view_layer.objects.active = root_obj
    elif top_level:
        top_level[0].select_set(True)
        context.view_layer.objects.active = top_level[0]

    return len(instances), warnings


class IMPORT_OT_pbd(bpy.types.Operator):
    """Imports a .pbd, .pbdasset, or .pbdbin scene file into the current
    Blender scene, reconstructing every instance's type, transform,
    material, modifiers, and keyframes - the inverse of File > Export >
    PBD. A .pbdasset (zip: scene.pbd + bundled materials/textures) gets
    unzipped first; a .pbdbin (gzip-compressed minified text) gets
    decompressed first - both then feed into the exact same reader a
    plain .pbd does. Neither compiled format had ANY way to be opened
    back up in Blender before this - producing one was possible, reading
    it back here wasn't.

    Source choice (local file vs URL) shows first, in a small dialog,
    rather than jumping straight into Blender's file browser - which
    had no way to offer the URL alternative at all, since ImportHelper's
    normal invoke() goes directly to fileselect_add with no stop in
    between. 'File' mode continues into the real file browser after
    that dialog closes (see execute() below); 'URL' mode fetches
    straight from execute() instead, reusing the same PbdFetcher-
    compatible cache pbd.test_reference and pbd_ref's own URL sources
    already use."""
    bl_idname = "import_scene.pbd"
    bl_label = "Import PBD"
    bl_options = {'REGISTER', 'UNDO'}

    # SKIP_SAVE on both: without it, Blender remembers these values
    # across invocations (its normal "last used operator settings"
    # behavior) - meaning a SECOND Import, from EITHER the panel button
    # or File > Import, would see filepath already set to whatever was
    # picked last time and skip straight to re-importing THAT file
    # again instead of opening the browser for a new one. Confirmed
    # exactly this way: reported as "importing a second time just
    # re-pastes the old import" - not a guess, a real reproduction.
    filepath: bpy.props.StringProperty(subtype='FILE_PATH', options={'SKIP_SAVE'})
    filter_glob: bpy.props.StringProperty(default="*.pbd;*.pbdasset;*.pbdbin", options={'HIDDEN'})
    source_mode: bpy.props.EnumProperty(
        name="Source",
        items=[('file', "Local File", "Pick a .pbd file from disk"),
               ('url', "URL", "Fetch a .pbd file from a http(s):// address")],
        default='file',
    )
    url: bpy.props.StringProperty(name="URL", default="", options={'SKIP_SAVE'},
                                   description="Full http(s):// address of a .pbd file")

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=350)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "source_mode", expand=True)
        if self.source_mode == 'url':
            layout.prop(self, "url")
        else:
            layout.label(text="Click OK, then choose a file in the browser")
            layout.label(text="that opens next.")

    def execute(self, context):
        if self.source_mode == 'file' and not self.filepath:
            # Confirmed "File" in the dialog but haven't picked one yet -
            # THIS is where ImportHelper's invoke() would normally have
            # gone straight to; chaining it here instead is what lets the
            # dialog above run first. Blender re-invokes execute() once a
            # real file is chosen, this time with filepath set.
            context.window_manager.fileselect_add(self)
            return {'RUNNING_MODAL'}

        if self.source_mode == 'url':
            if not self.url.strip():
                self.report({'ERROR'}, "Enter a URL first")
                return {'CANCELLED'}
            from .. import fetcher
            cache_dir = _shared_remote_cache_dir(context)
            try:
                local_path = fetcher.fetch(self.url.strip(), cache_dir, None, use_cache=True)
            except fetcher.FetchError as e:
                self.report({'ERROR'}, f"Fetch failed: {e}")
                return {'CANCELLED'}
            import_path = local_path
        else:
            import_path = self.filepath

        # .pbdasset (a zip: scene.pbd + bundled materials/textures/
        # manifest - see PbdAssetFormat.java) and .pbdbin (gzip-
        # compressed minified .pbd text - see PbdBinFormat.java) both
        # need converting to a real, on-disk plain .pbd before the
        # existing import_pbd_file() below can read them - it works with
        # text-on-disk, not zip or gzip. Doing that conversion here
        # rather than requiring a separate "convert first" step is the
        # actual "must be able to be opened with Blender" ask: neither
        # format previously had ANY Blender-side reader at all, so a
        # PBDASSET_OT_pbd-file-labeled-as-a-scene-format could be
        # produced but never opened back up in the one tool that
        # actually authors these scenes.
        lower = import_path.lower()
        display_name = os.path.splitext(os.path.basename(import_path))[0]  # captured BEFORE the .pbdasset/.pbdbin handling below replaces import_path with a temp/extracted path
        if lower.endswith('.pbdasset'):
            import zipfile
            extract_dir = tempfile.mkdtemp(prefix="pbdasset_")
            try:
                with zipfile.ZipFile(import_path) as zf:
                    zf.extractall(extract_dir)
            except (zipfile.BadZipFile, OSError) as e:
                self.report({'ERROR'}, f"Could not open '{import_path}' as .pbdasset: {e}")
                return {'CANCELLED'}
            scene_pbd = os.path.join(extract_dir, "scene.pbd")
            if not os.path.isfile(scene_pbd):
                self.report({'ERROR'}, f"'{import_path}' has no scene.pbd entry - not a valid .pbdasset")
                return {'CANCELLED'}
            import_path = scene_pbd
        elif lower.endswith('.pbdbin'):
            try:
                import_path, decompress_warning = _decompress_pbdbin(import_path)
                if decompress_warning:
                    self.report({'WARNING'}, decompress_warning)
            except (OSError, ValueError) as e:
                self.report({'ERROR'}, f"Could not read '{self.filepath}' as .pbdbin: {e}")
                return {'CANCELLED'}

        try:
            count, warnings = import_pbd_file(context, import_path, display_name=display_name)
        except (OSError, ParseError) as e:
            self.report({'ERROR'}, f"Import failed: {e}")
            return {'CANCELLED'}

        for w in warnings:
            self.report({'WARNING'}, w)
        self.report({'INFO'}, f"Imported {count} instance(s) from {import_path}")
        return {'FINISHED'}


def _shared_remote_cache_dir(context):
    """Same cache/remote layout PbdPaths.REMOTE_CACHE_DIR (Java) and
    ui_panel.py's own _remote_cache_dir (pbd.test_reference) use, so a
    URL fetched here, from Test Reference, or by the engine itself all
    share one cache instead of each keeping a separate copy. Duplicated
    rather than imported from ui_panel.py specifically to avoid this
    operators/ module reaching back up to import from the module that
    already imports FROM operators/ - not a circular import Python can't
    resolve, but the dependency direction it implies is backwards from
    every other import in this codebase, so kept as a small, obviously-
    matching duplicate instead. Anchored to this .blend file's own
    directory now (no more separately-configured project root setting
    to reach for), falling back to a temp directory if the file has
    never been saved."""
    base = bpy.path.abspath("//")
    if not base:
        import tempfile
        base = tempfile.gettempdir()
    return os.path.join(base, "pbd_cache", "remote")


def _menu_func_import(self, context):
    # ONE menu entry (not three), since it's the SAME operator handling
    # all three extensions now (see IMPORT_OT_pbd's own filter_glob and
    # its .pbdasset/.pbdbin handling in execute()) - the file browser's
    # own filter already lists all three, this label just needs to say
    # so up front rather than implying only plain .pbd is accepted.
    self.layout.operator(IMPORT_OT_pbd.bl_idname, text="PBD Scene (.pbd/.pbdasset/.pbdbin)")


CLASSES = (IMPORT_OT_pbd,)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.TOPBAR_MT_file_import.append(_menu_func_import)


def unregister():
    bpy.types.TOPBAR_MT_file_import.remove(_menu_func_import)
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
