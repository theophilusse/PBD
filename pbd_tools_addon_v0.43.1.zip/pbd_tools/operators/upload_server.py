"""Uploads the current scene to pbd.mazetrojan.fr for review (see
server/upload.php). Client-side validation here mirrors upload.php's
own checks (same required metadata fields, same extension allowlist)
specifically so a submission that would be rejected server-side is
caught here first, with a clear message, rather than making a network
round-trip just to find out - "Une verification des champs obligatoires
sera effectuee pralablement cote addon" from the roadmap this
implements.
"""
import os
import bpy
import mimetypes
import urllib.request
import urllib.error
import uuid

# Must match server/upload.php's REQUIRED_USER_AGENT exactly - the
# server rejects (with a 404, not a 403 - see that file's own doc on
# why) anything else. If this ever needs to change, change it in BOTH
# places together.
UPLOAD_USER_AGENT = "PBD-Blender-Addon/1.0 (+https://pbd.mazetrojan.fr)"
UPLOAD_URL = "https://pbd.mazetrojan.fr/upload.php"
VERSION_URL = "https://pbd.mazetrojan.fr/current_version.txt"

REQUIRED_METADATA_FIELDS = [
    ("pbd_scene_name", "name"),
    ("pbd_scene_kind", "kind"),
    ("pbd_scene_authors", "author"),
]


def _check_addon_version():
    """Fetches VERSION_URL and compares it against this add-on's own
    bl_info version - returns a warning STRING if this add-on is older
    than what the server currently expects, or None if it's current,
    the fetch failed, or the version string couldn't be parsed. Never
    raises - every failure mode here means "couldn't confirm either
    way", not "something is wrong", so the caller treats None as
    silently skip-the-warning rather than an error to surface.

    Deliberately NOT using fetcher.fetch() (the module every other
    remote-PBD-content fetch in this add-on goes through) - that
    module's own untrusted-host Y/N confirmation exists for fetching
    arbitrary THIRD-PARTY asset URLs a scene happens to reference, not
    for a one-line text file on this add-on's own home server, checked
    automatically before every upload; prompting for confirmation here
    would be exactly the kind of intrusive interruption this check is
    supposed to avoid being. A plain, short-timeout urllib call is all
    this needs.
    """
    try:
        with urllib.request.urlopen(VERSION_URL, timeout=3) as resp:
            server_version_str = resp.read().decode('utf-8', errors='replace').strip()
    except (urllib.error.URLError, OSError, TimeoutError):
        return None  # offline, server unreachable, etc. - not this check's job to complain about that

    try:
        server_version = tuple(int(p) for p in server_version_str.split('.'))
    except ValueError:
        return None  # malformed content at VERSION_URL - fail silent rather than show a confusing warning about a version number that doesn't even parse

    from .. import bl_info
    addon_version = bl_info["version"]
    if server_version > addon_version:
        server_str = '.'.join(str(p) for p in server_version)
        addon_str = '.'.join(str(p) for p in addon_version)
        return (f"This add-on ({addon_str}) is older than the server's current version "
                f"({server_str}) - update it before uploading, or your submission may use "
                f"outdated conventions the server/moderators no longer expect.")
    return None


def _check_required_metadata(context):
    """Returns a list of missing/empty field names - empty list means
    ready to submit. Mirrors upload.php's extract_required_metadata
    exactly (same three fields), checked here first so a submission
    that would fail server-side fails immediately, with no network
    round trip, and with a message that names the SAME fields the
    server would have complained about."""
    missing = []
    for prop_name, field_label in REQUIRED_METADATA_FIELDS:
        value = getattr(context.scene, prop_name, "").strip()
        if not value:
            missing.append(field_label)
    return missing


def _encode_multipart(fields_files):
    """fields_files: list of (form_field_name, filename, content_bytes).
    Returns (content_type_header_value, body_bytes) - hand-rolled rather
    than using the third-party `requests` library, which Blender's
    bundled Python does NOT ship by default (only the standard library
    is guaranteed present across a user's install), so urllib is the
    portable choice here."""
    boundary = uuid.uuid4().hex
    parts = []
    for field_name, filename, content in fields_files:
        mime = mimetypes.guess_type(filename)[0] or "application/octet-stream"
        parts.append(
            f'--{boundary}\r\n'
            f'Content-Disposition: form-data; name="{field_name}"; filename="{filename}"\r\n'
            f'Content-Type: {mime}\r\n\r\n'.encode('ascii')
            + content + b'\r\n'
        )
    parts.append(f'--{boundary}--\r\n'.encode('ascii'))
    body = b''.join(parts)
    return f'multipart/form-data; boundary={boundary}', body


class OBJECT_OT_pbd_upload_to_server(bpy.types.Operator):
    """Exports the current scene (same as File > Export > PBD) and
    submits it, along with its materials and textures, to
    pbd.mazetrojan.fr for moderator review - nothing is published
    immediately; see server/moderator.php for the review step this
    lands in. Requires name/kind/author metadata to already be filled
    in (the panel's own "File metadata" box) - checked here before
    anything is sent, matching what the server itself would otherwise
    reject the submission for anyway."""
    bl_idname = "pbd.upload_to_server"
    bl_label = "Upload to pbd.mazetrojan.fr"
    bl_options = {'REGISTER'}

    def invoke(self, context, event):
        missing = _check_required_metadata(context)
        if missing:
            self.report({'ERROR'}, f"Fill in required metadata first: {', '.join(missing)} "
                                    f"(see File metadata box in the panel)")
            return {'CANCELLED'}
        return context.window_manager.invoke_confirm(
            self, event,
            message="Submit this scene to pbd.mazetrojan.fr for review? "
                    "This sends your .pbd, its materials, and its textures over the network.",
        )

    def execute(self, context):
        try:
            return self._execute_impl(context)
        except Exception as e:
            import traceback
            traceback.print_exc()
            self.report({'ERROR'}, f"Upload failed: {type(e).__name__}: {e} (full traceback in System Console)")
            return {'CANCELLED'}

    def _execute_impl(self, context):
        version_warning = _check_addon_version()
        if version_warning:
            self.report({'WARNING'}, version_warning)

        missing = _check_required_metadata(context)
        if missing:
            self.report({'ERROR'}, f"Fill in required metadata first: {', '.join(missing)}")
            return {'CANCELLED'}

        from . import export_pbd
        import tempfile
        tmp_dir = tempfile.mkdtemp(prefix="pbd_upload_")
        tmp_pbd = os.path.join(tmp_dir, "scene.pbd")
        count, warnings, kf = export_pbd.export_scene_to_pbd(context, tmp_pbd)
        for w in warnings:
            self.report({'WARNING'}, w)
        if count == 0:
            self.report({'ERROR'}, "Nothing to upload - no PBD primitives in this scene")
            return {'CANCELLED'}

        # Gather every file this submission needs: the .pbd itself, its
        # sibling .pbdmat if _write_pbdmat produced one (EMBEDDED
        # materials - SHARED ones live in the project's own materials/
        # folder and are intentionally not bundled per-submission, same
        # as they're not bundled into a .pbdasset either), and every
        # distinct texture path any EMBEDDED material entry references.
        files_to_send = [("pbd", "scene.pbd", tmp_pbd)]
        tmp_pbdmat = os.path.join(tmp_dir, "scene.pbdmat")
        if os.path.isfile(tmp_pbdmat):
            files_to_send.append(("pbdmat", "scene.pbdmat", tmp_pbdmat))

        seen_textures = set()
        for entry in context.scene.pbd_materials:
            if entry.material_source != 'EMBEDDED':
                continue
            for path_attr in ("texture_path", "normal_map_path", "roughness_map_path", "displacement_map_path"):
                path = getattr(entry, path_attr, "")
                if not path:
                    continue
                abspath = bpy.path.abspath(path)
                if abspath in seen_textures or not os.path.isfile(abspath):
                    continue
                seen_textures.add(abspath)
                files_to_send.append(("tex_" + str(len(files_to_send)), os.path.basename(abspath), abspath))

        # Every keyframe sound=, across every tagged object in the
        # scene - a real, reported gap: export_pbd.py already writes
        # sound=<basename> into the .pbd text correctly (see
        # _sound_for_time), but nothing ever collected the ACTUAL .wav
        # file to send alongside it, so every submission with a sound
        # keyframe has been shipping a reference to a file that was
        # never actually uploaded. Deduplicated the same way textures
        # are (seen_sounds), since two different keyframes - on the
        # same object or different ones - can share one sound file.
        seen_sounds = set()
        for obj in bpy.data.objects:
            if not getattr(obj, "pbd", None) or not obj.pbd.is_pbd_primitive:
                continue
            for kf in obj.pbd.pbd_keyframe_sounds:
                path = kf.sound_file.strip()
                if not path:
                    continue
                abspath = bpy.path.abspath(path)
                if abspath in seen_sounds or not os.path.isfile(abspath):
                    continue
                seen_sounds.add(abspath)
                files_to_send.append(("snd_" + str(len(files_to_send)), os.path.basename(abspath), abspath))

        multipart_files = []
        for field_name, filename, path in files_to_send:
            with open(path, 'rb') as f:
                multipart_files.append((field_name, filename, f.read()))

        # Matches upload.php's own MAX_TOTAL_SIZE_BYTES (120MB) with a
        # small margin - not the OLD 7MB threshold from before the
        # server's own per-image limit was raised to 30MB.
        total_size = sum(len(content) for _, _, content in multipart_files)
        if total_size > 115 * 1024 * 1024:
            size_mb = total_size / (1024 * 1024)
            self.report({'ERROR'},
                f"Submission is {size_mb:.1f} MB - too large for this server's own "
                f"MAX_TOTAL_SIZE_BYTES (120 MB total). This isn't a bug in the scene itself; it needs "
                f"either smaller/fewer textures, or the server's own upload.php limits raised further "
                f"(see server/README.md's \"Upload size limits\" section).")
            return {'CANCELLED'}

        content_type, body = _encode_multipart(multipart_files)
        request = urllib.request.Request(
            UPLOAD_URL, data=body, method='POST',
            headers={'Content-Type': content_type, 'User-Agent': UPLOAD_USER_AGENT},
        )

        try:
            with urllib.request.urlopen(request, timeout=30) as response:
                response_body = response.read().decode('utf-8', errors='replace')
        except urllib.error.HTTPError as e:
            error_body = e.read().decode('utf-8', errors='replace')
            self.report({'ERROR'}, f"Server rejected the submission (HTTP {e.code}): {error_body}")
            return {'CANCELLED'}
        except urllib.error.URLError as e:
            self.report({'ERROR'}, f"Could not reach {UPLOAD_URL}: {e.reason}")
            return {'CANCELLED'}

        self.report({'INFO'}, f"Submitted for review: {response_body}")
        return {'FINISHED'}


CLASSES = (OBJECT_OT_pbd_upload_to_server,)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
