"""Uploads the current scene to the project's server (fetcher.PBD_SITE_HOST) for review (see
server/upload.php). Client-side validation here mirrors upload.php's
own checks (same required metadata fields, same extension allowlist,
same names, same limits - see upload_rules.py) specifically so a
submission that would be rejected server-side is caught here first,
with a clear message, rather than making a network round-trip just to
find out - "Une verification des champs obligatoires sera effectuee
pralablement cote addon" from the roadmap this implements.

The server is the authority; what this module adds is hygiene on the person's side: the files are named by the scene (which may be
somebody else's), so a path that is not a file of the person's (a network path, which Windows answers by offering their credentials)
is never opened, a file is never read beyond the size the server takes, nothing is followed to another address (the answer of a
redirect is a failure), the answers read are short, and the copies made for the transfer are removed when it ends.
"""
import os
import bpy
import urllib.request
import urllib.error

from .. import fetcher
from .. import safety
from .. import upload_rules
from ..fetcher import PBD_SITE_HOST

# Must match server/upload.php's REQUIRED_USER_AGENT exactly - the
# server rejects (with a 404, not a 403 - see that file's own doc on
# why) anything else. If this ever needs to change, change it in BOTH
# places together.
UPLOAD_USER_AGENT = f"PBD-Blender-Addon/1.0 (+https://{PBD_SITE_HOST})"
UPLOAD_URL = f"https://{PBD_SITE_HOST}/upload.php"
VERSION_URL = f"https://{PBD_SITE_HOST}/current_version.txt"

REQUIRED_METADATA_FIELDS = [
    ("pbd_scene_name", "name"),
    ("pbd_scene_kind", "kind"),
    ("pbd_scene_authors", "author"),
]


def _check_addon_version():
    """Fetches VERSION_URL and compares it against this add-on's own
    bl_info version - returns a warning STRING if this add-on is older
    than what the server currently expects, or None if it's current,
    the fetch failed, or the version string couldn't be parsed. Never
    raises - every failure mode here means "couldn't confirm either
    way", not "something is wrong", so the caller treats None as
    silently skip-the-warning rather than an error to surface.

    Deliberately NOT using fetcher.fetch() (the module every other
    remote-PBD-content fetch in this add-on goes through) - that
    module's own untrusted-host Y/N confirmation exists for fetching
    arbitrary THIRD-PARTY asset URLs a scene happens to reference, not
    for a one-line text file on this add-on's own home server, checked
    automatically before every upload; prompting for confirmation here
    would be exactly the kind of intrusive interruption this check is
    supposed to avoid being. A plain, short-timeout request is all this
    needs - read for at most MAX_VERSION_BYTES (a version number is a
    few characters; anything longer is not one), and a redirect is a
    failure, not something to follow.
    """
    try:
        with fetcher.build_opener().open(urllib.request.Request(VERSION_URL, headers={"User-Agent": UPLOAD_USER_AGENT}), timeout=3) as resp:
            raw = resp.read(upload_rules.MAX_VERSION_BYTES + 1)
    except (urllib.error.URLError, OSError, TimeoutError):
        return None  # offline, server unreachable, etc. - not this check's job to complain about that
    if len(raw) > upload_rules.MAX_VERSION_BYTES:
        return None  # not a version number

    try:
        server_version_str = raw.decode('utf-8', errors='replace').strip()
        server_version = tuple(int(p) for p in server_version_str.split('.'))
    except ValueError:
        return None  # malformed content at VERSION_URL - fail silent rather than show a confusing warning about a version number that doesn't even parse

    from .. import bl_info
    addon_version = bl_info["version"]
    if server_version > addon_version:
        server_str = '.'.join(str(p) for p in server_version)
        addon_str = '.'.join(str(p) for p in addon_version)
        return (f"This add-on ({addon_str}) is older than the server's current version "
                f"({server_str}) - update it before uploading, or your submission may use "
                f"outdated conventions the server/moderators no longer expect.")
    return None


def _check_required_metadata(context):
    """Returns a list of missing/empty field names - empty list means
    ready to submit. Mirrors upload.php's extract_required_metadata
    exactly (same three fields), checked here first so a submission
    that would fail server-side fails immediately, with no network
    round trip, and with a message that names the SAME fields the
    server would have complained about."""
    missing = []
    for prop_name, field_label in REQUIRED_METADATA_FIELDS:
        value = getattr(context.scene, prop_name, "").strip()
        if not value:
            missing.append(field_label)
    return missing


def sound_paths_of(obj):
    """The sound files the exported fields of one object name, as the author typed them (a path, maybe empty): the keyframe sounds, the
    open/close sounds of a lever arm that is exported (enabled), and the click of a light (switchSound=, the sound E makes on its model).
    Everything export_pbd writes as a sound file name has to be listed here, or the .pbd names a file that never travels with it."""
    paths = [kf.sound_file for kf in obj.pbd.pbd_keyframe_sounds]
    if obj.pbd.pbd_lever_arm_enabled:
        paths += [obj.pbd.pbd_lever_arm_open_sound, obj.pbd.pbd_lever_arm_close_sound]
    if obj.pbd.pbd_type == 'light':
        paths.append(obj.pbd.pbd_light_switch_sound)
    return paths


def files_of_submission(context, tmp_pbd, tmp_pbdmat):
    """``(candidates, refused)`` for a submission: ``candidates`` is [(form field, file name, path on the disk)] - the .pbd, its .pbdmat
    when the export wrote one, and every distinct texture and sound the scene names that is a file - and ``refused`` the paths that are
    not files of the person's (a network path, an address, an alternate data stream: see safety.refuse_local_reference), which are never
    opened, not even to see whether they exist."""
    candidates = [("pbd", "scene.pbd", tmp_pbd)]
    refused = []
    if os.path.isfile(tmp_pbdmat):
        candidates.append(("pbdmat", "scene.pbdmat", tmp_pbdmat))

    def consider(path, seen, prefix):
        abspath = bpy.path.abspath(path)
        reason = safety.refuse_local_reference(abspath)
        if reason:
            refused.append(f"'{safety.printable(path)}': {reason}")
            return
        if abspath in seen or not os.path.isfile(abspath):
            return
        seen.add(abspath)
        candidates.append((prefix + str(len(candidates)), os.path.basename(abspath), abspath))

    # SHARED materials live in the project's own materials/ folder and are intentionally not bundled per-submission, same as they're not
    # bundled into a .pbdasset either; EMBEDDED ones travel in the .pbdmat, with every distinct texture path they reference
    seen_textures = set()
    for entry in context.scene.pbd_materials:
        if entry.material_source != 'EMBEDDED':
            continue
        for path_attr in ("texture_path", "normal_map_path", "roughness_map_path", "displacement_map_path"):
            path = getattr(entry, path_attr, "")
            if path:
                consider(path, seen_textures, "tex_")

    # Every keyframe sound=, across every tagged object in the scene, a lever arm's openSound/closeSound (when the arm is exported) and a
    # light's switchSound: the .pbd names them, so the .wav has to travel with it. Deduplicated like the textures, since two keyframes -
    # on one object or on different ones - can share one sound file.
    seen_sounds = set()
    for obj in bpy.data.objects:
        if not getattr(obj, "pbd", None) or not obj.pbd.is_pbd_primitive:
            continue
        for raw_path in sound_paths_of(obj):
            path = raw_path.strip()
            if path:
                consider(path, seen_sounds, "snd_")
    return candidates, refused


class OBJECT_OT_pbd_upload_to_server(bpy.types.Operator):
    """Exports the current scene (same as File > Export > PBD) and
    submits it, along with its materials and textures, to
    the project's server (PBD_SITE_HOST) for moderator review - nothing is published
    immediately; see server/moderator.php for the review step this
    lands in. Requires name/kind/author metadata to already be filled
    in (the panel's own "File metadata" box) - checked here before
    anything is sent, matching what the server itself would otherwise
    reject the submission for anyway."""
    bl_idname = "pbd.upload_to_server"
    bl_label = f"Upload to {PBD_SITE_HOST}"
    bl_options = {'REGISTER'}

    def invoke(self, context, event):
        missing = _check_required_metadata(context)
        if missing:
            self.report({'ERROR'}, f"Fill in required metadata first: {', '.join(missing)} "
                                    f"(see File metadata box in the panel)")
            return {'CANCELLED'}
        return context.window_manager.invoke_confirm(
            self, event,
            message=f"Submit this scene to {PBD_SITE_HOST} for review? "
                    "This sends your .pbd, its materials, and its textures over the network.",
        )

    def execute(self, context):
        try:
            return self._execute_impl(context)
        except Exception as e:
            import traceback
            traceback.print_exc()
            self.report({'ERROR'}, f"Upload failed: {type(e).__name__}: {e} (full traceback in System Console)")
            return {'CANCELLED'}

    def _execute_impl(self, context):
        # What is missing from the person's own scene is found before the network is used at all (the version check is a request).
        missing = _check_required_metadata(context)
        if missing:
            self.report({'ERROR'}, f"Fill in required metadata first: {', '.join(missing)}")
            return {'CANCELLED'}

        version_warning = _check_addon_version()
        if version_warning:
            self.report({'WARNING'}, version_warning)

        from . import export_pbd
        import tempfile
        # The copies made for the transfer (the exported scene and its materials) are removed when it ends, whatever way it ends.
        with tempfile.TemporaryDirectory(prefix="pbd_upload_") as tmp_dir:
            tmp_pbd = os.path.join(tmp_dir, "scene.pbd")
            count, warnings, kf = export_pbd.export_scene_to_pbd(context, tmp_pbd)
            for w in warnings:
                self.report({'WARNING'}, w)
            if count == 0:
                self.report({'ERROR'}, "Nothing to upload - no PBD primitives in this scene")
                return {'CANCELLED'}

            candidates, refused = files_of_submission(context, tmp_pbd, os.path.join(tmp_dir, "scene.pbdmat"))
            problems = [f"{r} - a submission only has files on this machine" for r in refused]
            problems += upload_rules.problems_with([(name, os.path.getsize(path)) for _field, name, path in candidates])
            if problems:
                for problem in problems[:8]:
                    self.report({'ERROR'}, f"Not sent: {problem}")
                if len(problems) > 8:
                    self.report({'ERROR'}, f"... and {len(problems) - 8} more")
                return {'CANCELLED'}

            multipart_files = [(field, name, upload_rules.read_for_upload(path)) for field, name, path in candidates]
            content_type, body = upload_rules.encode_multipart(multipart_files)

        request = urllib.request.Request(
            UPLOAD_URL, data=body, method='POST',
            headers={'Content-Type': content_type, 'User-Agent': UPLOAD_USER_AGENT},
        )
        try:
            with fetcher.build_opener().open(request, timeout=30) as response:
                response_body = safety.read_capped(response, upload_rules.MAX_ANSWER_BYTES, "the server's answer").decode('utf-8', errors='replace')
        except safety.Refused as e:
            self.report({'ERROR'}, f"{e}")
            return {'CANCELLED'}
        except urllib.error.HTTPError as e:
            if 300 <= e.code < 400:
                self.report({'ERROR'}, f"{UPLOAD_URL} answered with a redirect (HTTP {e.code}), which is not followed - nothing was sent anywhere else")
                return {'CANCELLED'}
            error_body = e.read(upload_rules.MAX_ANSWER_BYTES).decode('utf-8', errors='replace')
            self.report({'ERROR'}, f"Server rejected the submission (HTTP {e.code}): {safety.printable(error_body, 2000, keep_lines=True)}")
            return {'CANCELLED'}
        except urllib.error.URLError as e:
            self.report({'ERROR'}, f"Could not reach {UPLOAD_URL}: {e.reason}")
            return {'CANCELLED'}

        self.report({'INFO'}, f"Submitted for review: {safety.printable(response_body, 2000, keep_lines=True)}")
        return {'FINISHED'}


CLASSES = (OBJECT_OT_pbd_upload_to_server,)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
