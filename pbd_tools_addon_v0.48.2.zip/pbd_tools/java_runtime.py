"""Finding a Java that can run what the Gradle project compiled.

A class file records the Java it was compiled for (major version 65 is Java 21), and a Java older than that refuses it:
"UnsupportedClassVersionError: pbd/pz/PbdToTileGeometryMain has been compiled by a more recent version of the Java Runtime (class file version
65.0), this version of the Java Runtime only recognizes class file versions up to 61.0". The project asks Gradle for a Java 21 toolchain
(build.gradle.kts), which Gradle fetches and keeps in its own folder; the `java` of a person's PATH is whatever else they installed, often
an older one - so running the project's classes with "java" from Blender failed on exactly the machines where `gradlew run` worked.

This module reads which Java the classes need (from the class file itself), looks for one that is recent enough - an explicit choice
(PBD_JAVA), JAVA_HOME, the PATH, the Javas Gradle fetched into ~/.gradle/jdks, and the places each system installs them - and, when
there is none, says what it looked at and what the person can do.

Pure Python, no bpy: a check runs it with Javas made up for the occasion (tools/regression/blender_addon_check.py).
"""

import glob
import os
import re
import shutil
import subprocess
import sys
import zipfile

#: The Java the engine is built for when the classes cannot be read (build.gradle.kts: languageVersion.set(JavaLanguageVersion.of(21))).
DEFAULT_RELEASE = 21

#: The most Javas that are started to ask their version: each is a process.
MAX_PROBES = 24

#: How long, in seconds, a java is given to answer `-version` before it is taken for one that does not run.
_PROBE_TIMEOUT = 20


def release_of_class_file(head):
    """The Java release a class file was compiled for, from its first eight bytes (magic, minor, major): major 52 is Java 8, 61 is Java 17, 65 is
    Java 21. None for anything that is not a class file."""
    if len(head) < 8 or head[:4] != b"\xca\xfe\xba\xbe":
        return None
    major = int.from_bytes(head[6:8], "big")
    return major - 44 if major >= 45 else None


def required_release(classpath, class_name, separator=os.pathsep):
    """The Java release that `class_name` ("pbd/pz/PbdToTileGeometryMain.class") needs, read from the first place on the classpath that holds it -
    a folder of classes or a jar. None when no entry holds it (the caller falls back on DEFAULT_RELEASE)."""
    for entry in classpath.split(separator):
        entry = entry.strip().strip('"')
        if not entry:
            continue
        try:
            if os.path.isdir(entry):
                path = os.path.join(entry, *class_name.split("/"))
                if os.path.isfile(path):
                    with open(path, "rb") as f:
                        return release_of_class_file(f.read(8))
            elif os.path.isfile(entry) and entry.lower().endswith((".jar", ".zip")):
                with zipfile.ZipFile(entry) as archive:
                    try:
                        return release_of_class_file(archive.read(class_name)[:8])
                    except KeyError:
                        continue
        except (OSError, zipfile.BadZipFile):
            continue
    return None


def release_of_version_text(version):
    """The release number of a java.version text: "21.0.12.1" is 21, "17" is 17, "11.0.2" is 11, "1.8.0_391" is 8 (Java 8 and before wrote 1.x), "9-ea"
    is 9. None for anything else."""
    parts = re.split(r"[._+-]", version.strip())
    try:
        major = int(parts[0])
        if major == 1 and len(parts) > 1:
            major = int(parts[1])
    except (ValueError, IndexError):
        return None
    return major if major > 0 else None


def _no_window():
    """On Windows a program started by a program with no console opens one; this says not to."""
    flag = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    return {"creationflags": flag} if flag else {}


def release_of(executable, run=subprocess.run):
    """The release of the Java at `executable`, from what `java -version` prints (it prints it on the error stream: `openjdk version "21.0.12.1"`),
    or None when it does not start or says something else."""
    try:
        proc = run([executable, "-version"], capture_output=True, text=True, timeout=_PROBE_TIMEOUT, **_no_window())
    except (OSError, subprocess.SubprocessError, ValueError):
        return None
    text = f"{proc.stderr or ''}\n{proc.stdout or ''}"
    match = re.search(r'version\s+"([^"]+)"', text)
    return release_of_version_text(match.group(1)) if match else None


def candidates(env, home, platform, which=shutil.which, globber=glob.glob):
    """[(where it comes from, path of a java program)] in the order they are tried. Nothing is started here; a path that is not a file is still
    listed (find_java skips it and says it was not there)."""
    exe = "java.exe" if platform.startswith("win") else "java"
    found = []

    def of_home(label, folder):
        found.append((label, os.path.join(folder, "bin", exe)))

    explicit = env.get("PBD_JAVA")
    if explicit:
        if os.path.isdir(explicit):
            of_home("PBD_JAVA", explicit)
        else:
            found.append(("PBD_JAVA", explicit))
    if env.get("JAVA_HOME"):
        of_home("JAVA_HOME", env["JAVA_HOME"])
    on_path = which("java")
    if on_path:
        found.append(("java on the PATH", on_path))

    patterns = []
    if home:
        patterns += [os.path.join(home, ".gradle", "jdks", "*"),                                  # the Javas Gradle fetched for a toolchain
                     os.path.join(home, ".gradle", "jdks", "*", "Contents", "Home"),
                     os.path.join(home, ".jdks", "*"),                                            # IntelliJ's
                     os.path.join(home, ".sdkman", "candidates", "java", "*")]
    if platform.startswith("win"):
        for variable in ("ProgramFiles", "ProgramW6432", "ProgramFiles(x86)"):
            base = env.get(variable)
            if base:
                for vendor in ("Java", "Eclipse Adoptium", "Microsoft", "Zulu", "Amazon Corretto", "BellSoft", "Semeru", "Temurin"):
                    patterns.append(os.path.join(base, vendor, "*"))
    elif platform == "darwin":
        patterns += ["/Library/Java/JavaVirtualMachines/*/Contents/Home",
                     "/opt/homebrew/opt/openjdk*/libexec/openjdk.jdk/Contents/Home",
                     "/usr/local/opt/openjdk*/libexec/openjdk.jdk/Contents/Home"]
        if home:
            patterns.append(os.path.join(home, "Library", "Java", "JavaVirtualMachines", "*", "Contents", "Home"))
    else:
        patterns += ["/usr/lib/jvm/*", "/usr/java/*", "/opt/java/*", "/opt/jdk*", "/usr/local/java/*"]
    for pattern in patterns:
        for folder in sorted(globber(pattern), reverse=True):   # the highest-numbered folder of a kind first
            of_home(folder, folder)
    return found


def find_java(required, env=None, home=None, platform=None, run=subprocess.run, which=shutil.which, globber=glob.glob):
    """-> (path of a java, its release, tried) for the first Java that is at least release `required`; (None, None, tried) when there is none.
    `tried` is [(where it comes from, path, release or None)], everything that was started - or found not to be a file - on the way."""
    env = os.environ if env is None else env
    home = os.path.expanduser("~") if home is None else home
    platform = sys.platform if platform is None else platform
    tried = []
    seen = set()
    for label, path in candidates(env, home, platform, which, globber):
        if len(tried) >= MAX_PROBES:
            break
        key = os.path.normcase(os.path.realpath(path))
        if key in seen:
            continue
        seen.add(key)
        if not os.path.isfile(path):
            tried.append((label, path, None))
            continue
        release = release_of(path, run)
        tried.append((label, path, release))
        if release is not None and release >= required:
            return path, release, tried
    return None, None, tried


def explain(required, tried):
    """The message when no Java is recent enough: what was needed, what was found, and the three ways out."""
    lines = [f"No Java {required} or newer was found - the project's classes were compiled for Java {required}, and an older one cannot run them."]
    started = [(label, path, release) for label, path, release in tried if release is not None]
    if started:
        lines.append("Found: " + "; ".join(f"Java {release} ({label})" for label, _path, release in started) + ".")
    else:
        lines.append("No Java could be started from: " + (", ".join(label for label, _path, _release in tried) or "the PATH, JAVA_HOME and the usual folders") + ".")
    lines.append(f"Install a JDK {required} (adoptium.net), or set JAVA_HOME - or PBD_JAVA, the path of a java program - to one, then start Blender again.")
    return " ".join(lines)
