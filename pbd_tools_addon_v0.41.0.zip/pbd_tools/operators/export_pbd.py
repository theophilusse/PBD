import math
import os

import bpy
import mathutils

from .. import anim_compat
from bpy_extras.io_utils import ExportHelper

# Blender is Z-up, the .pbd format is Y-up (like most real-time/GLSL
# pipelines). The conversion is done by conjugating each local transform
# with this -90 deg rotation around X. Verified independently before this
# file was written: composing the converted local transforms along a
# hierarchy gives exactly the same result as converting the world matrix
# directly (difference on the order of 1e-16).
_AXIS_CONVERSION = mathutils.Matrix.Rotation(math.radians(-90.0), 4, 'X')
_AXIS_CONVERSION_INV = _AXIS_CONVERSION.inverted()


def _to_pbd_matrix(matrix):
    return _AXIS_CONVERSION @ matrix @ _AXIS_CONVERSION_INV


# Default local dimensions of a native Blender mesh for each type
# (verified: all 6 Blender primitives fit in a 2x2x2 box, 2x2x0 for the
# flat ones (plane, disc) - none of them needs an explicit size/radius/
# depth argument for this, it is the native default).
_EXPECTED_LOCAL_DIMS = {
    'plane': (2.0, 2.0, 0.0),
    'sphere': (2.0, 2.0, 2.0),
    'cylinder': (2.0, 2.0, 2.0),
    'cone': (2.0, 2.0, 2.0),
    'cube': (2.0, 2.0, 2.0),
    'disc': (2.0, 2.0, 0.0),
    'torus': (2.0, 2.0, 0.6),
}

# The shader (see pbd.tese) defines its canonical primitives with a
# half-extent of 0.5 (unit 1x1x1 box), while a native Blender mesh has a
# half-extent of 1.0 (2x2x2 box) - without compensation, everything would
# render at exactly half the size visible in Blender. Compensated once
# here, at the source, rather than requiring every user to create their
# primitives in one exact way.
_BLENDER_TO_SHADER_SCALE = 2.0

# Canonical PBD face codes in PatchExpander part-index order (0-5) -
# +x=0 -x=1 +y=2(top) -y=3(bottom) +z=4 -z=5. Used both for faces= export
# below and documented again at properties.py's face booleans, since
# getting this backwards would silently remove the wrong face rather than
# error.
_PBD_FACE_CODES = ["+x", "-x", "+y", "-y", "+z", "-z"]


def _quote_if_needed(s):
    """Mirrors PbdSerializer.java's own quoteIfNeeded exactly - a bare
    value can't contain a space (readRawValue's un-quoted branch stops at
    the first one), so anything that might have one needs real quotes,
    not just hoping the reader is forgiving."""
    return f'"{s}"' if (" " in s or s == "") else s


def _removed_face_codes(pbd_props):
    """Blender-labeled face booleans -> removed canonical PBD face codes.
    Mapping verified numerically against _AXIS_CONVERSION (Blender +Z,
    Blender's own up axis, lands on the engine's +Y "top", etc.) rather
    than assumed - see this project's own axis-conversion notes.
    Blender index -> canonical part: +X->0 -X->1 +Z->2 -Z->3 -Y->4 +Y->5."""
    kept = [
        pbd_props.pbd_cube_face_posx, pbd_props.pbd_cube_face_negx,
        pbd_props.pbd_cube_face_posz, pbd_props.pbd_cube_face_negz,
        pbd_props.pbd_cube_face_negy, pbd_props.pbd_cube_face_posy,
    ]
    return [_PBD_FACE_CODES[i] for i, k in enumerate(kept) if not k]


def _expected_local_dims(prim_type):
    # Fallback matches the 2x2x2 convention every current type follows -
    # not (1,1,1), which predates that convention and would falsely flag
    # any future type left out of the table above by mistake.
    return _EXPECTED_LOCAL_DIMS.get(prim_type, (2.0, 2.0, 2.0))


def _mesh_scale_factor(obj, expected):
    """Ratio (actual mesh dimension / expected canonical dimension) on
    each non-degenerate axis, after removing the object's own scale.
    Comes out to ~1.0 everywhere for a mesh created via Add > Mesh > PBD
    ...; a mismatch flags a mesh that no longer matches the canonical
    shape - for instance resized in Edit Mode (the mesh changed, not
    obj.scale), or created via Blender's native tool whose default sizes
    differ (its default cube is 2x2x2, not 1x1x1)."""
    factors = []
    for i in range(3):
        scale_i = obj.scale[i]
        if abs(scale_i) < 1e-8 or expected[i] < 1e-8:
            continue
        local_dim = obj.dimensions[i] / scale_i
        factors.append(local_dim / expected[i])
    return factors


def _check_mesh_matches_canonical(obj):
    """None if the mesh matches the expected canonical size for its type;
    otherwise an explicit warning message. Doesn't apply to 'mesh',
    'ref', or 'light': none of the three has a canonical shape to
    measure against (a 'mesh' is deliberately whatever geometry it is;
    'ref' and 'light' have no geometry of their own at all - both are
    Empties), so there is no "expected size" to compare against - every
    'mesh' object would otherwise report a spurious mismatch."""
    if obj.pbd.pbd_type in ('mesh', 'ref', 'light'):
        return None
    factors = _mesh_scale_factor(obj, _expected_local_dims(obj.pbd.pbd_type))
    if not factors:
        return None
    avg = sum(factors) / len(factors)
    if any(abs(f - avg) > 0.05 for f in factors):
        return (f"'{obj.name}': the mesh does not match a clean canonical "
                f"{obj.pbd.pbd_type} (factor differs per axis: "
                f"{['%.2f' % f for f in factors]}) - edited in Edit Mode?")
    if abs(avg - 1.0) > 0.05:
        return (f"'{obj.name}': the mesh is about {avg:.2f}x the native "
                f"Blender size expected for a {obj.pbd.pbd_type} - check "
                f"that it wasn't resized in Edit Mode, or that a modifier "
                f"(Bevel, Subdivision...) isn't changing its bounding box.")
    return None


def _format_vec3(v, precision=6):
    return f"({v[0]:.{precision}g}, {v[1]:.{precision}g}, {v[2]:.{precision}g})"


def _pbd_parent_of(obj):
    """The native Blender parent, if it is itself a tagged PBD primitive -
    otherwise None (the object is a root in the .pbd file)."""
    parent = obj.parent
    if parent is not None and getattr(parent, "pbd", None) and parent.pbd.is_pbd_primitive:
        return parent
    return None


def _serialize_keyframes(obj):
    """Reads obj's own Blender keyframes (rotation_euler, location, and
    scale f-curves) and returns `keyframe { }` block strings, one per
    unique keyframe time across those curves. Evaluates every curve (not
    just the one that actually has a keyframe point at a given frame) at
    each collected time, so a time where only one property was keyed
    still gets a consistent, curve-interpolated pose rather than a gap -
    the engine's own interpolation then only has to do plain linear
    interpolation between these already-resolved poses, not reproduce
    Blender's own curve handles/easing.

    Channel mode (obj.pbd.pbd_channel_name non-empty): rather than
    inventing a new UI for "keyframes driven by a named channel instead
    of real time" (see pbd.render.ChannelTracker on the engine side),
    the artist just keyframes Scale normally on Blender's own timeline -
    completely standard, familiar tooling - and sets a channel name plus
    a time-scale factor converting frame number to channel-value units.
    A fast, ordinary-looking Blender animation (say, frame 0 to frame 24)
    becomes a very slow one once the engine drives it by a slowly-
    accumulating channel like "humidity" instead of by playback time -
    that's the whole trick behind making a few seconds of scale
    keyframing read as vegetation growing in over days.

    Returns an empty list if obj has no animation data at all - the
    normal case, not an error.
    """
    fcurves = anim_compat.get_object_fcurves(obj)
    if not fcurves:
        return []

    rot_curves = [anim_compat.find_fcurve(fcurves, "rotation_euler", i) for i in range(3)]
    loc_curves = [anim_compat.find_fcurve(fcurves, "location", i) for i in range(3)]
    scale_curves = [anim_compat.find_fcurve(fcurves, "scale", i) for i in range(3)]
    all_curves = [c for c in rot_curves + loc_curves + scale_curves if c is not None]
    if not all_curves:
        return []

    channel_name = obj.pbd.pbd_channel_name.strip()
    frames = sorted({kp.co.x for c in all_curves for kp in c.keyframe_points})
    fps = bpy.context.scene.render.fps

    lines = []
    for frame in frames:
        time = (frame * obj.pbd.pbd_channel_time_scale) if channel_name else (frame / fps)
        rot_rad = [c.evaluate(frame) if c else obj.rotation_euler[i] for i, c in enumerate(rot_curves)]
        loc = [c.evaluate(frame) if c else obj.location[i] for i, c in enumerate(loc_curves)]
        scale = [c.evaluate(frame) if c else obj.scale[i] for i, c in enumerate(scale_curves)]

        # Reuses the same proven _to_pbd_matrix + decompose path every
        # other rotation in this file goes through, rather than a
        # hand-derived per-component remap of the raw Euler values - a
        # rotation's axis conversion isn't a simple component swap the
        # way a position's is, and getting that wrong by reasoning it out
        # under time pressure is exactly the mistake that caused this
        # project's earlier rotation composition bug (see applyInstanceField's
        # "rot" case on the engine side for that story).
        euler = mathutils.Euler((rot_rad[0], rot_rad[1], rot_rad[2]), 'XYZ')
        local_matrix = mathutils.Matrix.Translation(mathutils.Vector(loc)) @ euler.to_matrix().to_4x4()
        pbd_matrix = _to_pbd_matrix(local_matrix)
        pbd_loc, pbd_rot_quat, _ = pbd_matrix.decompose()
        pbd_rot_deg = [math.degrees(a) for a in pbd_rot_quat.to_euler('XYZ')]
        # Scale isn't part of local_matrix/_to_pbd_matrix above (that
        # path is for pos/rot only) - full TRS decomposition to convert
        # a scale between the two axis conventions is what caught this
        # project's own Y/Z swap bug in the import path once already
        # (see import_pbd.py's own comment on that), so the same
        # matrix-decompose approach is used here too rather than
        # reasoning per-component under time pressure again.
        scale_matrix = _to_pbd_matrix(mathutils.Matrix.Diagonal(
            (scale[0] * _BLENDER_TO_SHADER_SCALE, scale[1] * _BLENDER_TO_SHADER_SCALE, scale[2] * _BLENDER_TO_SHADER_SCALE, 1.0)))
        _, _, pbd_scale = scale_matrix.decompose()

        parts = [f"time={time:.4g}"]
        if channel_name:
            parts.append(f"channel={channel_name}")
        parts.append(f"pos={_format_vec3(pbd_loc)}")
        parts.append(f"rot={_format_vec3(pbd_rot_deg)}")
        if channel_name:
            parts.append(f"scale={_format_vec3(pbd_scale)}")
        sound_file = _sound_for_time(obj, time)
        if sound_file:
            parts.append(f"sound={sound_file}")
        lines.append("  keyframe { " + " ".join(parts) + " }")
    return lines


def _sound_for_time(obj, time_seconds):
    """Matches the panel's own _find_sound_entry tolerance -
    looks up without creating, since export shouldn't add new empty
    entries for keyframes that never had a sound set."""
    for entry in obj.pbd.pbd_keyframe_sounds:
        if abs(entry.time - time_seconds) < 0.001 and entry.sound_file.strip():
            return os.path.basename(entry.sound_file)
    return None


def _export_mesh_vertex_data(mesh):
    """Encodes mesh's current triangulated geometry as base64, in
    EXACTLY the binary layout pbd.format.PbdMeshData.fromBase64 expects
    (see that class's own doc comment): int32 vertexCount, int32
    indexCount, per-vertex float32 x,y,z,nx,ny,nz,u,v (32 bytes), per-index
    int32, all little-endian. Takes a Mesh DATABLOCK directly (not an
    Object) - an LOD variant's geometry lives in one that was never
    linked to any Object at all (see PbdMeshLodEntry's own doc comment),
    so obj.data wouldn't reach it.

    One vertex per triangle CORNER (no sharing across triangles, matching
    mesh_preview.py's own "fine trade-off, keeps this simple" policy for
    procedural previews) - simpler than hashing (position,normal,uv)
    tuples to dedupe, and this format has no per-instance vertex-count
    budget that would make the extra few vertices matter."""
    import struct
    mesh.calc_loop_triangles()
    uv_layer = mesh.uv_layers.active.data if mesh.uv_layers.active else None

    positions = []
    normals = []
    uvs = []
    indices = []
    next_index = 0
    for tri in mesh.loop_triangles:
        for loop_index in tri.loops:
            loop = mesh.loops[loop_index]
            v = mesh.vertices[loop.vertex_index].co
            n = loop.normal  # per-loop (split) normal - respects sharp edges/autosmooth, unlike the vertex normal
            pv = _blender_to_pbd_mesh_vec(v)
            pn = _blender_to_pbd_mesh_vec(n)
            positions.append(pv)
            normals.append(pn)
            uvs.append(tuple(uv_layer[loop_index].uv) if uv_layer else (0.0, 0.0))
            indices.append(next_index)
            next_index += 1

    vertex_count = len(positions)
    buf = bytearray()
    buf += struct.pack('<ii', vertex_count, len(indices))
    for i in range(vertex_count):
        buf += struct.pack('<8f', *positions[i], *normals[i], *uvs[i])
    for idx in indices:
        buf += struct.pack('<i', idx)
    import base64
    return base64.b64encode(bytes(buf)).decode('ascii')


def _blender_to_pbd_mesh_vec(v):
    """Same Z-up -> Y-up remap as mesh_preview.py's _blender_to_pbd,
    applied to a raw mathutils Vector rather than a plain tuple - mesh
    vertex-level geometry needs the same axis convention every other
    part of this format already uses, or an embedded mesh would render
    sideways relative to everything else in the same scene."""
    return (v.x, v.z, -v.y)


def _serialize_instance(obj):
    # Root -> matrix_world (absolute position); PBD child -> matrix_local
    # (already relative to the parent, Blender's matrix_parent_inverse included).
    has_pbd_parent = _pbd_parent_of(obj) is not None
    matrix = obj.matrix_local if has_pbd_parent else obj.matrix_world
    pbd_matrix = _to_pbd_matrix(matrix)
    loc, rot_quat, scale = pbd_matrix.decompose()
    euler_deg = [math.degrees(a) for a in rot_quat.to_euler('XYZ')]

    if obj.pbd.pbd_type == 'ref':
        # No `_BLENDER_TO_SHADER_SCALE` compensation here - a ref isn't a
        # native-2x2x2-sized mesh, its scale is a plain multiplier on
        # whatever the referenced file's own content already is, so it
        # should pass straight through, not be silently doubled.
        lines = [f"pbd_ref {obj.name} {{"]
        lines.append(f"  source = {obj.pbd.pbd_ref_source}")
        if obj.pbd.pbd_ref_fallback.strip():
            lines.append(f"  fallback = {obj.pbd.pbd_ref_fallback.strip()}")
        if obj.pbd.pbd_ref_mat_override.strip():
            lines.append(f"  mat    = {obj.pbd.pbd_ref_mat_override.strip()}")
        lines.append(f"  pos    = {_format_vec3(loc)}")
        if any(abs(a) > 1e-4 for a in euler_deg):
            lines.append(f"  rot    = {_format_vec3(euler_deg)}")
        if any(abs(s - 1.0) > 1e-4 for s in scale):
            lines.append(f"  scale  = {_format_vec3(list(scale))}")
        if has_pbd_parent:
            lines.append(f"  parent = {obj.parent.name}")
        if obj.pbd.pbd_lod_enabled:
            lines.append(f"  lod    = {obj.pbd.pbd_lod}")
        if obj.pbd.pbd_category:
            lines.append(f"  category = {_quote_if_needed(obj.pbd.pbd_category)}")
        if obj.pbd.pbd_indestructible:
            lines.append("  indestructible = true")
            lines.append(f"  hardness = {obj.pbd.pbd_hardness:.4g}")
            lines.append(f"  resistance = {obj.pbd.pbd_resistance:.4g}")
        lines.append("}")
        return "\n".join(lines)

    if obj.pbd.pbd_type == 'light':
        # Same "no _BLENDER_TO_SHADER_SCALE, no mat=" reasoning as 'ref'
        # just above - a light isn't a native-2x2x2 shape either, and
        # has no material of its own to shade (it emits, doesn't
        # receive).
        lines = [f"light {obj.name} {{"]
        lines.append(f"  pos    = {_format_vec3(loc)}")
        if any(abs(a) > 1e-4 for a in euler_deg):
            lines.append(f"  rot    = {_format_vec3(euler_deg)}")
        if has_pbd_parent:
            lines.append(f"  parent = {obj.parent.name}")
        lines.append(f"  lightMode = {obj.pbd.pbd_light_mode}")
        if not obj.pbd.pbd_light_enabled:
            lines.append("  lightEnabled = false")
        lines.append(f"  lightColor = {_format_vec3(list(obj.pbd.pbd_light_color))}")
        lines.append(f"  lightIntensity = {obj.pbd.pbd_light_intensity:.4g}")
        lines.append(f"  lightRange = {obj.pbd.pbd_light_range:.4g}")
        if obj.pbd.pbd_light_mode == 'spot':
            lines.append(f"  lightSpotAngle = {math.degrees(obj.pbd.pbd_light_spot_angle):.4g}")
        if obj.pbd.pbd_category:
            lines.append(f"  category = {_quote_if_needed(obj.pbd.pbd_category)}")
        lines.append("}")
        return "\n".join(lines)

    lines = [f"{obj.pbd.pbd_type} {obj.name} {{"]
    lines.append(f"  pos   = {_format_vec3(loc)}")
    if any(abs(a) > 1e-4 for a in euler_deg):
        lines.append(f"  rot   = {_format_vec3(euler_deg)}")
    # "mesh" skips the x2 compensation for the same reason "ref" does
    # (see that branch above, which returns before reaching here): the
    # canonical-primitive-at-native-2x-size assumption this factor
    # corrects for doesn't apply to arbitrary embedded geometry, which
    # was already exported at its own real, unmodified local scale.
    scale_factor = 1.0 if obj.pbd.pbd_type == 'mesh' else _BLENDER_TO_SHADER_SCALE
    scaled = [s * scale_factor for s in scale]
    lines.append(f"  scale = {_format_vec3(scaled)}")
    if has_pbd_parent:
        lines.append(f"  parent = {obj.parent.name}")
    if obj.pbd.pbd_lod_enabled:
        lines.append(f"  lod   = {obj.pbd.pbd_lod}")
    if obj.pbd.pbd_category:
        lines.append(f"  category = {_quote_if_needed(obj.pbd.pbd_category)}")
    if obj.pbd.pbd_indestructible:
        lines.append("  indestructible = true")
        lines.append(f"  hardness = {obj.pbd.pbd_hardness:.4g}")
        lines.append(f"  resistance = {obj.pbd.pbd_resistance:.4g}")
    lines.append(f"  mat   = {obj.pbd.pbd_material}")
    if obj.pbd.pbd_type in ('cylinder', 'cone') and obj.pbd.pbd_cap != 'both':
        lines.append(f"  cap   = {obj.pbd.pbd_cap}")
    if obj.pbd.pbd_type == 'cube':
        sx, sy, sz = obj.pbd.pbd_cube_smooth_x, obj.pbd.pbd_cube_smooth_y, obj.pbd.pbd_cube_smooth_z
        if max(sx, sy, sz) > 0.001:
            lines.append(f"  smoothX = {sx:.4g}")
            lines.append(f"  smoothY = {sy:.4g}")
            lines.append(f"  smoothZ = {sz:.4g}")
        removed_codes = _removed_face_codes(obj.pbd)
        if removed_codes:
            lines.append(f"  faces = ({','.join(removed_codes)})")
    if obj.pbd.pbd_type == 'mesh':
        encoded = _export_mesh_vertex_data(obj.data)
        lines.append(f'  vertexData = "base64:{encoded}"')
        for entry in obj.pbd.pbd_mesh_lod_sources:
            if entry.mesh_data is None:
                continue
            lod_encoded = _export_mesh_vertex_data(entry.mesh_data)  # this LOD tier's own stored shape, not obj's current one
            lines.append(f'  vertexDataLod{entry.lod} = "base64:{lod_encoded}"')
    if obj.pbd.pbd_bend_enabled:
        # pbd_bend_angle is stored/returned in radians (subtype='ANGLE') -
        # the .pbd format's modifier fields are in degrees, matching `rot=`.
        lines.append("  modifier bend { axis=%s angle=%.4g }" % (
            obj.pbd.pbd_bend_axis.lower(), math.degrees(obj.pbd.pbd_bend_angle)))
    if obj.pbd.pbd_shear_enabled:
        lines.append("  modifier shear { factorX=%.4g factorY=%.4g factorZ=%.4g }" % (
            obj.pbd.pbd_shear_factor_x, obj.pbd.pbd_shear_factor_y, obj.pbd.pbd_shear_factor_z))
    if obj.pbd.pbd_taper_enabled:
        lines.append("  modifier taper { bottomScale=%.4g topScale=%.4g }" % (
            obj.pbd.pbd_taper_bottom_scale, obj.pbd.pbd_taper_top_scale))
    lines.extend(_serialize_keyframes(obj))
    if obj.pbd.pbd_link_group:
        lines.append(f"  linkGroup = {obj.pbd.pbd_link_group}")
    if obj.pbd.pbd_metadata:
        lines.append("  metadata = true")
        for entry in obj.pbd.pbd_linked_doors:
            if entry.door:
                lines.append(f"  containerTrigger = {entry.door.name}")
    if obj.pbd.pbd_loop_animation:
        lines.append("  loop = true")
    # Channel-mode keyframes (see _serialize_keyframes) already carry
    # channel=/scale= per keyframe when obj.pbd.pbd_channel_name is set -
    # nothing extra needed on the instance block itself.
    lines.append("}")
    return "\n".join(lines)


def _write_pbdmat(context, pbd_filepath):
    """Writes EMBEDDED-source entries from scene.pbd_materials to <same
    base name>.pbdmat next to the .pbd file. SHARED-source entries are
    skipped here entirely - they're not duplicated into a per-scene
    file, they get their own include_material line pointing straight at
    the project-wide materials/NAME.pbdmat instead (see material_source
    on PbdMaterialEntry). Returns a list of include_material targets (0
    or more) - a completely empty catalog, or one where every entry is
    shared, are both normal cases, not errors.
    """
    embedded = [e for e in context.scene.pbd_materials if e.material_source == 'EMBEDDED']
    shared = [e for e in context.scene.pbd_materials if e.material_source == 'SHARED']

    includes = []

    if embedded:
        base, _ = os.path.splitext(pbd_filepath)
        mat_filepath = base + ".pbdmat"
        lines = []
        for entry in embedded:
            lines.append(f"material {entry.name} {{")
            lines.append("  color     = (%.4g, %.4g, %.4g)" % tuple(entry.color))
            lines.append(f"  shininess = {entry.shininess:.4g}")
            lines.append(f"  specular  = {entry.specular:.4g}")
            if entry.texture_path:
                lines.append(f"  texture   = {os.path.basename(entry.texture_path)}")
                if abs(entry.uv_scale_u - 1.0) > 0.001 or abs(entry.uv_scale_v - 1.0) > 0.001:
                    if abs(entry.uv_scale_u - entry.uv_scale_v) < 0.001:
                        lines.append(f"  uvScale   = {entry.uv_scale_u:.4g}")  # both axes match - the shorter, backward-compatible single-value form
                    else:
                        lines.append(f"  uvScaleU  = {entry.uv_scale_u:.4g}")
                        lines.append(f"  uvScaleV  = {entry.uv_scale_v:.4g}")
            if entry.normal_map_path:
                lines.append(f"  normalMap = {os.path.basename(entry.normal_map_path)}")
            if entry.roughness_map_path:
                lines.append(f"  roughnessMap = {os.path.basename(entry.roughness_map_path)}")
            if entry.displacement_map_path:
                lines.append(f"  displacementMap = {os.path.basename(entry.displacement_map_path)}")
                lines.append(f"  displacementScale = {entry.displacement_scale:.4g}")
            if entry.reflectivity > 0.001:
                lines.append(f"  reflectivity = {entry.reflectivity:.4g}")
            if entry.transparency > 0.001:
                lines.append(f"  transparency = {entry.transparency:.4g}")
            lines.append("}")
            lines.append("")
        with open(mat_filepath, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))
        includes.append(os.path.basename(mat_filepath))

    if shared:
        materials_dir = _resolve_materials_dir(context)
        pbd_dir = os.path.dirname(os.path.abspath(pbd_filepath))
        for entry in shared:
            shared_path = os.path.join(materials_dir, f"{entry.name}.pbdmat")
            if not os.path.exists(shared_path):
                # Not fatal - the exported .pbd just won't find this
                # material until the file shows up (a scrape/conversion
                # run away from finishing, say) - report it rather than
                # silently reference a path that doesn't resolve.
                print(f"[PBD export] WARNING: shared material '{entry.name}' not found at {shared_path}")
            rel = os.path.relpath(shared_path, pbd_dir)
            includes.append(rel.replace(os.sep, "/"))

    return includes


def _find_gradle_root_from(start_path):
    """Walks up from start_path (a file or directory) looking for
    build.gradle.kts. Replaces pbd_project_root, a separate persistent
    setting the user had to configure by hand and could easily point at
    the wrong place (the add-on's own install folder rather than the
    actual Gradle project - which is exactly what happened). Derived
    instead from wherever the user actually chooses to save/browse each
    time, via Blender's own file browser - which already remembers the
    last-used directory per operator across sessions on its own, so
    repeat exports into the same project don't need a separately-
    remembered setting to stay convenient."""
    current = os.path.abspath(start_path)
    if not os.path.isdir(current):
        current = os.path.dirname(current)
    for _ in range(25):  # bounded - a symlink loop or similar shouldn't spin forever
        if os.path.isfile(os.path.join(current, "build.gradle.kts")):
            return current
        parent = os.path.dirname(current)
        if parent == current:  # reached the filesystem root
            return None
        current = parent
    return None


def _find_gradle_root_with_blend_fallback(chosen_path):
    """_find_gradle_root_from(chosen_path), falling back to walking up
    from THIS .blend file's own saved location if that comes up empty -
    covers the common case of a .blend kept inside the project while
    its content gets exported somewhere else entirely (a separate
    'model' or 'assets' folder outside the Gradle project, say):
    without this, that's a hard failure with nothing to do but move the
    export inside the project after all, even though the actual answer
    (which project this belongs to) was sitting right there in
    bpy.data.filepath the whole time. Returns None if neither works,
    same as _find_gradle_root_from alone."""
    root = _find_gradle_root_from(chosen_path)
    if root is not None:
        return root
    if bpy.data.filepath:
        return _find_gradle_root_from(bpy.data.filepath)
    return None


def _resolve_materials_dir(context):
    """scene.pbd_materials_folder if set (a dedicated setting,
    independent of anything else - see materials.py's register()),
    else a best-effort guess relative to this .py file's own location
    (tools/blender-addon/pbd_tools/ -> ../../../src/main/resources/
    materials), which only works if the add-on happens to be installed
    from inside a checkout of this project rather than Blender's own
    separate add-ons folder (the normal case)."""
    if context.scene.pbd_materials_folder:
        return context.scene.pbd_materials_folder
    return os.path.normpath(os.path.join(os.path.dirname(__file__), "..", "..", "..", "..",
                                          "src", "main", "resources", "materials"))


def _serialize_embedded_ref(obj):
    """Embeds a referenced file's instances directly into this export
    instead of a pbd_ref pointing externally at it - an invisible
    metadata anchor cube carries this object's own transform, and every
    ROOT instance from the referenced file (one with no parent of its
    own already) gets parented to that anchor, so the engine's existing
    hierarchy-composition math (parent.matrix_world @ child.local)
    places everything correctly without this function needing to
    compose any matrices itself. Non-root instances in the referenced
    file keep their own original parent unchanged - only its roots
    attach to the new anchor."""
    from . import import_pbd
    import os

    matrix = obj.matrix_local if _pbd_parent_of(obj) is not None else obj.matrix_world
    pbd_matrix = _to_pbd_matrix(matrix)
    loc, rot_quat, scale = pbd_matrix.decompose()
    euler_deg = [math.degrees(a) for a in rot_quat.to_euler('XYZ')]

    anchor_name = obj.name
    lines = [f"cube {anchor_name} {{"]
    lines.append(f"  pos    = {_format_vec3(loc)}")
    if any(abs(a) > 1e-4 for a in euler_deg):
        lines.append(f"  rot    = {_format_vec3(euler_deg)}")
    lines.append(f"  scale  = {_format_vec3(list(scale))}")
    if _pbd_parent_of(obj) is not None:
        lines.append(f"  parent = {obj.parent.name}")
    if obj.pbd.pbd_lod_enabled:
        lines.append(f"  lod    = {obj.pbd.pbd_lod}")
    if obj.pbd.pbd_category:
        lines.append(f"  category = {_quote_if_needed(obj.pbd.pbd_category)}")
    if obj.pbd.pbd_indestructible:
        lines.append("  indestructible = true")
        lines.append(f"  hardness = {obj.pbd.pbd_hardness:.4g}")
        lines.append(f"  resistance = {obj.pbd.pbd_resistance:.4g}")
    lines.append("  metadata = true")
    lines.append("}")

    source_path = bpy.path.abspath(obj.pbd.pbd_ref_source)
    if not os.path.exists(source_path):
        lines.append(f"# WARNING: embed source not found at export time: {source_path}")
        return "\n".join(lines)

    try:
        _include_material, instances = import_pbd.parse_pbd_file(source_path)
    except Exception as e:
        lines.append(f"# WARNING: failed to read embed source '{source_path}': {e}")
        return "\n".join(lines)

    mat_override = obj.pbd.pbd_ref_mat_override.strip()
    for inst in instances:
        block = [f"{inst['type']} {inst['id']} {{"]
        has_own_parent = 'parent' in inst['fields']
        for key, value in inst['fields'].items():
            if key == 'mat' and mat_override:
                value = mat_override  # overrides this sub-instance's own mat=, same as the non-embedded pbd_ref case above
            block.append(f"  {key} = {value}")
        if not has_own_parent:
            block.append(f"  parent = {anchor_name}")
        for trigger in inst.get('containerTriggers', []):
            block.append(f"  containerTrigger = {trigger}")
        for mod in inst['modifiers']:
            params_str = " ".join(f"{k}={v}" for k, v in mod['params'].items())
            block.append(f"  modifier {mod['type']} {{ {params_str} }}")
        for kf in inst['keyframes']:
            kf_parts = [f"time={kf['time']}"]
            if kf.get('pos') is not None:
                kf_parts.append(f"pos={_format_vec3(kf['pos'])}")
            if kf.get('rot') is not None:
                kf_parts.append(f"rot={_format_vec3(kf['rot'])}")
            block.append(f"  keyframe {{ {' '.join(kf_parts)} }}")
        block.append("}")
        lines.append("\n".join(block))

    return "\n".join(lines)


def _minify_pbd_text(text):
    """Mirrors PbdSerializer.java's pretty/minified distinction for this
    add-on's own independent Python export (it builds pretty text
    directly and never goes through the Java serializer at all) - every
    separator trimmed to the minimum PbdParser can still read
    unambiguously: no indentation, fields space- rather than
    newline-separated, comment lines dropped entirely (PbdParser's
    skipWhitespaceAndComments treats them as nothing regardless, so they
    only add size, never meaning, to a minified file).

    Works line-by-line against export_pbd.py's own consistent, known
    output shape (a block-opener line ending in "{", a bare "}" closer,
    an ordinary "  key = value" field line, or an already-compact
    "keyframe { ... }" line whose own internal fields use a bare "="
    with no spaces, distinguishing it from an ordinary field line here)
    rather than attempting a general-purpose reformatter - this only
    ever needs to handle what THIS module itself writes, not arbitrary
    hand-authored .pbd text.
    """
    out_tokens = []
    for raw_line in text.split("\n"):
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.endswith("{") or line == "}":
            out_tokens.append(line)
        elif " = " in line:
            key, _, value = line.partition(" = ")
            key = key.rstrip()  # pretty-formatting pads keys for column alignment ("pos   = ..."), which partition on " = " leaves attached to the key otherwise - not wrong to parse (readIdentifier stops at the first space either way) but not actually minimal either
            value = value.lstrip()
            # Collapse ", " -> "," inside a parenthesized tuple value
            # (pos/scale/rot/faces all use this shape), matching
            # PbdSerializer's own minified vec3 formatting.
            if value.startswith("("):
                value = value.replace(", ", ",")
            out_tokens.append(f"{key}={value}")
        else:
            # Already-compact lines pass through unchanged: a
            # "keyframe { time=0 sound=foo.wav }" block (its own fields
            # use bare "=", never " = ", specifically so this branch
            # catches it), "pbd_version 1", "include_material foo.pbdmat".
            out_tokens.append(line)
    return " ".join(out_tokens) + "\n"


def export_scene_to_pbd(context, filepath):
    tagged = [obj for obj in context.scene.objects
              if getattr(obj, "pbd", None) and obj.pbd.is_pbd_primitive]
    # No longer any need to exclude LOD-source objects from this list -
    # an LOD variant's geometry now lives in a Mesh datablock stored
    # directly on the entry (see PbdMeshLodEntry), never as a second
    # Object in the scene at all, so there is nothing here that could
    # double-count it.
    if not tagged:
        return 0, [], 0

    warnings = [msg for obj in tagged if not obj.pbd.pbd_shear_enabled and obj.pbd.pbd_type not in ('ref', 'light')
                for msg in [_check_mesh_matches_canonical(obj)] if msg]

    # Parents must appear before their children - the .pbd parser knows
    # how to re-sort them (PbdScene.resolveHierarchy), but an already-
    # ordered export stays more readable by hand.
    ordered = []
    seen = set()

    def visit(obj):
        if obj.name in seen:
            return
        parent = _pbd_parent_of(obj)
        if parent is not None:
            visit(parent)
        seen.add(obj.name)
        ordered.append(obj)

    for obj in tagged:
        visit(obj)

    blocks = []
    for obj in ordered:
        if obj.pbd.pbd_type == 'ref' and obj.pbd.pbd_ref_embed and obj.pbd.pbd_ref_source:
            blocks.append(_serialize_embedded_ref(obj))
        else:
            blocks.append(_serialize_instance(obj))
    keyframe_count = sum(block.count("keyframe {") for block in blocks)

    mat_includes = _write_pbdmat(context, filepath)

    header = "pbd_version 1\n"
    # File-level metadata (PbdScene.java's own name/kind/authors/origin)
    # - describes the FILE as a whole, so read from the SCENE, not from
    # any one object, and written once here rather than per-instance.
    if context.scene.pbd_scene_name.strip():
        header += f'name = {_quote_if_needed(context.scene.pbd_scene_name.strip())}\n'
    if context.scene.pbd_scene_kind.strip():
        header += f"kind = {context.scene.pbd_scene_kind.strip()}\n"
    for author in context.scene.pbd_scene_authors.split(","):
        author = author.strip()
        if author:
            header += f'author = {_quote_if_needed(author)}\n'
    if context.scene.pbd_scene_origin.strip():
        header += f'origin = {_quote_if_needed(context.scene.pbd_scene_origin.strip())}\n'
    for include in mat_includes:
        header += f"include_material {include}\n"
    if warnings:
        header += "\n# WARNING - please check before using this file:\n"
        for msg in warnings:
            header += f"#   {msg}\n"
    text = header + "\n" + "\n\n".join(blocks) + "\n"
    if getattr(context.scene, "pbd_export_minify", False):
        text = _minify_pbd_text(text)

    with open(filepath, "w", encoding="utf-8") as f:
        f.write(text)

    return len(ordered), warnings, keyframe_count


class EXPORT_OT_pbd(bpy.types.Operator, ExportHelper):
    """Exports the scene's PBD-tagged objects to a .pbd file"""

    bl_idname = "export_scene.pbd"
    bl_label = "Export PBD"
    filename_ext = ".pbd"

    filter_glob: bpy.props.StringProperty(default="*.pbd", options={'HIDDEN'})

    def execute(self, context):
        count, warnings, keyframe_count = export_scene_to_pbd(context, self.filepath)
        if count == 0:
            self.report({'WARNING'}, "No PBD-tagged object in the scene")
            return {'CANCELLED'}
        for msg in warnings:
            self.report({'WARNING'}, msg)
        suffix = f" - {len(warnings)} warning(s) above" if warnings else ""
        # Says explicitly when zero keyframes were found, rather than
        # just going quiet about animation - if an object was keyframed
        # in Blender but this reads 0, that's the direct signal something
        # about reading its f-curves failed (see anim_compat.py), not
        # "nothing to report".
        anim_note = f", {keyframe_count} keyframe(s) across all objects" if keyframe_count else ", 0 keyframes found on any object"
        self.report({'INFO'}, f"{count} primitive(s) exported to {self.filepath}{anim_note}{suffix}")
        return {'FINISHED'}


def menu_func_export(self, context):
    self.layout.operator(EXPORT_OT_pbd.bl_idname, text="PBD (.pbd)")


CLASSES = (EXPORT_OT_pbd,)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.TOPBAR_MT_file_export.append(menu_func_export)


def unregister():
    bpy.types.TOPBAR_MT_file_export.remove(menu_func_export)
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
