import os

import bpy
import mathutils

from . import anim_compat


def _find_sound_entry(obj, time_seconds):
    """Read-only lookup - safe to call from draw(). The write half (add a
    new entry) used to live in the same function and get called directly
    from draw_animation_section below, which is exactly what Blender's
    "Writing to ID classes in this context is not allowed" guards
    against: draw() runs in a read-only context, and a CollectionProperty
    .add() is a write, full stop, regardless of how small or how often
    the same one would end up added. Splitting the write out into
    OBJECT_OT_pbd_add_keyframe_sound's execute() - which runs in a real
    operator-invoke context, where writes ARE allowed - is the actual
    fix, not a workaround; see that operator below."""
    for entry in obj.pbd.pbd_keyframe_sounds:
        if abs(entry.time - time_seconds) < 0.001:
            return entry
    return None


def draw_pbd_properties_safe(layout, obj, scene):
    """Wraps draw_pbd_properties in a try/except that shows a VISIBLE red
    error box instead of the section just silently stopping partway
    through, which is what a bare Python exception during Blender panel
    draw() does by default (whatever was already added stays on screen,
    everything after the failure point simply never draws, and the only
    trace is a line in Blender's system console most people never have
    open). Full traceback still goes to the console via traceback.print_exc()
    for actually debugging it - this box is for noticing something broke
    at all, not fixing it from the UI."""
    try:
        draw_pbd_properties(layout, obj, scene)
    except Exception as e:
        box = layout.box()
        box.alert = True
        box.label(text="PBD panel error - see System Console", icon='ERROR')
        box.label(text=str(e)[:80])
        box.label(text="(Blender/add-on version mismatch, or a stale")
        box.label(text="install - try Preferences > Add-ons > Remove,")
        box.label(text="then reinstall and restart Blender.)")
        import traceback
        traceback.print_exc()


def draw_pbd_properties(layout, obj, scene):
    """Shared by both panels below so every PBD feature exposed here shows
    up the same way regardless of which panel the user has open."""
    layout.prop(obj.pbd, "is_pbd_primitive")
    if not obj.pbd.is_pbd_primitive:
        return

    layout.prop(obj.pbd, "pbd_type")
    layout.prop(obj.pbd, "pbd_metadata")
    if obj.pbd.pbd_metadata:
        layout.label(text="Renders nothing (engine + Blender wireframe)", icon='INFO')

    lod_row = layout.row(align=True)
    lod_row.prop(obj.pbd, "pbd_lod_enabled", text="")
    lod_sub = lod_row.row(align=True)
    lod_sub.enabled = obj.pbd.pbd_lod_enabled
    lod_sub.prop(obj.pbd, "pbd_lod")
    if obj.pbd.pbd_lod_enabled:
        layout.label(text="Field only - engine doesn't pick between LOD", icon='INFO')
        layout.label(text="tiers by distance yet, this just gets exported.")
    layout.prop(obj.pbd, "pbd_category")

    # Storage-cube side: an actual list (like the material list elsewhere
    # in this addon), not a "select several objects in a specific order
    # then click a button" convention - a standard +/- list is something
    # every Blender user already recognizes on sight.
    box = layout.box()
    box.label(text="Doors that open this container:", icon='LINKED')
    if obj.pbd.pbd_metadata:
        row = box.row()
        row.template_list("PBD_UL_linked_doors", "", obj.pbd, "pbd_linked_doors",
                           obj.pbd, "pbd_linked_doors_active_index", rows=3)
        col = row.column(align=True)
        col.operator("pbd.add_linked_door", text="", icon='ADD')
        col.operator("pbd.remove_linked_door", text="", icon='REMOVE')

        active_index = obj.pbd.pbd_linked_doors_active_index
        if 0 <= active_index < len(obj.pbd.pbd_linked_doors):
            box.prop(obj.pbd.pbd_linked_doors[active_index], "door", text="Door object")

        if len(obj.pbd.pbd_linked_doors) == 0:
            box.label(text="No door set - falls back to any open", icon='ERROR')
            box.label(text="object in the scene. Click + to add one.")
        elif len(obj.pbd.pbd_linked_doors) == 1:
            box.label(text="Shows contents once this door is open.")
        else:
            box.label(text="Shows contents once ANY of these is open;")
            box.label(text="cache only resets once ALL are closed.")
    else:
        box.label(text="Check \"Metadata Only\" above first.", icon='INFO')

    # Door side: read-only, computed by scanning the scene rather than a
    # second parallel list - the collection above (per storage cube) is
    # kept as the only real source of truth, so this can never drift out
    # of sync with it.
    controls = _storage_cubes_controlled_by(obj, scene)
    if controls:
        box = layout.box()
        box.label(text=f"This object opens {len(controls)} container(s):", icon='PACKAGE')
        for cube in controls:
            box.label(text=f"  - {cube.name}", icon='CUBE')

    if obj.pbd.pbd_type != 'ref':
        box = layout.box()
        box.label(text="Dimensions (grows from center):")
        box.prop(obj.pbd, "pbd_dim_x")
        box.prop(obj.pbd, "pbd_dim_y")
        box.prop(obj.pbd, "pbd_dim_z")
        box.operator("pbd.refresh_uv", icon='UV', text="Refresh UV Mapping")
        box.label(text="Run after resizing to fix stretched textures.")
        box.operator("pbd.start_texture_painting", icon='TPAINT_HLT', text="Start Texture Painting")

        box2 = layout.box()
        box2.label(text="Face position (moves just that face):")
        row = box2.row(align=True)
        row.prop(obj.pbd, "pbd_face_min_x")
        row.prop(obj.pbd, "pbd_face_max_x")
        row = box2.row(align=True)
        row.prop(obj.pbd, "pbd_face_min_y")
        row.prop(obj.pbd, "pbd_face_max_y")
        row = box2.row(align=True)
        row.prop(obj.pbd, "pbd_face_min_z")
        row.prop(obj.pbd, "pbd_face_max_z")
        row = box2.row(align=True)
        row.label(text="Mirror:")
        row.operator("pbd.mirror_face_position", text="X").axis = 'x'
        row.operator("pbd.mirror_face_position", text="Y").axis = 'y'
        row.operator("pbd.mirror_face_position", text="Z").axis = 'z'

    if obj.pbd.pbd_type == 'mesh':
        lod_box = layout.box()
        lod_box.label(text="LOD variants (optional):", icon='MESH_DATA')
        lod_box.label(text="This object's own CURRENT shape is always LOD 0.")
        row = lod_box.row()
        row.template_list("PBD_UL_mesh_lod", "", obj.pbd, "pbd_mesh_lod_sources",
                           obj.pbd, "pbd_mesh_lod_active_index", rows=3)
        col = row.column(align=True)
        col.operator("pbd.add_mesh_lod", text="", icon='ADD')
        col.operator("pbd.remove_mesh_lod", text="", icon='REMOVE')
        idx = obj.pbd.pbd_mesh_lod_active_index
        if 0 <= idx < len(obj.pbd.pbd_mesh_lod_sources):
            entry = obj.pbd.pbd_mesh_lod_sources[idx]
            lod_box.prop(entry, "lod")
            btn_row = lod_box.row(align=True)
            btn_row.operator("pbd.capture_mesh_lod", icon='IMPORT')
            apply_row = btn_row.row(align=True)
            apply_row.enabled = entry.mesh_data is not None
            apply_row.operator("pbd.apply_mesh_lod", icon='EXPORT')
            lod_box.label(text="Sculpt/edit this object into the shape you", icon='INFO')
            lod_box.label(text="want, Capture it here, then move to the next")
            lod_box.label(text="row - Apply brings a saved shape back to edit")
            lod_box.label(text="or re-capture. Only one shape is ever visible.")
        lod_box.label(text="Data round-trips through export/import; the", icon='INFO')
        lod_box.label(text="engine doesn't pick between tiers by distance yet.")

    if obj.pbd.pbd_type == 'ref':
        # A reference has no geometry of its own (see
        # OBJECT_OT_add_pbd_ref) - material/cap/smooth/taper/bend/shear
        # all apply to a shape this object doesn't have, so none of them
        # are shown; only where the referenced file goes.
        box = layout.box()
        box.label(text="PBD Reference (composition):", icon='LINKED')
        box.prop(obj.pbd, "pbd_ref_source")
        if not obj.pbd.pbd_ref_source:
            box.label(text="Set a source above: a local .pbd path, or a", icon='ERROR')
            box.label(text="full http(s):// URL for a remote one.")
        elif obj.pbd.pbd_ref_source.strip().lower().startswith(('http://', 'https://')):
            box.prop(obj.pbd, "pbd_ref_fallback")
        box.operator("pbd.test_reference", icon='URL')
        box.prop(obj.pbd, "pbd_ref_embed")
        layout.label(text="Blender can't preview the referenced file's", icon='INFO')
        layout.label(text="geometry yet - this Empty only marks placement")
        return

    layout.prop_search(obj.pbd, "pbd_material", scene, "pbd_materials")

    if obj.pbd.pbd_type in ('cylinder', 'cone'):
        row = layout.row()
        row.prop(obj.pbd, "pbd_cap")
        if obj.pbd.pbd_type == 'cone' and obj.pbd.pbd_cap in ('top', 'bottom'):
            row.enabled = False
            layout.label(text="Cone has one cap - use Both/None", icon='INFO')

    if obj.pbd.pbd_type == 'cube':
        box = layout.box()
        box.label(text="Smooth (per axis):")
        box.prop(obj.pbd, "pbd_cube_smooth_x")
        box.prop(obj.pbd, "pbd_cube_smooth_y")
        box.prop(obj.pbd, "pbd_cube_smooth_z")
        if max(obj.pbd.pbd_cube_smooth_x, obj.pbd.pbd_cube_smooth_y, obj.pbd.pbd_cube_smooth_z) > 0.001:
            box.label(text="Previewed live by regenerating the mesh", icon='INFO')

        # Face removal - its own clearly-headed box (not folded into
        # Smooth above) since it's a commonly-needed, easy-to-miss
        # feature otherwise: an open crate or a cabinet with no back
        # panel. Grid layout (3 rows of 2, one row per Blender axis) so
        # all 6 are visible at once, no scrolling within the section.
        face_box = layout.box()
        face_box.label(text="Faces (untick to remove):", icon='MESH_CUBE')
        grid = face_box.grid_flow(row_major=True, columns=2, even_columns=True)
        grid.prop(obj.pbd, "pbd_cube_face_posx")
        grid.prop(obj.pbd, "pbd_cube_face_negx")
        grid.prop(obj.pbd, "pbd_cube_face_posy")
        grid.prop(obj.pbd, "pbd_cube_face_negy")
        grid.prop(obj.pbd, "pbd_cube_face_posz")
        grid.prop(obj.pbd, "pbd_cube_face_negz")
        removed_count = sum(1 for p in (
            obj.pbd.pbd_cube_face_posx, obj.pbd.pbd_cube_face_negx,
            obj.pbd.pbd_cube_face_posy, obj.pbd.pbd_cube_face_negy,
            obj.pbd.pbd_cube_face_posz, obj.pbd.pbd_cube_face_negz) if not p)
        if removed_count:
            face_box.label(text=f"{removed_count} face(s) removed - exported as faces=", icon='CHECKMARK')

    if obj.pbd.pbd_type in ('cylinder', 'cone'):
        box = layout.box()
        box.prop(obj.pbd, "pbd_taper_enabled")
        if obj.pbd.pbd_taper_enabled:
            box.prop(obj.pbd, "pbd_taper_bottom_scale")
            box.prop(obj.pbd, "pbd_taper_top_scale")
            box.label(text="No live preview: Blender's Taper uses one", icon='INFO')
            box.label(text="factor, not independent top/bottom scales")

    box = layout.box()
    box.prop(obj.pbd, "pbd_bend_enabled")
    if obj.pbd.pbd_bend_enabled:
        box.prop(obj.pbd, "pbd_bend_axis")
        box.prop(obj.pbd, "pbd_bend_angle")
        box.label(text="Previewed live via a Simple Deform modifier", icon='INFO')

    box = layout.box()
    box.prop(obj.pbd, "pbd_shear_enabled")
    if obj.pbd.pbd_shear_enabled:
        box.prop(obj.pbd, "pbd_shear_factor_x")
        box.prop(obj.pbd, "pbd_shear_factor_y")
        box.prop(obj.pbd, "pbd_shear_factor_z")
        box.label(text="Previewed live by regenerating the mesh", icon='INFO')

    draw_animation_section(layout, obj)


def draw_animation_section(layout, obj):
    """Animation (a door opening, say) uses Blender's OWN native
    keyframing on rotation/location - there's no separate PBD keyframe
    tool, the exporter (_serialize_keyframes) just reads whatever
    rotation_euler/location f-curves the object already has. This
    section exists purely to make that discoverable and to remove the
    need to know Blender's own keyframing shortcuts: without it, nothing
    anywhere hints that keyframing is even the right approach, or
    confirms it actually picked something up."""
    box = layout.box()
    box.label(text="Animation (door/drawer opening):")

    box.prop(obj.pbd, "pbd_link_group")
    if obj.pbd.pbd_link_group:
        box.label(text="Opens together with other objects", icon='LINKED')
        box.label(text="using this same Link Group name.")
    box.prop(obj.pbd, "pbd_loop_animation")
    box.prop(obj.pbd, "pbd_channel_name")
    if obj.pbd.pbd_channel_name.strip():
        box.prop(obj.pbd, "pbd_channel_time_scale")
        box.label(text="Keyframe Scale normally below - frame number", icon='INFO')
        box.label(text=f"N maps to channel value N x {obj.pbd.pbd_channel_time_scale:.4g}.")

    times = _keyframe_times(obj)
    if times:
        box.label(text=f"{len(times)} keyframe(s):", icon='CHECKMARK')
        for t in times:
            row = box.row(align=True)
            row.label(text=f"  t={t:.2f}s")
            op = row.operator("pbd.goto_keyframe", text="", icon='PLAY')
            op.time_seconds = t
            op = row.operator("pbd.delete_keyframe", text="", icon='X')
            op.time_seconds = t
            sound_box = box.box()
            sound_row = sound_box.row(align=True)
            sound_entry = _find_sound_entry(obj, t)
            if sound_entry is not None:
                sound_row.label(text="Sound:", icon='SPEAKER')
                sound_row.prop(sound_entry, "sound_file", text="")
                op = sound_row.operator("pbd.remove_keyframe_sound", text="", icon='X')
                op.time_seconds = t
            else:
                op = sound_row.operator("pbd.add_keyframe_sound", text="Add Sound", icon='SPEAKER')
                op.time_seconds = t
    else:
        box.label(text="No keyframes on this object yet.", icon='INFO')

    row = box.row(align=True)
    row.operator("pbd.insert_animation_keyframe", text="Insert Keyframe Here", icon='KEY_HLT')
    tip = box.column(align=True)
    tip.scale_y = 0.8
    tip.label(text="Move the timeline (bottom of screen),")
    tip.label(text="rotate/move this object to its next")
    tip.label(text="pose, click Insert again. Exported")
    tip.label(text="keyframe times = frame / scene FPS.")


class OBJECT_OT_pbd_add_keyframe_sound(bpy.types.Operator):
    """Adds a pbd_keyframe_sounds entry for this exact keyframe time -
    the write half of what _find_sound_entry used to do inline during
    draw(), moved here because operator execute() runs in a context
    where writing to ID data is actually allowed, unlike draw()."""
    bl_idname = "pbd.add_keyframe_sound"
    bl_label = "Add Keyframe Sound"
    bl_options = {'REGISTER', 'UNDO'}
    time_seconds: bpy.props.FloatProperty()

    def execute(self, context):
        obj = context.object
        if _find_sound_entry(obj, self.time_seconds) is not None:
            return {'CANCELLED'}  # redundant click (e.g. double-invoke) - nothing to do
        entry = obj.pbd.pbd_keyframe_sounds.add()
        entry.time = self.time_seconds
        return {'FINISHED'}


class OBJECT_OT_pbd_remove_keyframe_sound(bpy.types.Operator):
    """Removes this keyframe's sound entry entirely (not just clearing
    the filename) so the row reverts to the 'Add Sound' button rather
    than staying as an empty, always-visible field."""
    bl_idname = "pbd.remove_keyframe_sound"
    bl_label = "Remove Keyframe Sound"
    bl_options = {'REGISTER', 'UNDO'}
    time_seconds: bpy.props.FloatProperty()

    def execute(self, context):
        obj = context.object
        sounds = obj.pbd.pbd_keyframe_sounds
        for i, entry in enumerate(sounds):
            if abs(entry.time - self.time_seconds) < 0.001:
                sounds.remove(i)
                return {'FINISHED'}
        return {'CANCELLED'}


class OBJECT_OT_pbd_goto_keyframe(bpy.types.Operator):
    """Moves the playhead to this keyframe's frame, so its pose is what's
    visible in the viewport for hand-editing (move/rotate the object,
    then re-keyframe from the toolbar button above) - this add-on has no
    separate pose-editing UI of its own, this is the bridge to using
    Blender's normal transform tools at the right moment in time."""
    bl_idname = "pbd.goto_keyframe"
    bl_label = "Go To Keyframe"
    bl_options = {'REGISTER', 'UNDO'}
    time_seconds: bpy.props.FloatProperty()

    def execute(self, context):
        fps = context.scene.render.fps
        context.scene.frame_set(round(self.time_seconds * fps))
        return {'FINISHED'}


class OBJECT_OT_pbd_delete_keyframe(bpy.types.Operator):
    """Removes every rotation_euler/location keyframe point at this exact
    time (across whichever of those 6 channels actually have one there)
    from the active object - the missing "edit" half of the panel's
    keyframe list, which previously only showed a count with no way to
    change it short of switching to Blender's own Dope Sheet by hand."""
    bl_idname = "pbd.delete_keyframe"
    bl_label = "Delete Keyframe"
    bl_options = {'REGISTER', 'UNDO'}
    time_seconds: bpy.props.FloatProperty()

    def execute(self, context):
        obj = context.object
        fcurves = anim_compat.get_object_fcurves(obj)
        fps = context.scene.render.fps
        frame = self.time_seconds * fps
        removed = 0
        for fc in fcurves:
            if fc.data_path not in ("rotation_euler", "location"):
                continue
            for kp in list(fc.keyframe_points):
                if abs(kp.co.x - frame) < 0.5:  # within half a frame - float rounding, not a real second keyframe nearby
                    fc.keyframe_points.remove(kp)
                    removed += 1
        self.report({'INFO'}, f"Removed {removed} keyframe point(s) at t={self.time_seconds:.2f}s")
        return {'FINISHED'}


def _keyframe_times(obj):
    """Frame numbers (already converted to seconds) with a keyframe on
    rotation_euler or location, deduplicated and sorted - same curves
    _serialize_keyframes reads at export time (see anim_compat for why
    this doesn't touch action.fcurves directly)."""
    fcurves = anim_compat.get_object_fcurves(obj)
    if not fcurves:
        return []
    curves = [anim_compat.find_fcurve(fcurves, "rotation_euler", i) for i in range(3)]
    curves += [anim_compat.find_fcurve(fcurves, "location", i) for i in range(3)]
    frames = sorted({kp.co.x for c in curves if c for kp in c.keyframe_points})
    fps = bpy.context.scene.render.fps
    return [f / fps for f in frames]


def draw_material_catalog(layout, scene):
    """Shared by both panels - the scene-wide PBD Materials list backing a
    .pbdmat file (see materials.py). Editing a field here updates a real
    Blender Material immediately, so every object already using that name
    re-previews with the new color/shading right away.

    Typing a name directly into an object's Material field (prop_search
    allows free text, not just catalog picks) does NOT add it here - the
    catalog and an object's pbd_material are only linked by name, not
    auto-synced either direction. An object referencing a name with no
    catalog entry has nothing wrong with it (it exports and renders
    fine, falling back to a neutral color - see PbdRenderer's
    resolveMaterialEntry) but its texture/UV/normal-map/etc fields
    literally don't exist anywhere to edit until a catalog entry for
    that name exists - "Sync from Objects" below is the fast way to
    create one for everything already in use.
    """
    if len(scene.pbd_materials) == 0:
        box = layout.box()
        box.label(text="No materials yet.", icon='INFO')
        box.label(text="Add one below, or Sync from")
        box.label(text="Objects if you've already typed")
        box.label(text="material names on some objects.")

    row = layout.row()
    row.template_list("PBD_UL_materials", "", scene, "pbd_materials", scene, "pbd_materials_active_index", rows=3)
    col = row.column(align=True)
    col.operator("pbd.material_add", text="", icon='ADD')
    col.operator("pbd.material_remove", text="", icon='REMOVE')

    idx = scene.pbd_materials_active_index
    if 0 <= idx < len(scene.pbd_materials):
        entry = scene.pbd_materials[idx]
        box = layout.box()
        box.prop(entry, "name")
        box.prop(entry, "color")
        box.prop(entry, "shininess")
        box.prop(entry, "specular")
        box.prop(entry, "texture_path")
        box.prop(entry, "uv_scale")
        box.prop(entry, "normal_map_path")
        box.prop(entry, "roughness_map_path")
        box.prop(entry, "displacement_map_path")
        if entry.displacement_map_path:
            box.prop(entry, "displacement_scale")
        box.prop(entry, "material_source")
        box.prop(entry, "reflectivity")
        box.prop(entry, "transparency")

    row = layout.row(align=True)
    row.operator("pbd.material_load", text="Load .pbdmat", icon='IMPORT')
    row.operator("pbd.material_save", text="Save .pbdmat", icon='EXPORT')
    layout.operator("pbd.material_sync_from_objects", text="Sync from Objects", icon='FILE_REFRESH')
    layout.operator("pbd.refresh", text="Refresh Materials", icon='FILE_REFRESH')


class OBJECT_OT_pbd_insert_animation_keyframe(bpy.types.Operator):
    """Inserts a rotation_euler keyframe on the active object at the
    current frame - exactly what pressing I over Rotation in the N-panel
    or viewport already does; this just saves knowing that shortcut, and
    makes it a one-click action from the PBD tab specifically. Position
    a door/drawer object at its current pose (closed, say) before
    clicking, move the timeline forward, pose it again (open), click
    again - two keyframes is enough for a working open/close animation.
    """
    bl_idname = "pbd.insert_animation_keyframe"
    bl_label = "Insert PBD Animation Keyframe"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.object
        if obj is None:
            self.report({'ERROR'}, "No active object")
            return {'CANCELLED'}
        obj.keyframe_insert(data_path="rotation_euler", frame=context.scene.frame_current)
        self.report({'INFO'}, f"Keyframed rotation at frame {context.scene.frame_current}")
        return {'FINISHED'}


class OBJECT_OT_pbd_export_compiled(bpy.types.Operator):
    """Exports to a .pbdbin or .pbdasset file YOU choose - internally,
    the current scene goes to a temp .pbd first (not something you asked
    to keep), then pbd.PbdConvertMain (shelled out to, since these two
    formats are implemented in Java - PbdBinFormat/PbdAssetFormat, not
    duplicated in Python here) converts it. The Gradle project root
    needed to run PbdConvertMain is found by walking up from wherever
    you choose to save, looking for build.gradle.kts - save inside the
    actual project for this to find it, same as Export and Visualize."""
    bl_idname = "pbd.export_compiled"
    bl_label = "Export Compiled Format"
    bl_options = {'REGISTER'}

    filepath: bpy.props.StringProperty(subtype='FILE_PATH')
    mode: bpy.props.EnumProperty(
        items=[('bin', "PBDBIN (.pbdbin)", "Gzip-compressed minified .pbd - smaller, faster to load, not for hand-editing"),
               ('asset', "PBDASSET (.pbdasset)", "Self-contained zip bundle with materials/textures - one file to hand someone instead of several linked ones")],
        default='bin',
    )

    def invoke(self, context, event):
        ext = ".pbdbin" if self.mode == 'bin' else ".pbdasset"
        if not self.filepath:
            base = os.path.splitext(os.path.basename(bpy.data.filepath))[0] if bpy.data.filepath else "scene"
            self.filepath = base + ext
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def check(self, context):
        """Called by Blender automatically whenever a property changes
        while the file browser (or its redo panel) is open - keeps
        filepath's extension matching mode even if the user typed one
        without an extension, typed the WRONG one, or switched .pbdbin/
        .pbdasset via the redo panel after the browser was already
        showing a path picked under the other mode. Returns whether it
        changed anything, which is Blender's own convention here (used
        to decide whether to redraw), not just a side-effecting void."""
        ext = ".pbdbin" if self.mode == 'bin' else ".pbdasset"
        base, current_ext = os.path.splitext(self.filepath)
        if current_ext.lower() != ext:
            self.filepath = base + ext
            return True
        return False

    def execute(self, context):
        # Wraps the WHOLE body, not just the subprocess call below (which
        # already had its own try/except) - export_scene_to_pbd and
        # _get_runtime_classpath could both throw for reasons this
        # add-on's Linux-only testing never exercised (a Windows path
        # quirk, a permissions error, something scene-specific in
        # export). Better a reported error with the real exception text
        # than an unhandled traceback the user has no clear next step
        # from.
        try:
            return self._execute_impl(context)
        except Exception as e:
            import traceback
            traceback.print_exc()
            self.report({'ERROR'}, f"{self.mode} export failed: {type(e).__name__}: {e} "
                                    f"(full traceback in System Console)")
            return {'CANCELLED'}

    def _execute_impl(self, context):
        from .operators import export_pbd
        output_path = self.filepath
        root = export_pbd._find_gradle_root_with_blend_fallback(output_path)
        if root is None:
            self.report({'ERROR'}, f"No build.gradle.kts found above {output_path} - "
                                    f"save somewhere inside the actual Gradle project")
            return {'CANCELLED'}

        import tempfile
        tmp_pbd = os.path.join(tempfile.mkdtemp(prefix="pbd_export_"), "scene.pbd")
        count, warnings, kf = export_pbd.export_scene_to_pbd(context, tmp_pbd)
        for w in warnings:
            self.report({'WARNING'}, w)

        try:
            classpath = _get_runtime_classpath(root)
        except RuntimeError as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}

        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        try:
            import subprocess
            result = subprocess.run(
                ["java", "-cp", classpath, "pbd.PbdConvertMain", self.mode, tmp_pbd, output_path],
                cwd=root, capture_output=True, text=True, timeout=30,
            )
            for line in result.stdout.splitlines():
                self.report({'INFO'}, line)
            if result.returncode != 0:
                self.report({'ERROR'}, f"PbdConvertMain failed: {result.stderr[-300:]}")
                return {'CANCELLED'}
        except (OSError, subprocess.SubprocessError) as e:
            self.report({'ERROR'}, f"Failed to run PbdConvertMain: {e}")
            return {'CANCELLED'}

        # .pbdbin (unlike .pbdasset, which bundles everything into its
        # own zip - see PbdConvertMain's asset branch) is NOT a bundle:
        # PbdSerializer re-emits the scene's own include_material=
        # UNCHANGED, still a path relative to wherever the .pbdbin ends
        # up living. tmp_pbd's materials were written next to IT, in a
        # temp directory that's about to become meaningless - without
        # copying them over too, that reference points at a file that
        # will never exist next to the actual output. This was a real,
        # reproduced bug (not a guess): "include_material could not
        # read '...\\scene.pbdmat'" - the .pbdbin loaded fine, only the
        # materials file was missing from the temp directory it was
        # never copied out of. Every sibling of tmp_pbd (its .pbdmat and
        # whatever textures got embedded alongside it) gets copied next
        # to output_path now, for .pbdbin specifically.
        if self.mode == 'bin':
            import shutil
            tmp_dir = os.path.dirname(tmp_pbd)
            out_dir = os.path.dirname(output_path)
            copied = []
            for fname in os.listdir(tmp_dir):
                if fname == os.path.basename(tmp_pbd):
                    continue  # the intermediate .pbd itself - not wanted next to the .pbdbin
                shutil.copy2(os.path.join(tmp_dir, fname), os.path.join(out_dir, fname))
                copied.append(fname)
            if copied:
                self.report({'INFO'}, f"Copied alongside {output_path}: {', '.join(copied)}")

        self.report({'INFO'}, f"Wrote {output_path}")
        return {'FINISHED'}


def _get_runtime_classpath(root):
    """The FULL runtime classpath (project's own compiled classes AND
    every dependency jar - JOML, LWJGL) via Gradle's own dependency
    resolution, by running the printRuntimeClasspath task added to
    build.gradle.kts for exactly this purpose - not by guessing at
    Gradle's build/ output layout by hand.

    Replaces two near-identical functions (_find_build_output_path here
    and OBJECT_OT_pbd_export_to_tilegeometry's own _find_build_output)
    that both only ever found the build/classes/java/main directory or a
    packaged jar - the PROJECT's own classes, correct as far as it went,
    but missing every dependency jar entirely. Ran fine for a main()
    that happens to touch nothing but java.*; threw
    ClassNotFoundException/NoClassDefFoundError on org.joml.Vector3fc
    the moment anything reachable from PbdConvertMain's main() touched
    an actual dependency - which, for a class that serializes 3D
    transforms, is essentially always. Confirmed via a real Blender
    error report, not suspected from code reading alone.

    Raises RuntimeError with a message suitable for self.report() on any
    failure (gradlew missing, task failed, timeout) - callers don't need
    their own try/except around this specifically, just around whatever
    they do with the result alongside their other failure modes.
    """
    gradlew = os.path.join(root, "gradlew.bat" if os.name == "nt" else "gradlew")
    if not os.path.isfile(gradlew):
        raise RuntimeError(f"No gradlew found at {gradlew} - is Project Root pointing at "
                            f"the folder containing build.gradle.kts?")
    if os.name != "nt":
        try:
            os.chmod(gradlew, os.stat(gradlew).st_mode | 0o111)  # +x - a fresh checkout/zip extraction often loses this bit, Windows has no equivalent to lose
        except OSError:
            pass  # best-effort - if this fails, the subprocess call below will surface a clear enough permission error on its own
    import subprocess
    try:
        result = subprocess.run(
            [gradlew, "printRuntimeClasspath", "-q"],
            cwd=root, capture_output=True, text=True, timeout=120,
        )
    except subprocess.TimeoutExpired:
        raise RuntimeError("gradlew printRuntimeClasspath timed out after 120s - "
                            "try running it by hand once from a terminal to see what it's doing")
    except OSError as e:
        raise RuntimeError(f"Could not run {gradlew}: {e}")
    if result.returncode != 0:
        raise RuntimeError(f"gradlew printRuntimeClasspath failed:\n{result.stderr[-500:]}")
    marker_start, marker_end = "PBD_CLASSPATH_START", "PBD_CLASSPATH_END"
    if marker_start not in result.stdout:
        raise RuntimeError(f"printRuntimeClasspath produced no classpath - is build.gradle.kts "
                            f"up to date with this add-on's version? Output:\n{result.stdout[-500:]}")
    classpath = result.stdout.split(marker_start, 1)[1].split(marker_end, 1)[0]
    return classpath


class OBJECT_OT_pbd_export_to_tilegeometry(bpy.types.Operator):
    """Runs PbdToTileGeometryMain to add the current scene as a new tile
    in a tileGeometry.txt YOU point at (existing file to append to, or a
    new path to create one) - the Gradle project root needed to run the
    tool is found by walking up from that chosen path, same as the other
    compiled-format buttons."""
    bl_idname = "pbd.export_to_tilegeometry"
    bl_label = "Add to tileGeometry.txt"
    bl_options = {'REGISTER'}

    filepath: bpy.props.StringProperty(subtype='FILE_PATH')
    filename_ext = ".txt"
    filter_glob: bpy.props.StringProperty(default="tileGeometry.txt;*.txt", options={'HIDDEN'})
    tileset_name: bpy.props.StringProperty(
        name="Tileset Name",
        default="custom_assets",
        description="Which tileset in tileGeometry.txt this becomes a new tile of - created if it doesn't exist yet",
    )

    def invoke(self, context, event):
        if not self.filepath:
            self.filepath = "tileGeometry.txt"
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        # Wraps the whole body for the same reason export_compiled's does
        # - a subprocess-invoking operator has more ways to fail than
        # just "the subprocess itself returned nonzero".
        try:
            return self._execute_impl(context)
        except Exception as e:
            import traceback
            traceback.print_exc()
            self.report({'ERROR'}, f"tileGeometry export failed: {type(e).__name__}: {e} "
                                    f"(full traceback in System Console)")
            return {'CANCELLED'}

    def _execute_impl(self, context):
        from .operators import export_pbd
        tile_geometry_path = self.filepath
        root = export_pbd._find_gradle_root_with_blend_fallback(tile_geometry_path)
        if root is None:
            self.report({'ERROR'}, f"No build.gradle.kts found above {tile_geometry_path} - "
                                    f"point this at a tileGeometry.txt inside the actual Gradle project")
            return {'CANCELLED'}

        import tempfile
        tmp_pbd = os.path.join(tempfile.mkdtemp(prefix="pbd_export_"), "scene.pbd")
        count, warnings, kf = export_pbd.export_scene_to_pbd(context, tmp_pbd)
        for w in warnings:
            self.report({'WARNING'}, w)

        try:
            classpath = _get_runtime_classpath(root)
        except RuntimeError as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}

        try:
            import subprocess
            result = subprocess.run(
                ["java", "-cp", classpath, "pbd.pz.PbdToTileGeometryMain", tmp_pbd, tile_geometry_path, self.tileset_name],
                cwd=root, capture_output=True, text=True, timeout=30,
            )
            for line in result.stdout.splitlines():
                self.report({'INFO'}, line)
            if result.returncode != 0:
                self.report({'ERROR'}, f"PbdToTileGeometryMain failed: {result.stderr[-300:]}")
                return {'CANCELLED'}
        except (OSError, subprocess.SubprocessError) as e:
            self.report({'ERROR'}, f"Failed to run PbdToTileGeometryMain: {e}")
            return {'CANCELLED'}

        self.report({'INFO'}, f"Added to {tile_geometry_path}")

        return {'FINISHED'}


class OBJECT_OT_pbd_add_bounding_box(bpy.types.Operator):
    """Adds a new metadata (invisible) cube matching the active object's
    exact world-space bounding box - the "add a bounding-box" macro:
    useful for marking an FBX-derived object's hitbox before bin-packing,
    or any other case where the storage-space/collision volume should
    exactly track an existing object's real extent rather than being
    positioned by hand and eyeballed."""
    bl_idname = "pbd.add_bounding_box"
    bl_label = "Add Bounding Box (metadata)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.object
        if obj is None:
            self.report({'ERROR'}, "No active object")
            return {'CANCELLED'}

        # bound_box is 8 local-space corners; each needs the object's own
        # matrix_world applied to get the true world-space extent this
        # box should cover - not just obj.location +/- obj.dimensions/2,
        # which would be wrong for a rotated object.
        world_corners = [obj.matrix_world @ mathutils.Vector(c) for c in obj.bound_box]
        xs = [c.x for c in world_corners]
        ys = [c.y for c in world_corners]
        zs = [c.z for c in world_corners]
        center = ((min(xs) + max(xs)) / 2, (min(ys) + max(ys)) / 2, (min(zs) + max(zs)) / 2)
        size = (max(xs) - min(xs), max(ys) - min(ys), max(zs) - min(zs))

        bpy.ops.object.add_pbd_primitive(prim_type='cube')
        box_obj = context.active_object
        box_obj.name = obj.name + "_hitbox"
        box_obj.location = center
        # Native cube dimensions are 2 units (see add_primitive.py) - scale
        # to match size exactly, same convention pbd_dim_x/y/z already use.
        box_obj.scale = (size[0] / 2, size[1] / 2, size[2] / 2)
        box_obj.pbd.pbd_metadata = True

        self.report({'INFO'}, f"Added {box_obj.name}: {size[0]:.3f} x {size[1]:.3f} x {size[2]:.3f}")
        return {'FINISHED'}


class OBJECT_OT_pbd_quick_export_and_visualize(bpy.types.Operator):
    """Exports to a .pbd file YOU choose, then launches the Java engine
    viewer on it via `gradlew run --args=<path>` - found by walking up
    from wherever you save looking for build.gradle.kts (see
    _find_gradle_root_from), not from a separately-configured project
    root setting. Save inside the actual Gradle project (anywhere under
    it) for this to find it. The viewer is a separate, long-running
    window, not something to wait on here."""
    bl_idname = "pbd.quick_export_and_visualize"
    bl_label = "Export and Visualize"
    bl_options = {'REGISTER'}

    filepath: bpy.props.StringProperty(subtype='FILE_PATH')
    filename_ext = ".pbd"
    filter_glob: bpy.props.StringProperty(default="*.pbd", options={'HIDDEN'})

    def invoke(self, context, event):
        if not self.filepath:
            self.filepath = (os.path.splitext(os.path.basename(bpy.data.filepath))[0] + ".pbd") \
                if bpy.data.filepath else "scene.pbd"
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        from .operators import export_pbd
        root = export_pbd._find_gradle_root_with_blend_fallback(self.filepath)
        if root is None:
            self.report({'ERROR'}, f"No build.gradle.kts found above {self.filepath} - "
                                    f"save somewhere inside the actual Gradle project")
            return {'CANCELLED'}

        os.makedirs(os.path.dirname(self.filepath), exist_ok=True)
        count, warnings, kf = export_pbd.export_scene_to_pbd(context, self.filepath)
        for w in warnings:
            self.report({'WARNING'}, w)

        gradlew = os.path.join(root, "gradlew.bat" if os.name == "nt" else "gradlew")
        if os.name != "nt":
            try:
                os.chmod(gradlew, os.stat(gradlew).st_mode | 0o111)
            except OSError:
                pass
        try:
            import subprocess
            subprocess.Popen([gradlew, "run", f"--args={self.filepath}"], cwd=root)
        except OSError as e:
            self.report({'ERROR'}, f"Failed to launch viewer: {e}")
            return {'CANCELLED'}

        self.report({'INFO'}, f"Exported {count} instance(s), launching viewer...")
        return {'FINISHED'}


class PBD_UL_materials(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        row.prop(item, "color", text="")
        row.prop(item, "name", text="", emboss=False)


class PBD_UL_linked_doors(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        if item.door:
            row.label(text=item.door.name, icon='OBJECT_DATA')
        else:
            row.label(text="(no object set)", icon='ERROR')


def _storage_cubes_controlled_by(door_obj, scene):
    """Every object in the scene whose pbd_linked_doors list contains
    door_obj - a read-only view computed by scanning the scene, not a
    second parallel list: each storage cube's own pbd_linked_doors stays
    the only real source of truth, so this can never drift out of sync
    with it."""
    result = []
    for o in bpy.data.objects:
        if not (o.pbd.is_pbd_primitive and o.pbd.pbd_metadata):
            continue
        if any(entry.door == door_obj for entry in o.pbd.pbd_linked_doors):
            result.append(o)
    return result


class OBJECT_OT_pbd_add_linked_door(bpy.types.Operator):
    """Adds one empty door-link slot to the active storage cube's list -
    the same +/- pattern as this addon's own material list, or Blender's
    native modifier/particle lists: press +, then pick the object in the
    field that appears, no specific selection order to remember."""
    bl_idname = "pbd.add_linked_door"
    bl_label = "Add Door"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.object
        if obj is None or not obj.pbd.pbd_metadata:
            self.report({'ERROR'}, "Select a Metadata-Only storage cube first")
            return {'CANCELLED'}
        obj.pbd.pbd_linked_doors.add()
        obj.pbd.pbd_linked_doors_active_index = len(obj.pbd.pbd_linked_doors) - 1
        return {'FINISHED'}


class OBJECT_OT_pbd_remove_linked_door(bpy.types.Operator):
    """Removes the currently-active row from the storage cube's door list."""
    bl_idname = "pbd.remove_linked_door"
    bl_label = "Remove Door"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.object
        if obj is None:
            return {'CANCELLED'}
        index = obj.pbd.pbd_linked_doors_active_index
        if 0 <= index < len(obj.pbd.pbd_linked_doors):
            obj.pbd.pbd_linked_doors.remove(index)
            obj.pbd.pbd_linked_doors_active_index = max(0, index - 1)
        return {'FINISHED'}


class PBD_UL_mesh_lod(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        row.label(text=f"LOD {item.lod}:")
        if item.mesh_data:
            row.label(text=f"{len(item.mesh_data.vertices)} verts", icon='MESH_DATA')
        else:
            row.label(text="(empty - use Capture below)", icon='ERROR')


class OBJECT_OT_pbd_add_mesh_lod(bpy.types.Operator):
    """Adds one empty LOD-variant slot to the active mesh primitive's
    list - pick the source object and tier in the fields that appear,
    same +/- pattern as the door-link list."""
    bl_idname = "pbd.add_mesh_lod"
    bl_label = "Add LOD Variant"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.object
        if obj is None or obj.pbd.pbd_type != 'mesh':
            self.report({'ERROR'}, "Select a 'mesh'-type primitive first")
            return {'CANCELLED'}
        entry = obj.pbd.pbd_mesh_lod_sources.add()
        # Next unused tier, not always 1 - if 1 exists already, default
        # to 2, and so on, so adding several in a row doesn't require
        # correcting the tier number each time.
        used = {e.lod for e in obj.pbd.pbd_mesh_lod_sources}
        n = 1
        while n in used and n != entry.lod:
            n += 1
        entry.lod = n
        obj.pbd.pbd_mesh_lod_active_index = len(obj.pbd.pbd_mesh_lod_sources) - 1
        return {'FINISHED'}


class OBJECT_OT_pbd_remove_mesh_lod(bpy.types.Operator):
    """Removes the currently-active row from the mesh's LOD-variant list."""
    bl_idname = "pbd.remove_mesh_lod"
    bl_label = "Remove LOD Variant"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.object
        if obj is None:
            return {'CANCELLED'}
        index = obj.pbd.pbd_mesh_lod_active_index
        if 0 <= index < len(obj.pbd.pbd_mesh_lod_sources):
            obj.pbd.pbd_mesh_lod_sources.remove(index)
            obj.pbd.pbd_mesh_lod_active_index = max(0, index - 1)
        return {'FINISHED'}


class OBJECT_OT_pbd_capture_mesh_lod(bpy.types.Operator):
    """Saves the active object's CURRENT geometry into the active LOD
    row's slot, replacing whatever was there - a copy, not a link, so
    editing the object further afterward doesn't change what got
    captured. Build the low-detail shape (or any other variant) on the
    SAME object, one at a time, capturing each before moving on to the
    next - never two shapes visible in the scene at once."""
    bl_idname = "pbd.capture_mesh_lod"
    bl_label = "Capture Current Shape"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.object
        if obj is None or obj.pbd.pbd_type != 'mesh':
            self.report({'ERROR'}, "Select a 'mesh'-type primitive first")
            return {'CANCELLED'}
        index = obj.pbd.pbd_mesh_lod_active_index
        if not (0 <= index < len(obj.pbd.pbd_mesh_lod_sources)):
            self.report({'ERROR'}, "Add an LOD row first (the + button above)")
            return {'CANCELLED'}
        entry = obj.pbd.pbd_mesh_lod_sources[index]
        old = entry.mesh_data
        entry.mesh_data = obj.data.copy()  # a real copy - obj.data itself stays this object's own live, editable mesh
        entry.mesh_data.use_fake_user = True  # keeps it alive with zero Object users, which is the point - never linked to one
        if old is not None and old.users == 0:
            bpy.data.meshes.remove(old)  # the row's PREVIOUS capture, now replaced - not left as an orphan
        self.report({'INFO'}, f"Captured {len(entry.mesh_data.vertices)} vertices as LOD {entry.lod}")
        return {'FINISHED'}


class OBJECT_OT_pbd_apply_mesh_lod(bpy.types.Operator):
    """Replaces the active object's CURRENT geometry with whatever is
    stored in the active LOD row - the object visibly TRANSFORMS into
    that saved shape right in the viewport, in place, rather than
    needing a second object to switch visibility on. The shape this
    REPLACES is gone unless it was itself captured into some other LOD
    row first - there is no undo for what obj.data held a moment ago
    beyond Blender's own Ctrl+Z."""
    bl_idname = "pbd.apply_mesh_lod"
    bl_label = "Apply This Shape"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.object
        if obj is None or obj.pbd.pbd_type != 'mesh':
            self.report({'ERROR'}, "Select a 'mesh'-type primitive first")
            return {'CANCELLED'}
        index = obj.pbd.pbd_mesh_lod_active_index
        if not (0 <= index < len(obj.pbd.pbd_mesh_lod_sources)):
            self.report({'ERROR'}, "Select an LOD row first")
            return {'CANCELLED'}
        entry = obj.pbd.pbd_mesh_lod_sources[index]
        if entry.mesh_data is None:
            self.report({'ERROR'}, "This LOD row is empty - use Capture Current Shape on it first (on whichever object currently has the shape you want here)")
            return {'CANCELLED'}
        old_data = obj.data
        obj.data = entry.mesh_data.copy()  # a copy applied TO the object - entry.mesh_data itself stays untouched, so Apply can be used again later without needing to re-Capture
        if old_data.users == 0:
            bpy.data.meshes.remove(old_data)
        self.report({'INFO'}, f"Applied LOD {entry.lod}'s shape ({len(obj.data.vertices)} vertices)")
        return {'FINISHED'}


class OBJECT_OT_pbd_fix_to_animated(bpy.types.Operator):
    """Glues the other selected object(s) to the active one so they
    follow its animation - select the static piece(s) first, shift-
    select the animated object LAST (making it active), then run this.
    Uses Blender's own native parenting (bpy.ops.object.parent_set),
    the same convention as Ctrl+P, not a new one invented for this addon:
    the active object becomes the parent, exactly like Blender's own
    keep-transform parenting already works everywhere else."""
    bl_idname = "pbd.fix_to_animated"
    bl_label = "Fix to Animated Object"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        target = context.object
        if target is None:
            self.report({'ERROR'}, "No active object - select the static piece(s), then shift-select the animated one last")
            return {'CANCELLED'}
        if target.animation_data is None or target.animation_data.action is None:
            self.report({'WARNING'}, f"'{target.name}' has no animation - gluing to it won't move anything")
        others = [o for o in context.selected_objects if o != target]
        if not others:
            self.report({'ERROR'}, "Select at least one other object to glue, in addition to the animated target")
            return {'CANCELLED'}
        bpy.ops.object.parent_set(type='OBJECT', keep_transform=True)
        self.report({'INFO'}, f"Glued {len(others)} object(s) to follow '{target.name}'")
        return {'FINISHED'}


class OBJECT_OT_pbd_mirror_face_position(bpy.types.Operator):
    """Mirrors this object's position across the origin on the chosen
    axis - literally just obj.location.axis = -obj.location.axis,
    matching Blender's own intuitive sense of "mirror" (flip the sign),
    nothing smarter. pbd_face_min/max are live-computed FROM location
    already (see _make_face_getset), so they correctly reflect the
    mirrored position on their own next redraw without needing to be
    touched here directly.

    The previous version tried to be clever: read the current face
    min/max, swap and negate them, and write them back through the same
    get/set properties. That chains two dependent operations which each
    re-read obj.dimensions - and dimensions does not reliably update
    synchronously between two property writes in the same Python call,
    so the second write's "other face stays fixed" math was computed
    against a stale dimensions value from before the first write took
    effect. Confirmed empirically: a cube at location.x=2.5 (dimension
    2, so min=1.5/max=3.5) mirrored to location.x=-1.25 with dimension
    9 instead of location.x=-2.5 with dimension unchanged - a real,
    severe, every-time bug, not an edge case. This version's single
    direct assignment has no such interaction to go wrong."""
    bl_idname = "pbd.mirror_face_position"
    bl_label = "Mirror Position"
    bl_options = {'REGISTER', 'UNDO'}

    axis: bpy.props.EnumProperty(
        items=[('x', "X", ""), ('y', "Y", ""), ('z', "Z", "")],
        default='x',
    )

    def execute(self, context):
        obj = context.object
        if obj is None:
            self.report({'ERROR'}, "No active object")
            return {'CANCELLED'}
        current = getattr(obj.location, self.axis)
        setattr(obj.location, self.axis, -current)
        self.report({'INFO'}, f"Mirrored position on {self.axis.upper()} axis "
                               f"({current:.4g} -> {-current:.4g})")
        return {'FINISHED'}


class OBJECT_OT_pbd_start_texture_painting(bpy.types.Operator):
    """Sets this object up for texture painting and switches to
    Blender's own Texture Paint mode - a 3D artist gets Blender's full,
    familiar toolset (brushes, color picker, symmetry, all of it), not a
    limited custom painter built for this addon. This operator's whole
    job is just the setup: making sure there's a UV map (refreshing it
    if needed) and a paintable image assigned to a material, so pressing
    it hands the artist a ready canvas instead of Blender's own "no
    active image" error."""
    bl_idname = "pbd.start_texture_painting"
    bl_label = "Start Texture Painting"
    bl_options = {'REGISTER', 'UNDO'}

    image_size: bpy.props.IntProperty(name="New Image Size", default=1024, min=64, max=8192)

    def execute(self, context):
        obj = context.object
        if obj is None or obj.type != 'MESH':
            self.report({'ERROR'}, "Select a mesh object first")
            return {'CANCELLED'}

        if not obj.data.uv_layers:
            from .operators.add_primitive import refresh_pbd_uv_mapping
            refresh_pbd_uv_mapping(obj)

        mat_name = obj.pbd.pbd_material or obj.name
        material = bpy.data.materials.get(mat_name)
        if material is None:
            material = bpy.data.materials.new(mat_name)
        material.use_nodes = True

        image_name = f"{mat_name}_diffuse"
        image = bpy.data.images.get(image_name)
        if image is None:
            image = bpy.data.images.new(image_name, width=self.image_size, height=self.image_size, alpha=False)
            image.generated_color = (0.6, 0.6, 0.6, 1.0)  # neutral grey canvas, not Blender's default checker/black - closer to a blank material to paint onto

        nodes = material.node_tree.nodes
        image_node = nodes.get("PBD_PaintTarget")
        if image_node is None:
            image_node = nodes.new("ShaderNodeTexImage")
            image_node.name = "PBD_PaintTarget"
        image_node.image = image

        bsdf = nodes.get("Principled BSDF")
        if bsdf is not None:
            material.node_tree.links.new(image_node.outputs["Color"], bsdf.inputs["Base Color"])

        if obj.data.materials:
            obj.data.materials[0] = material
        else:
            obj.data.materials.append(material)

        # Also drives which image Blender's Texture Paint mode targets
        # by default (Image Editor / active paint slot) - without this,
        # entering Texture Paint mode can leave "no image" active even
        # though one exists on the material.
        context.scene.tool_settings.image_paint.canvas = image

        bpy.ops.object.mode_set(mode='TEXTURE_PAINT')

        # Switch to Blender's own Texture Paint workspace if the current
        # file has one (it does by default in a stock Blender install) -
        # this is what actually surfaces the familiar brush/color panels
        # without the artist needing to know to look for them.
        workspace = bpy.data.workspaces.get("Texture Paint")
        if workspace is not None:
            context.window.workspace = workspace

        self.report({'INFO'}, f"Painting '{image_name}' on '{mat_name}' - Blender's Texture Paint tools are ready")
        return {'FINISHED'}


class OBJECT_OT_pbd_convert_to_mesh(bpy.types.Operator):
    """Tags the active object as a PBD 'mesh' primitive - unlike every
    other type here, which is a canonical procedural shape evaluated by
    the engine's shader, 'mesh' embeds THIS object's own current
    triangulated geometry directly (see PbdMeshData / export_pbd.py's
    _export_mesh_vertex_data), for content that doesn't fit the
    procedural model (an imported prop, a hand-sculpted shape). Works on
    any existing mesh object - it doesn't need to have been created via
    Add PBD Primitive first."""
    bl_idname = "object.pbd_convert_to_mesh"
    bl_label = "Convert to PBD Mesh"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.object
        if obj is None or obj.type != 'MESH':
            self.report({'ERROR'}, "Select a mesh object first")
            return {'CANCELLED'}
        if len(obj.data.vertices) == 0:
            self.report({'ERROR'}, "Object has no geometry")
            return {'CANCELLED'}
        obj.pbd.is_pbd_primitive = True
        obj.pbd.pbd_type = 'mesh'
        self.report({'INFO'}, f"'{obj.name}' will export its own {len(obj.data.vertices)}-vertex "
                               f"mesh as PBD 'mesh' data")
        return {'FINISHED'}


class OBJECT_OT_pbd_test_reference(bpy.types.Operator):
    """Actually tries to resolve the active object's pbd_ref source right
    now, from inside Blender - a local path is checked for existence, a
    URL is fetched for real via fetcher.py (with the fallback URL and
    caching PbdFetcher.java itself uses, so this also pre-warms the exact
    cache the engine will read from). Reports success/failure clearly
    rather than leaving "does this even work" as a question you only find
    out by launching the engine."""
    bl_idname = "pbd.test_reference"
    bl_label = "Test Reference"
    bl_options = {'REGISTER'}

    def execute(self, context):
        obj = context.object
        if obj is None or obj.pbd.pbd_type != 'ref':
            self.report({'ERROR'}, "Select a PBD Reference object first")
            return {'CANCELLED'}
        source = obj.pbd.pbd_ref_source.strip()
        if not source:
            self.report({'ERROR'}, "Source is empty")
            return {'CANCELLED'}

        if source.lower().startswith(('http://', 'https://')):
            from . import fetcher
            cache_dir = _remote_cache_dir(context)
            try:
                path = fetcher.fetch(source, cache_dir, obj.pbd.pbd_ref_fallback.strip() or None, use_cache=False)
                size = os.path.getsize(path)
                self.report({'INFO'}, f"Fetched OK ({size} bytes) -> cached at {path}")
                return {'FINISHED'}
            except fetcher.FetchError as e:
                self.report({'ERROR'}, f"Fetch failed: {e}")
                return {'CANCELLED'}
        else:
            candidate = bpy.path.abspath(source) if source.startswith('//') else source
            if os.path.isfile(candidate):
                self.report({'INFO'}, f"Found local file: {candidate}")
                return {'FINISHED'}
            self.report({'ERROR'}, f"Local file not found: {candidate} "
                                    f"(the engine resolves a relative source= relative to wherever "
                                    f"the .pbd doing the referencing actually gets exported - use an "
                                    f"absolute path here to test independently of that)")
            return {'CANCELLED'}


def _remote_cache_dir(context):
    """Same cache/remote layout PbdPaths.REMOTE_CACHE_DIR uses on the Java
    side, so a fetch tested here and a fetch done by the engine share one
    cache instead of each keeping their own separate copy. Anchored to
    this .blend file's own directory now (bpy.path.abspath("//")) rather
    than a separately-configured project root - falls back to a temp
    directory if the file has never been saved, so Test Reference still
    works before a first save."""
    base = bpy.path.abspath("//")
    if not base:
        import tempfile
        base = tempfile.gettempdir()
    return os.path.join(base, "pbd_cache", "remote")


class OBJECT_OT_pbd_refresh_uv(bpy.types.Operator):
    """Re-projects this object's UVs sized to its current world
    dimensions (see add_primitive.py's refresh_pbd_uv_mapping) - run this
    after resizing an object, since a dimension change doesn't
    automatically re-run the projection that happened at creation time."""
    bl_idname = "pbd.refresh_uv"
    bl_label = "Refresh UV Mapping"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.object
        if obj is None or obj.type != 'MESH':
            self.report({'ERROR'}, "Select a mesh object first")
            return {'CANCELLED'}
        from .operators.add_primitive import refresh_pbd_uv_mapping
        refresh_pbd_uv_mapping(obj)
        self.report({'INFO'}, f"Refreshed UV mapping on '{obj.name}'")
        return {'FINISHED'}


class OBJECT_PT_pbd_primitive(bpy.types.Panel):
    """Properties-editor panel - unchanged location, kept for anyone used to finding it there."""

    bl_label = "PBD"
    bl_idname = "OBJECT_PT_pbd_primitive"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "object"

    def draw(self, context):
        obj = context.object
        if obj is None:
            return
        draw_pbd_properties_safe(self.layout, obj, context.scene)


class VIEW3D_PT_pbd_tools(bpy.types.Panel):
    """3D-viewport sidebar panel (press N, "PBD" tab): one click to create
    an already-tagged primitive instead of adding a mesh and then finding
    the checkbox in Properties, plus the selected object's PBD settings
    right there so switching editors is rarely needed."""

    bl_label = "PBD Tools"
    bl_idname = "VIEW3D_PT_pbd_tools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "PBD"

    def draw(self, context):
        layout = self.layout
        layout.label(text="PBD Tools v0.34.0", icon='INFO')

        # File-level metadata (PbdScene.java's own name/kind/authors/
        # origin - describing the FILE as a whole) - shown once here,
        # not per-object, since it isn't a per-object thing. Previously
        # had no UI at all despite the parser/serializer supporting it
        # the whole time.
        meta_box = layout.box()
        meta_box.label(text="File metadata:", icon='FILE_TEXT')
        meta_box.prop(context.scene, "pbd_scene_name")
        meta_box.prop(context.scene, "pbd_scene_kind")
        meta_box.prop(context.scene, "pbd_scene_authors")
        meta_box.prop(context.scene, "pbd_scene_origin")

        box = layout.box()
        # operator_context set once here for the WHOLE box: a plain
        # layout.operator() call from a panel defaults to EXEC_DEFAULT,
        # which calls execute() directly and skips invoke() entirely -
        # meaning EVERY file-browser button below (Export, Export &
        # Visualize, Import, tileGeometry, .pbdbin/.pbdasset) would
        # either silently operate on an empty/stale filepath or (for
        # Import specifically) skip the File-vs-URL choice dialog
        # outright, while the SAME operators invoked via File > Import/
        # Export (which Blender's own menu registration invokes with
        # INVOKE_DEFAULT) would behave correctly - exactly the
        # inconsistency reported ("the panel behaves differently from
        # File > Import"). Confirmed by reasoning through Blender's own
        # default operator_context, not by assumption alone: every
        # operator below defines invoke() specifically to open a file
        # browser or dialog, so skipping it can't be intentional here.
        box.operator_context = 'INVOKE_DEFAULT'
        # Every button below opens its own file browser now (no more
        # persistent Project Root setting to point at the wrong folder -
        # see _find_gradle_root_from) - so nothing here needs to be
        # disabled ahead of time the way it used to be; an operator that
        # can't find build.gradle.kts above wherever you chose to save
        # reports that clearly once you've actually picked a location,
        # which is the only point such a check could be accurate anyway.
        row = box.row(align=True)
        row.operator("export_scene.pbd", text="Export", icon='EXPORT')
        row.operator("pbd.quick_export_and_visualize", text="Export & Visualize", icon='PLAY')
        box.prop(context.scene, "pbd_export_minify", text="Minify exported .pbd text", icon='FILE_TEXT')
        box.operator("import_scene.pbd", text="Import", icon='IMPORT')
        box.operator("pbd.export_to_tilegeometry", text="Add to tileGeometry.txt", icon='FILE_TEXT')
        row2 = box.row(align=True)
        row2.operator("pbd.export_compiled", text=".pbdbin", icon='PACKAGE').mode = 'bin'
        row2.operator("pbd.export_compiled", text=".pbdasset", icon='PACKAGE').mode = 'asset'

        col = layout.column(align=True)
        col.label(text="Create:")
        for prim_type, label in (
            ('plane', "Plane"),
            ('sphere', "Sphere"),
            ('cylinder', "Cylinder"),
            ('cone', "Cone"),
            ('cube', "Cube"),
            ('disc', "Disc"),
            ('torus', "Torus"),
        ):
            op = col.operator("object.add_pbd_primitive", text=label)
            op.prim_type = prim_type
        col.operator("object.add_pbd_ref", text="Reference (pbd_ref)", icon='EMPTY_ARROWS')

        layout.separator()
        mesh_box = layout.box()
        mesh_box.label(text="Arbitrary geometry:", icon='MESH_DATA')
        mesh_box.operator("object.pbd_convert_to_mesh", icon='OUTLINER_OB_MESH')
        mesh_help = mesh_box.column(align=True)
        mesh_help.scale_y = 0.8
        mesh_help.label(text="Select any existing mesh first - embeds")
        mesh_help.label(text="its own geometry as-is, no procedural shape.")

        obj = context.object
        if obj is not None and obj.type in ('MESH', 'EMPTY'):
            layout.separator()
            box = layout.box()
            box.label(text=f"Selected: {obj.name}")
            box.operator("pbd.add_bounding_box", text="Add Bounding Box (metadata)", icon='CUBE')
            box.operator("pbd.fix_to_animated", text="Fix to Animated Object", icon='CONSTRAINT')
            fix_help = box.column(align=True)
            fix_help.scale_y = 0.8
            fix_help.label(text="Select static piece(s), shift-select the")
            fix_help.label(text="animated object last, then click.")
            draw_pbd_properties_safe(box, obj, context.scene)

        layout.separator()
        tip = layout.column(align=True)
        tip.scale_y = 0.8
        tip.label(text="Tip: right-click a Create button")
        tip.label(text="above to assign a keyboard shortcut")
        tip.label(text="(or Preferences > Keymap).")


class OBJECT_OT_pbd_load_pbdmat_by_path(bpy.types.Operator):
    """Loads one specific .pbdmat file, given directly by path - the
    one-click counterpart to pbd.material_load's file browser, used by
    the pbdmat list below. A plain StringProperty (not FILE_PATH
    subtype) on purpose: a FILE_PATH property makes Blender's default
    invoke() pop the file browser even when called from a panel button
    with the path already known, which defeats the point of a one-click
    list entry."""
    bl_idname = "pbd.load_pbdmat_by_path"
    bl_label = "Load This .pbdmat"
    bl_options = {'REGISTER', 'UNDO'}
    filepath: bpy.props.StringProperty()

    def execute(self, context):
        from . import materials as materials_module
        try:
            parsed = materials_module._parse_pbdmat(self.filepath)
        except OSError as e:
            self.report({'ERROR'}, f"Could not read {self.filepath}: {e}")
            return {'CANCELLED'}
        mat_dir = os.path.dirname(self.filepath)
        for name, fields in parsed.items():
            entry = context.scene.pbd_materials.get(name)
            if entry is None:
                entry = context.scene.pbd_materials.add()
                entry.name = name
            if "color" in fields:
                entry.color = fields["color"]
            if "shininess" in fields:
                entry.shininess = fields["shininess"]
            if "specular" in fields:
                entry.specular = fields["specular"]
            if "texture" in fields:
                entry.texture_path = os.path.join(mat_dir, fields["texture"])
            if "normalMap" in fields:
                entry.normal_map_path = os.path.join(mat_dir, fields["normalMap"])
            if "roughnessMap" in fields:
                entry.roughness_map_path = os.path.join(mat_dir, fields["roughnessMap"])
            if "displacementMap" in fields:
                entry.displacement_map_path = os.path.join(mat_dir, fields["displacementMap"])
            if "displacementScale" in fields:
                entry.displacement_scale = fields["displacementScale"]
            if "uvScale" in fields:
                entry.uv_scale = fields["uvScale"]
            if "reflectivity" in fields:
                entry.reflectivity = fields["reflectivity"]
            if "transparency" in fields:
                entry.transparency = fields["transparency"]
        self.report({'INFO'}, f"Loaded {len(parsed)} material(s) from {os.path.basename(self.filepath)}")
        return {'FINISHED'}


def draw_pbdmat_file_list(layout, context):
    """Lists every .pbdmat under the project's shared materials/ folder
    (see _resolve_materials_dir in export_pbd.py for how that folder is
    located) - browsing what already exists there before deciding what
    to load or reference as a SHARED material, rather than needing to
    remember file names or dig through a file browser."""
    layout.prop(context.scene, "pbd_materials_folder")
    from .operators import export_pbd
    materials_dir = export_pbd._resolve_materials_dir(context)
    if not os.path.isdir(materials_dir):
        layout.label(text=f"No materials/ folder found at {materials_dir}", icon='ERROR')
        layout.label(text="(set the folder above, or - if working from a", icon='BLANK1')
        layout.label(text="checkout of this project - leave it empty and use", icon='BLANK1')
        layout.label(text="Load .pbdmat by Path below for anywhere else)", icon='BLANK1')
        return
    files = sorted(f for f in os.listdir(materials_dir) if f.endswith(".pbdmat"))
    if not files:
        layout.label(text="No .pbdmat files found yet.", icon='INFO')
        return
    col = layout.column(align=True)
    for f in files:
        row = col.row(align=True)
        row.label(text=f[:-len(".pbdmat")])
        op = row.operator("pbd.load_pbdmat_by_path", text="", icon='IMPORT')
        op.filepath = os.path.join(materials_dir, f)


class VIEW3D_PT_pbd_materials(bpy.types.Panel):
    """Separate panel (same PBD sidebar tab) so the material catalog isn't
    buried under whichever object happens to be selected - materials are
    scene-wide, not per-object."""

    bl_label = "PBD Materials"
    bl_idname = "VIEW3D_PT_pbd_materials"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "PBD"

    def draw(self, context):
        draw_material_catalog(self.layout, context.scene)
        self.layout.separator()
        box = self.layout.box()
        box.label(text="Available in materials/ folder:")
        draw_pbdmat_file_list(box, context)


CLASSES = (PBD_UL_materials, PBD_UL_linked_doors, PBD_UL_mesh_lod, OBJECT_PT_pbd_primitive, VIEW3D_PT_pbd_tools, VIEW3D_PT_pbd_materials,
           OBJECT_OT_pbd_insert_animation_keyframe, OBJECT_OT_pbd_goto_keyframe, OBJECT_OT_pbd_delete_keyframe,
           OBJECT_OT_pbd_quick_export_and_visualize, OBJECT_OT_pbd_load_pbdmat_by_path,
           OBJECT_OT_pbd_export_to_tilegeometry, OBJECT_OT_pbd_export_compiled, OBJECT_OT_pbd_add_bounding_box,
           OBJECT_OT_pbd_add_linked_door, OBJECT_OT_pbd_remove_linked_door, OBJECT_OT_pbd_refresh_uv,
           OBJECT_OT_pbd_fix_to_animated, OBJECT_OT_pbd_mirror_face_position, OBJECT_OT_pbd_start_texture_painting,
           OBJECT_OT_pbd_test_reference, OBJECT_OT_pbd_convert_to_mesh,
           OBJECT_OT_pbd_add_keyframe_sound, OBJECT_OT_pbd_remove_keyframe_sound,
           OBJECT_OT_pbd_add_mesh_lod, OBJECT_OT_pbd_remove_mesh_lod,
           OBJECT_OT_pbd_capture_mesh_lod, OBJECT_OT_pbd_apply_mesh_lod)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
