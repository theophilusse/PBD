"""One-click doors, drawers, levers and toggleable lights.

The engine opens a thing in one of two ways - keyframes (the Animation box: Insert Keyframe Here) or a lever arm (a pose to
drag the object to, no timeline) - and a light that shares a Link Group with something that opens is ON while that thing is
open (PbdRenderer / LightLinks: a wardrobe lamp, a fridge light, a wall switch). Until now the only way to get there was to tick
"Lever Arm" at the bottom of an object's panel, type or capture an open pose, and type the same Link Group on two objects by
hand. This module is the add-on's front door to all of it, in the manner of Insert Keyframe Here:

  * pbd.add_lever_arm      - on the selected object: a door that swings 90 degrees, a drawer that slides out, or a lever that
                             tilts, worked out from where the object is NOW (that pose is the closed one)
  * pbd.remove_lever_arm   - takes it off again
  * pbd.add_door_light     - on a selected door/drawer/lever: a light, linked to it, that is on while it is open
  * object.add_pbd_door / _drawer / _light_switch - the whole thing ready made (hinge pivot + panel + handle, a drawer, a wall
                             switch with its lamp), each with the motion already set up

Everything here is plain Python over properties the add-on already had (pbd_lever_arm_*, pbd_link_group): no new setting and no
new file-format key, so what these buttons make is exported, imported and read by the engine exactly like what an artist set by
hand. The helpers (set_lever_arm, openers_of, ...) are importable and checked by tools/regression/blender_addon_check.py.
"""

import math

import bpy
import mathutils

from .. import anim_compat

# What the ready-made pieces measure, in metres. A native Blender primitive is 2 m across, so an object's scale is half its size
# (the exporter's x2 turns that back into the engine's size).
DOOR_WIDTH, DOOR_HEIGHT, DOOR_THICKNESS = 0.9, 2.0, 0.04
DRAWER_SIZE = (0.5, 0.4, 0.18)           # width, depth, height of the front box
DRAWER_SLIDE = 0.32                       # how far it comes out
PLATE_SIZE = (0.08, 0.02, 0.12)           # a wall switch's plate
LEVER_TILT_DEG = 25.0                     # the toggle rests tilted down by this much and flips up by as much
LAMP_OFFSET = (0.0, -0.5, 1.4)            # where the switch's lamp starts, from the switch: the user moves it to the ceiling

# What each kind of lever arm does, and the defaults it comes with. (identifier, label, tooltip)
KINDS = (
    ('DOOR', "Door", "Swings 90 degrees about the object's vertical axis, and goes on to the nearest end when let go. The object turns around its OWN origin, so "
                     "for a hinge on the door's edge put the arm on a Pivot placed on the hinge (the Door button under Create does exactly that)"),
    ('DRAWER', "Drawer", "Slides out along the object's own front (its -Y) by four fifths of its depth, and stays wherever the player lets go"),
    ('LEVER', "Lever", "Tilts 60 degrees about the object's own X axis, and goes on to the nearest end when let go - a switch or a lever to pull"),
)
_TOOLTIP = {identifier: tooltip for identifier, _label, tooltip in KINDS}
_DEFAULT_DEG = {'DOOR': 90.0, 'LEVER': 60.0}
_RELEASE = {'DOOR': 'snap', 'DRAWER': 'free', 'LEVER': 'snap'}
_NO_DEPTH_FALLBACK = 0.4                  # a drawer slide for an object with no depth to speak of (a pivot)


# ----------------------------------------------------------------------------- what can open, what is linked

def is_pbd(obj):
    return obj is not None and getattr(obj, "pbd", None) is not None and obj.pbd.is_pbd_primitive


def is_openable(obj):
    """Whether the engine can open it - what makes it switch a light of its Link Group (pbd.render.LightLinks.isDriver): a lever arm or
    keyframes, on something that is neither a light nor a reference (those do not move on their own) and does not loop (a ceiling fan
    turning forever has no open and no shut)."""
    return (is_pbd(obj) and obj.pbd.pbd_type not in ('light', 'ref') and not obj.pbd.pbd_loop_animation
            and (obj.pbd.pbd_lever_arm_enabled or anim_compat.has_keyframes(obj)))


def opener_for(obj):
    """The object that opens when `obj` is clicked in the engine: obj itself, or the nearest parent that can open (a door panel hangs
    on the hinge Pivot that carries the arm), or None."""
    node = obj
    while node is not None:
        if is_openable(node):
            return node
        node = node.parent
    return None


def pbd_objects(scene):
    return [o for o in scene.objects if is_pbd(o)]


def link_groups_in_use(scene):
    return {o.pbd.pbd_link_group for o in pbd_objects(scene) if o.pbd.pbd_link_group}


def fresh_group(scene, base):
    """A Link Group name no object uses yet: `base`, else base_2, base_3..."""
    base = "".join(c if (c.isalnum() or c in "_-") else "_" for c in base) or "group"
    taken = link_groups_in_use(scene)
    if base not in taken:
        return base
    n = 2
    while f"{base}_{n}" in taken:
        n += 1
    return f"{base}_{n}"


def openers_of(scene, group):
    """The objects of Link Group `group` that the engine can open - what switches a light of that group."""
    if not group:
        return []
    return [o for o in pbd_objects(scene) if o.pbd.pbd_link_group == group and is_openable(o)]


def lights_of(scene, group):
    """The PBD lights of Link Group `group`."""
    if not group:
        return []
    return [o for o in pbd_objects(scene) if o.pbd.pbd_type == 'light' and o.pbd.pbd_link_group == group]


def light_link_state(scene, light):
    """How a light stands with its Link Group: ('free', []) it names none, so its own Enabled is all there is; ('orphan', []) it names
    one that nothing opening shares, so its own Enabled stands too; ('linked', openers) the engine switches it with those, on while any is
    open, and ignores its Enabled."""
    group = light.pbd.pbd_link_group
    if not group:
        return 'free', []
    openers = openers_of(scene, group)
    return ('linked', openers) if openers else ('orphan', [])


# ----------------------------------------------------------------------------- the lever arm

def lever_arm_problem(obj):
    """Why obj cannot be given a lever arm now (a sentence), or None."""
    if not is_pbd(obj):
        return "Select a PBD object first"
    if obj.pbd.pbd_type in ('ref', 'light'):
        return (f"A {'reference' if obj.pbd.pbd_type == 'ref' else 'light'} cannot carry a lever arm (it is not exported) - "
                f"put the arm on a Pivot (Create > Pivot) and parent this object to it")
    if anim_compat.has_keyframes(obj):
        return ("This object has keyframes (rotation, location or scale) - the engine would play them and ignore a lever arm. "
                "Delete them first (select the object, hover the 3D view, Alt+I)")
    if obj.pbd.pbd_lever_arm_enabled:
        return "This object already has a lever arm - change it in the Lever Arm box, or Remove it first"
    return None


def set_lever_arm(obj, kind, amount=None):
    """Gives obj a lever arm of `kind` ('DOOR', 'DRAWER' or 'LEVER'), measured from its CURRENT Location and Rotation, which become
    the closed pose. `amount`: degrees for a door or a lever, metres for a drawer (default: 90, 60, four fifths of the object's
    depth). Returns a sentence saying what was set. The caller has checked lever_arm_problem."""
    pbd = obj.pbd
    location = obj.location.copy()
    rotation = obj.rotation_euler.copy()
    turn = mathutils.Euler(rotation, 'XYZ')
    description = ""
    if kind == 'DRAWER':
        if amount is None:
            depth = obj.dimensions.y
            amount = 0.8 * depth if depth > 0.05 else _NO_DEPTH_FALLBACK
        slide = rotation.to_matrix() @ mathutils.Vector((0.0, -amount, 0.0))  # its own front, -Y, in the parent's space
        pbd.pbd_lever_arm_open_pos = location + slide
        pbd.pbd_lever_arm_open_rot = rotation
        description = f"slides out {amount:.2f} m along its front"
    else:
        degrees = _DEFAULT_DEG[kind] if amount is None else amount
        if kind == 'DOOR':
            turn.z += math.radians(degrees)  # Euler XYZ: more Z is a turn about the PARENT's vertical axis
            description = f"swings {degrees:g} degrees"
        else:
            turn.x += math.radians(degrees)  # more X is a turn about the object's OWN X axis
            description = f"tilts {degrees:g} degrees"
        pbd.pbd_lever_arm_open_pos = location
        pbd.pbd_lever_arm_open_rot = turn
    pbd.pbd_lever_arm_release = _RELEASE[kind]
    pbd.pbd_lever_arm_locked = False
    pbd.pbd_lever_arm_enabled = True
    return description


class OBJECT_OT_pbd_add_lever_arm(bpy.types.Operator):
    """Gives the selected object a lever arm, the way Insert Keyframe Here gives it a keyframe: one click, a sensible open
    pose worked out from where the object is now (that pose is the closed one). Change the numbers below, or pose the object
    open by hand and click Capture Current Pose as Open, to make it your own"""

    bl_idname = "pbd.add_lever_arm"
    bl_label = "Add Lever Arm"
    bl_description = ("Gives the selected object a lever arm - the player takes hold of it and drags it with the mouse in the engine. "
                      "Its current pose is the closed one; the open pose is worked out for the kind you pick")
    bl_options = {'REGISTER', 'UNDO'}

    kind: bpy.props.EnumProperty(name="Kind", items=KINDS, default='DOOR')

    @classmethod
    def description(cls, context, properties):
        """The tooltip of each of the three buttons (Door, Drawer, Lever) says what THAT one does, not what the operator is."""
        return _TOOLTIP.get(properties.kind, cls.bl_description)

    def execute(self, context):
        obj = context.object
        problem = lever_arm_problem(obj)
        if problem:
            self.report({'ERROR'}, problem)
            return {'CANCELLED'}
        description = set_lever_arm(obj, self.kind)
        extra = ""
        if self.kind == 'DOOR' and obj.pbd.pbd_type != 'group':
            extra = " - it turns around its own centre; for a hinge on its edge use the Door button under Create"
        self.report({'INFO'}, f"'{obj.name}' now has a lever arm: it {description}{extra}")
        return {'FINISHED'}


class OBJECT_OT_pbd_remove_lever_arm(bpy.types.Operator):
    """Takes the lever arm off the selected object (its open pose and settings are kept, in case you switch it back on)"""

    bl_idname = "pbd.remove_lever_arm"
    bl_label = "Remove Lever Arm"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.object
        if not is_pbd(obj):
            self.report({'ERROR'}, "Select a PBD object first")
            return {'CANCELLED'}
        if not obj.pbd.pbd_lever_arm_enabled:
            self.report({'INFO'}, f"'{obj.name}' has no lever arm")
            return {'CANCELLED'}
        obj.pbd.pbd_lever_arm_enabled = False
        self.report({'INFO'}, f"Lever arm removed from '{obj.name}'")
        return {'FINISHED'}


# ----------------------------------------------------------------------------- a light that follows a door

def new_light(scene, name, group, location):
    """A PBD light at `location`, in Link Group `group`, off to begin with (it is on while its group is open)."""
    bpy.ops.object.add_pbd_light()
    light = bpy.context.active_object
    light.name = name
    light.location = mathutils.Vector(location)
    light.pbd.pbd_link_group = group
    light.pbd.pbd_light_enabled = False
    return light


class OBJECT_OT_pbd_add_door_light(bpy.types.Operator):
    """Adds a light that is on while the selected door, drawer or lever is open (the lamp of a wardrobe or a fridge, the
    light a wall switch turns on): the two share a Link Group, which is all the engine needs"""

    bl_idname = "pbd.add_door_light"
    bl_label = "Add Light Linked to This"
    bl_description = ("Adds a light, linked to the selected door/drawer/lever through a shared Link Group: it is on while that object "
                      "is open and off while it is shut. It starts on the object - move it where it should shine")
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        selected = context.object
        if not is_pbd(selected) or selected.pbd.pbd_type in ('light', 'ref'):
            self.report({'ERROR'}, "Select the door, drawer or lever the light should follow")
            return {'CANCELLED'}
        obj = opener_for(selected)  # a door panel: the hinge Pivot it hangs on, which is what opens
        if obj is None:
            if selected.pbd.pbd_loop_animation and (selected.pbd.pbd_lever_arm_enabled or anim_compat.has_keyframes(selected)):
                self.report({'ERROR'}, f"'{selected.name}' loops (a fan, say): it never opens or shuts, so a light cannot follow it")
            else:
                self.report({'ERROR'}, f"'{selected.name}' cannot open yet - give it (or the Pivot it hangs on) a Lever Arm or keyframes first")
            return {'CANCELLED'}
        scene = context.scene
        group = obj.pbd.pbd_link_group or fresh_group(scene, obj.name + "_light")
        context.view_layer.update()  # a script may have moved it a moment ago: matrix_world is only up to date after this
        where = obj.matrix_world.translation.copy()
        obj.pbd.pbd_link_group = group
        light = new_light(scene, obj.name + "_light", group, where)
        self.report({'INFO'}, f"Light '{light.name}' added at '{obj.name}' (Link Group '{group}'): it is on while '{obj.name}' is open. "
                              f"Move it where it should shine")
        return {'FINISHED'}


# ----------------------------------------------------------------------------- ready-made pieces

def _shape(name, size, *, parent=None, location=(0.0, 0.0, 0.0), material=None):
    """A PBD cube of `size` metres, named, parented, placed (in its parent's space) and given a material."""
    bpy.ops.object.add_pbd_primitive(prim_type='cube')
    obj = bpy.context.active_object
    obj.name = name
    obj.parent = parent
    obj.location = mathutils.Vector(location)
    obj.scale = mathutils.Vector((size[0] / 2.0, size[1] / 2.0, size[2] / 2.0))  # the texture coordinates the cube was made with need no change: they never depend on its size
    if material:
        obj.pbd.pbd_material = material
    return obj


def _pivot(name, *, parent=None, location=None):
    bpy.ops.object.add_pbd_group()
    obj = bpy.context.active_object
    obj.name = name
    obj.parent = parent
    if location is not None:
        obj.location = mathutils.Vector(location)
    return obj


def _finish(context, active):
    """Leaves only `active` selected and active: the object that carries the arm, ready for the next click."""
    for o in context.scene.objects:
        o.select_set(False)
    context.view_layer.objects.active = active
    active.select_set(True)


class OBJECT_OT_add_pbd_door(bpy.types.Operator):
    """A door ready to drag open: a Pivot on the hinge carrying the lever arm, with the panel and a handle parented to it
    (a panel on its own would turn around its centre, not its edge)"""

    bl_idname = "object.add_pbd_door"
    bl_label = "Add PBD Door"
    bl_description = ("A door with a hinge on its edge: a Pivot holding the lever arm (swings 90 degrees), a wooden panel and a metal handle parented "
                      "to it. Placed at the 3D cursor, standing on the floor, the hinge on the left")
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        hinge = _pivot("door")
        _shape("door_panel", (DOOR_WIDTH, DOOR_THICKNESS, DOOR_HEIGHT), parent=hinge,
               location=(DOOR_WIDTH / 2, 0.0, DOOR_HEIGHT / 2), material='wood')
        _shape("door_handle", (0.14, 0.03, 0.03), parent=hinge,
               location=(DOOR_WIDTH - 0.1, -(DOOR_THICKNESS / 2 + 0.015), DOOR_HEIGHT / 2), material='metal')
        set_lever_arm(hinge, 'DOOR')
        _finish(context, hinge)
        self.report({'INFO'}, "Door added: grab it by the handle in the engine. The lever arm is on the Pivot 'door' - turn the hinge side or "
                              "the open angle in its Lever Arm box")
        return {'FINISHED'}


class OBJECT_OT_add_pbd_drawer(bpy.types.Operator):
    """A drawer ready to drag open: a Pivot carrying the lever arm (slides out along -Y and stays where it is let go), with
    the front box and a handle parented to it"""

    bl_idname = "object.add_pbd_drawer"
    bl_label = "Add PBD Drawer"
    bl_description = ("A drawer: a Pivot holding the lever arm (slides out along its front, -Y, and stays where released), a wooden box and a "
                      "metal handle parented to it. Placed at the 3D cursor")
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        width, depth, height = DRAWER_SIZE
        slider = _pivot("drawer")
        _shape("drawer_box", DRAWER_SIZE, parent=slider, location=(0.0, depth / 2, height / 2), material='wood')
        _shape("drawer_handle", (0.14, 0.03, 0.025), parent=slider, location=(0.0, -0.015, height / 2), material='metal')
        set_lever_arm(slider, 'DRAWER', DRAWER_SLIDE)
        _finish(context, slider)
        self.report({'INFO'}, "Drawer added: grab it by the handle in the engine. The lever arm is on the Pivot 'drawer'")
        return {'FINISHED'}


class OBJECT_OT_add_pbd_light_switch(bpy.types.Operator):
    """A wall switch and the lamp it turns on: a plate, a toggle on a pivot that flips up (lever arm) and a light in the same
    Link Group, so the lamp is on while the toggle is up"""

    bl_idname = "object.add_pbd_light_switch"
    bl_label = "Add PBD Light Switch"
    bl_description = ("A wall switch with its lamp: a plate and a toggle that flips up when the player drags it, and a light that is on "
                      "while the toggle is up (they share a Link Group). The switch is at the 3D cursor, facing -Y; the lamp starts 1.4 m "
                      "above and 0.5 m in front of it - move it where it should shine")
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        group = fresh_group(context.scene, "switch")
        root = _pivot("switch")
        origin = root.location.copy()  # where the 3D cursor put it: the lamp is placed from here
        _shape("switch_plate", PLATE_SIZE, parent=root, material='plastic')
        front = -PLATE_SIZE[1] / 2
        lever = _pivot("switch_lever", parent=root, location=(0.0, front, 0.0))
        lever.rotation_euler = mathutils.Euler((math.radians(LEVER_TILT_DEG), 0.0, 0.0), 'XYZ')  # rests tilted down...
        _shape("switch_toggle", (0.02, 0.05, 0.02), parent=lever, location=(0.0, -0.025, 0.0), material='plastic')
        set_lever_arm(lever, 'LEVER', -2 * LEVER_TILT_DEG)  # ...and flips up by twice as much (more X tips a -Y toggle DOWN)
        lever.pbd.pbd_link_group = group
        new_light(context.scene, "switch_light", group, origin + mathutils.Vector(LAMP_OFFSET))
        _finish(context, lever)
        self.report({'INFO'}, f"Light switch added (Link Group '{group}'): the lamp is on while the toggle is up. "
                              f"Move 'switch_light' where it should shine")
        return {'FINISHED'}


# ----------------------------------------------------------------------------- menus

def menu_func(self, context):
    """Add > Mesh: the pieces that are not a plain shape, next to the shapes add_primitive lists."""
    self.layout.separator()
    self.layout.operator(OBJECT_OT_add_pbd_door.bl_idname, text="PBD Door (hinge + lever arm)")
    self.layout.operator(OBJECT_OT_add_pbd_drawer.bl_idname, text="PBD Drawer (lever arm)")
    self.layout.operator(OBJECT_OT_add_pbd_light_switch.bl_idname, text="PBD Light Switch (lever + lamp)")


CLASSES = (OBJECT_OT_pbd_add_lever_arm, OBJECT_OT_pbd_remove_lever_arm, OBJECT_OT_pbd_add_door_light,
           OBJECT_OT_add_pbd_door, OBJECT_OT_add_pbd_drawer, OBJECT_OT_add_pbd_light_switch)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.VIEW3D_MT_mesh_add.append(menu_func)


def unregister():
    bpy.types.VIEW3D_MT_mesh_add.remove(menu_func)
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
