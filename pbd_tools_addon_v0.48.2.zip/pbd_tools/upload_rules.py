"""What the server will accept of a submission - the part of server/pbd_upload_lib.php the add-on can know before it sends anything.

The server is the authority (it reads every byte again, with the engine's own lexer, and a client can say anything), so this module
is not a security boundary: it exists so that a submission which would be refused is refused HERE, with the name of the file and the
rule, instead of after a transfer of up to 120 MB - and so that the add-on itself behaves: it never reads a file the server would
not take, never reads more of one than the server accepts, and never builds a request whose framing a file name could break.

No ``bpy`` in here on purpose: plain Python, run by the tests without Blender, and compared with the server's own constants by
tools/regression/blender_addon_check.py.
"""

import os
import re
import uuid

from . import safety

# ---- the numbers (server/pbd_upload_lib.php: PBD_UPLOAD_*; the regression suite compares them) -----------------------------------------------------------

ALLOWED_EXTENSIONS = ("pbd", "pbdmat", "png", "jpg", "jpeg", "wav")
#: Never sent, whatever the list above says (the server checks these first, as a hard stop).
FORBIDDEN_EXTENSIONS = (
    "php", "php3", "php4", "php5", "php7", "php8", "phtml", "phar", "pht", "phps", "inc",
    "cgi", "pl", "py", "sh", "bash", "exe", "dll", "so", "dylib", "bat", "cmd", "com", "scr", "jar", "class",
    "htaccess", "htpasswd", "config", "ini", "asp", "aspx", "jsp",
    "svg", "html", "htm", "xhtml", "shtml", "js", "mjs", "xml", "xsl", "swf", "zip", "gz",
)
#: What each part of the request says it is: the add-on's own table, so that a request is the same on every machine (the machine's
#: registry of types has a .pbd for PowerBuilder). The server does not believe it either way: it reads the bytes.
CONTENT_TYPES = {"pbd": "text/plain", "pbdmat": "text/plain", "png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg", "wav": "audio/wav"}
MAX_FILES = 40
MAX_SINGLE_FILE = 30 * 1024 * 1024
MAX_TOTAL = 120 * 1024 * 1024
MAX_NAME = 200
#: The longest answer of the server that is read: its messages are a few lines.
MAX_ANSWER_BYTES = 64 * 1024
#: The longest text read from the file that says which add-on version is current.
MAX_VERSION_BYTES = 64

# A plain file name: letters, digits, '_' and '-', one dot, an extension of letters and digits (pbd_lint_is_plain_name).
_PLAIN_NAME = re.compile(r"[A-Za-z0-9_-]+\.[A-Za-z0-9]+\Z")


def is_plain_name(name):
    return _PLAIN_NAME.match(name) is not None


def extension_of(name):
    """The extension of a name in lower case, without the dot ('' when it has none)."""
    return name.rsplit(".", 1)[1].lower() if "." in name else ""


def problems_with(files):
    """The reasons the server would refuse a submission of ``files`` - ``[(name, size in bytes)]`` as the person's disk has them - or []
    when none. Every reason names the file and the rule, so that the person knows what to rename, shrink or remove."""
    problems = []
    if not files:
        return ["there is nothing to send"]
    if len(files) > MAX_FILES:
        problems.append(f"too many files: a submission has at most {MAX_FILES}, this one has {len(files)}")
    seen = {}
    total = 0
    scenes, materials = [], []
    for name, size in files:
        shown = safety.printable(name)
        if len(name) > MAX_NAME or not is_plain_name(name):
            problems.append(f"'{shown}' is not a plain file name (letters, digits, '_' and '-', one dot, at most {MAX_NAME} characters) - rename the file")
            continue
        ext = extension_of(name)
        if ext in FORBIDDEN_EXTENSIONS:
            problems.append(f"'{shown}': a .{ext} file is never accepted")
            continue
        if ext not in ALLOWED_EXTENSIONS:
            problems.append(f"'{shown}': .{ext} is not a kind of file a submission has ({', '.join('.' + e for e in ALLOWED_EXTENSIONS)})")
            continue
        key = name.lower()
        if key in seen:
            problems.append(f"two files are named '{shown}' (the server does not tell capitals apart) - rename one")
        seen[key] = True
        if size <= 0:
            problems.append(f"'{shown}' is empty")
        if size > MAX_SINGLE_FILE:
            problems.append(f"'{shown}' weighs {safety.describe(size)}, more than the {safety.describe(MAX_SINGLE_FILE)} one file may")
        total += size
        if ext == "pbd":
            scenes.append(name)
        elif ext == "pbdmat":
            materials.append(name)
    if total > MAX_TOTAL:
        problems.append(f"the submission weighs {safety.describe(total)}, more than the {safety.describe(MAX_TOTAL)} it may")
    if not scenes:
        problems.append("a submission has a .pbd file and this one has none")
    elif len(scenes) > 1:
        problems.append(f"a submission is one .pbd file (and its materials, pictures and sounds); this one has {len(scenes)}")
    if len(materials) > 1:
        problems.append(f"a submission has at most one .pbdmat file; this one has {len(materials)}")
    return problems


def header_value(text):
    """A file name as it goes into a ``Content-Disposition`` header: the characters that would end the value or the line are escaped the
    way a browser does (``"`` -> %22, CR -> %0D, LF -> %0A), so that no name, however it was made, can add a header or a part."""
    return text.replace("\r", "%0D").replace("\n", "%0A").replace('"', "%22")


def _boundary_absent_from(contents):
    """A boundary that occurs in none of the ``contents`` (RFC 2046 asks for that; a random one nearly always does, this makes sure)."""
    while True:
        boundary = uuid.uuid4().hex
        needle = boundary.encode("ascii")
        if not any(needle in content for content in contents):
            return boundary


def encode_multipart(fields_files):
    """``fields_files``: [(form field name, file name, content bytes)] -> (the Content-Type header value, the body bytes).

    Hand-rolled rather than using the third-party ``requests`` library, which Blender's bundled Python does NOT ship (only the standard
    library is guaranteed), so urllib is the portable choice. Header lines are UTF-8: a file name comes straight from the disk, and a
    real asset library routinely has accented names - the server refuses such names with a clear message (problems_with says so first),
    but the framing never depends on that."""
    boundary = _boundary_absent_from([content for _field, _name, content in fields_files])
    parts = []
    for field_name, filename, content in fields_files:
        mime = CONTENT_TYPES.get(extension_of(filename), "application/octet-stream")
        parts.append(
            (f'--{boundary}\r\n'
             f'Content-Disposition: form-data; name="{header_value(field_name)}"; filename="{header_value(filename)}"\r\n'
             f'Content-Type: {mime}\r\n\r\n').encode("utf-8", "replace")
            + content + b"\r\n")
    parts.append(f"--{boundary}--\r\n".encode("ascii"))
    return f"multipart/form-data; boundary={boundary}", b"".join(parts)


def read_for_upload(path):
    """The bytes of a file to send, refused (before a byte of it is read) when it is larger than the server takes."""
    return safety.read_file_capped(path, MAX_SINGLE_FILE, f"'{safety.printable(os.path.basename(path))}'")
