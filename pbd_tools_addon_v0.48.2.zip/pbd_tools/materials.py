"""
Scene-level material catalog, backing a .pbdmat file (see PbdMatParser on
the engine side). Each pbd_materials entry is one `material NAME { ... }`
block; editing a field here immediately updates a real Blender Material
so every object using that name previews with the right color in the
viewport - not just at export time.
"""

import bpy
import math
import os
import struct

from . import safety
from .pbdmat_text import _PbdmatReader, _is_white, _java_trim, parse_pbdmat_text  # noqa: F401 - the .pbdmat reader (pbdmat_text.py); the checks reach it through this module too


class OBJECT_OT_pbd_refresh(bpy.types.Operator):
    """Re-syncs every PBD material's Blender representation and switches
    Solid-shading viewports to display texture images.

    Solid mode (Blender's default viewport shading) only ever shows a
    material's flat diffuse_color - it has no node graph to read, so an
    Image Texture node being correctly wired to Base Color (which is all
    _sync_material_to_blender sets up) is invisible there no matter how
    correct it is. Material Preview / Rendered modes DO read the node
    graph and would already show it - but Solid is what most people are
    looking at by default, and there's no obvious UI hint that a
    different display mode exists. Solid mode also has its own texture
    display, toggled per-viewport via Viewport Shading > Color >
    Texture - scripted here rather than left as a manual step to find.
    """
    bl_idname = "pbd.refresh"
    bl_label = "Refresh PBD Materials"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Re-applies every PBD material's color/texture/etc to its Blender material, and switches viewports to show textures in Solid shading"

    def execute(self, context):
        for entry in context.scene.pbd_materials:
            _sync_material_to_blender(entry)
        for obj in bpy.data.objects:
            if obj.type == 'MESH' and getattr(obj, "pbd", None) and obj.pbd.pbd_material:
                assign_material_to_object(obj, obj.pbd.pbd_material)

        switched = 0
        for window in context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D':
                    for space in area.spaces:
                        if space.type == 'VIEW_3D':
                            space.shading.color_type = 'TEXTURE'
                            switched += 1

        self.report({'INFO'}, f"Refreshed {len(context.scene.pbd_materials)} material(s), "
                               f"switched {switched} viewport(s) to texture display")
        return {'FINISHED'}


def _sync_uv_mapping(nodes, links, bsdf, entry):
    """The Mapping node the pictures of a material read their coordinates from, made (with the UV coordinates it reads) when it is not
    there, and set from the entry: the scale of each axis, then the turn. Blender's Mapping node (type Point) scales, rotates and then
    moves a coordinate, which is the order the engine uses (the picture is scaled over the surface, and turned inside the tile it fills).
    Its Rotation Z is the NEGATIVE of the picture's turn (uv_rotation_radians): the node turns the coordinates a picture is looked up at,
    and the picture appears to turn the other way."""
    mapping_node = nodes.get("PBD UVScale")
    if mapping_node is None:
        mapping_node = nodes.new("ShaderNodeMapping")
        mapping_node.name = "PBD UVScale"
        mapping_node.label = "PBD UV scale and rotation"
        mapping_node.location = (bsdf.location.x - 700, bsdf.location.y)
    mapping_node.vector_type = 'POINT'
    coord_node = nodes.get("PBD TexCoord")
    if coord_node is None:
        coord_node = nodes.new("ShaderNodeTexCoord")
        coord_node.name = "PBD TexCoord"
        coord_node.location = (bsdf.location.x - 900, bsdf.location.y)
    links.new(coord_node.outputs["UV"], mapping_node.inputs["Vector"])
    mapping_node.inputs["Scale"].default_value = (entry.uv_scale_u, entry.uv_scale_v, 1.0)
    mapping_node.inputs["Rotation"].default_value = (0.0, 0.0, uv_rotation_radians(entry))
    return mapping_node


def _remove_uv_mapping(nodes):
    """Takes the Mapping node and its UV coordinates out of a material that has no picture left to read them. Returns None."""
    for name in ("PBD UVScale", "PBD TexCoord"):
        node = nodes.get(name)
        if node is not None:
            nodes.remove(node)
    return None


def _sync_material_to_blender(entry):
    """Finds or creates a Blender Material matching this entry's name and
    pushes color/specular/texture into it. diffuse_color drives Solid
    shading (proven in this add-on's own test renders); an Image Texture
    node wired into Principled BSDF's Base Color drives Material Preview /
    Rendered shading, so a texture_path actually shows there - a flat
    Base Color value alone can never display an image, no matter what
    that value is."""
    mat_name = "pbd_mat_" + entry.name
    mat = bpy.data.materials.get(mat_name)
    if mat is None:
        mat = bpy.data.materials.new(name=mat_name)
        mat.use_nodes = True

    mat.diffuse_color = (entry.color[0], entry.color[1], entry.color[2], 1.0)
    mat.specular_intensity = entry.specular

    if mat.use_nodes:
        nodes = mat.node_tree.nodes
        links = mat.node_tree.links
        bsdf = nodes.get("Principled BSDF")
        if bsdf is not None:
            if "Specular IOR Level" in bsdf.inputs:  # property name changed across Blender versions
                bsdf.inputs["Specular IOR Level"].default_value = entry.specular
            elif "Specular" in bsdf.inputs:
                bsdf.inputs["Specular"].default_value = entry.specular

            # One Mapping node (scale, then rotation - the engine's order) serves every picture of the material that Blender shows: the
            # diffuse picture and the normal map are read, by the engine's shader, at the same vUV * uvScale, turned alike. It is there while
            # either exists, and goes when neither does.
            mapping_node = _sync_uv_mapping(nodes, links, bsdf, entry) if (entry.texture_path or entry.normal_map_path) else _remove_uv_mapping(nodes)

            tex_node = nodes.get("PBD Texture")
            if entry.texture_path:
                if tex_node is None:
                    tex_node = nodes.new("ShaderNodeTexImage")
                    tex_node.name = "PBD Texture"
                    tex_node.location = (bsdf.location.x - 500, bsdf.location.y)
                links.new(mapping_node.outputs["Vector"], tex_node.inputs["Vector"])
                try:
                    image = bpy.data.images.load(bpy.path.abspath(entry.texture_path), check_existing=True)
                    tex_node.image = image
                    links.new(tex_node.outputs["Color"], bsdf.inputs["Base Color"])
                except RuntimeError as e:
                    print(f"[PBD] Could not load texture '{entry.texture_path}': {e}")
                    bsdf.inputs["Base Color"].default_value = (entry.color[0], entry.color[1], entry.color[2], 1.0)
            else:
                if tex_node is not None:
                    nodes.remove(tex_node)
                bsdf.inputs["Base Color"].default_value = (entry.color[0], entry.color[1], entry.color[2], 1.0)

            # Normal map: needs a dedicated Normal Map node between the
            # image and the BSDF (Blender doesn't accept a raw image color
            # as a normal input - that node is what un-remaps the
            # 0..1-encoded tangent-space vector back into a usable normal).
            normal_tex_node = nodes.get("PBD NormalTexture")
            normal_map_node = nodes.get("PBD NormalMap")
            if entry.normal_map_path:
                if normal_tex_node is None:
                    normal_tex_node = nodes.new("ShaderNodeTexImage")
                    normal_tex_node.name = "PBD NormalTexture"
                    normal_tex_node.location = (bsdf.location.x - 500, bsdf.location.y - 300)
                if normal_map_node is None:
                    normal_map_node = nodes.new("ShaderNodeNormalMap")
                    normal_map_node.name = "PBD NormalMap"
                    normal_map_node.location = (bsdf.location.x - 300, bsdf.location.y - 300)
                links.new(mapping_node.outputs["Vector"], normal_tex_node.inputs["Vector"])
                try:
                    normal_image = bpy.data.images.load(bpy.path.abspath(entry.normal_map_path), check_existing=True)
                    normal_image.colorspace_settings.name = 'Non-Color'  # normal maps are data, not sRGB color
                    normal_tex_node.image = normal_image
                    links.new(normal_tex_node.outputs["Color"], normal_map_node.inputs["Color"])
                    links.new(normal_map_node.outputs["Normal"], bsdf.inputs["Normal"])
                except RuntimeError as e:
                    print(f"[PBD] Could not load normal map '{entry.normal_map_path}': {e}")
            else:
                if normal_tex_node is not None:
                    nodes.remove(normal_tex_node)
                if normal_map_node is not None:
                    nodes.remove(normal_map_node)

            if "Roughness" in bsdf.inputs:
                # No real reflection probe in Blender's viewport, and no
                # single "reflectivity" input on Principled BSDF either -
                # lower roughness reads as glossier/more mirror-like,
                # which is the closer single-slider approximation of "more
                # reflective" than Transmission (which means see-through,
                # not reflective) would be. Same "close visual
                # approximation, not physically exact" policy as this
                # add-on's bend/smooth previews.
                bsdf.inputs["Roughness"].default_value = max(0.05, 0.5 - entry.reflectivity * 0.45)

            mat.blend_method = 'BLEND' if entry.transparency > 0.001 else 'OPAQUE'
            if "Alpha" in bsdf.inputs:
                bsdf.inputs["Alpha"].default_value = 1.0 - entry.transparency
    return mat


def _sync_material_entry(self, context):
    _sync_material_to_blender(self)
    # Re-push to every object currently using this material by name, so
    # a rename or color edit is visible immediately, not just for
    # objects assigned to it afterward.
    for obj in bpy.data.objects:
        if obj.type == 'MESH' and getattr(obj, "pbd", None) and obj.pbd.pbd_material == self.name:
            assign_material_to_object(obj, self.name)


#: the smallest UV scale there is, whatever its sign: a scale of 0 gives every point of a surface the same texture coordinate (one texel
#: over the whole thing), which is never what anybody means; and the largest, far past anything that is still a texture
UV_SCALE_MIN = 0.01
UV_SCALE_LIMIT = 1000.0
#: what a property that holds a float32 gives back for UV_SCALE_MIN is a hair UNDER it (0.0099999998): a value is too small only below this,
#: or correcting it would be corrected again, for ever
_UV_SCALE_TOO_SMALL = UV_SCALE_MIN * 0.99


def _uv_scale_changed(self, context):
    """A UV scale of exactly 0 (or nearer to it than UV_SCALE_MIN) is made +-UV_SCALE_MIN, keeping its sign - typing 0 was never a wish
    for one texel - and the entry is then pushed to its Blender material like any other change. (Blender calls this again for the
    assignment made here, with values that need no correction: the entry is pushed twice then, which does no harm.)"""
    for key in ("uv_scale_u", "uv_scale_v"):
        value = getattr(self, key)
        if abs(value) < _UV_SCALE_TOO_SMALL:
            setattr(self, key, UV_SCALE_MIN if value >= 0.0 else -UV_SCALE_MIN)  # (Blender calls this again for that assignment: nothing left to correct)
    _sync_material_entry(self, context)


#: the turns a picture can be given, in degrees, counter-clockwise as it is seen on the surface (u to the right, v up): the engine's `uvRotation`
#: (pbd.format.MaterialUv.quarterTurns). Only quarter turns: the engine turns the picture where it loads it, for the shader, the classic meshes
#: and the voxels of a shot object alike, so that they cannot disagree - an angle in between would need a shader of its own.
UV_ROTATIONS = (0, 90, 180, 270)
#: what the engine tolerates of a value that is not exactly a multiple of 90 (an angle that went through a float on its way): a thousandth of a degree
UV_ROTATION_TOLERANCE = 1e-3
#: ... and the number of quarter turns beyond which a value is a typo and not a rotation
UV_ROTATION_MAX_TURNS = 1e12


def quarter_turns_of(raw):
    """The quarter turns (0 to 3, counter-clockwise) a value of the `uvRotation` key means, or None when it means none: exactly what the engine's
    MaterialUv.quarterTurns makes of the same text (tools/regression/blender_addon_check.py asks the engine itself, value by value). A value
    within a thousandth of a degree of a multiple of 90 is that multiple."""
    degrees = _decimal(raw)
    if degrees is None:
        return None
    turns = round(degrees / 90.0)  # (halves go to the even one, as Java's Math.rint does)
    if abs(turns) > UV_ROTATION_MAX_TURNS or abs(degrees - turns * 90.0) > UV_ROTATION_TOLERANCE:
        return None
    return int(turns) % 4


def uv_rotation_degrees(entry):
    """The turn of an entry's picture, in degrees: 0, 90, 180 or 270 (what the `uv_rotation` property holds as text; 0 for anything else)."""
    try:
        degrees = int(str(entry.uv_rotation))
    except (AttributeError, TypeError, ValueError):
        return 0
    return degrees if degrees in UV_ROTATIONS else 0


def uv_rotation_radians(entry):
    """The Rotation Z of the Mapping node that shows the entry's turn: MINUS the turn (see _sync_uv_mapping). Verified against a render of real
    Blender (Cycles) in tools/regression/blender_addon_check.py: the node and the engine put the same picture on the same surface."""
    return -math.radians(uv_rotation_degrees(entry))


def has_picture(entry):
    """True when an entry has a picture the Mapping node places: a texture or a normal map (the pictures Blender shows, and the ones the engine's
    uvScale and uvRotation apply to). The panels offer the texture mapping for such an entry, and the node exists exactly while it has one
    (_sync_material_to_blender)."""
    return bool(entry.texture_path or entry.normal_map_path)


def assign_material_to_object(obj, material_name):
    """Finds-or-creates the Blender material for material_name (from the
    scene catalog if present, else a neutral fallback) and makes it the
    object's only material slot. Called whenever pbd_material changes
    (see properties.py) and whenever a catalog entry it's using is edited
    (see _sync_material_entry above)."""
    scene = bpy.context.scene
    entry = scene.pbd_materials.get(material_name)
    if entry is not None:
        mat = _sync_material_to_blender(entry)
    else:
        # Not in the catalog - likely one of the engine's hard-coded
        # names (wood/metal/plastic) or a name from an included .pbdmat
        # this session hasn't loaded. Neutral grey placeholder rather
        # than refusing the name.
        mat_name = "pbd_mat_" + material_name
        mat = bpy.data.materials.get(mat_name)
        if mat is None:
            mat = bpy.data.materials.new(name=mat_name)
            mat.diffuse_color = (0.65, 0.65, 0.68, 1.0)

    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


# ----------------------------------------------------------------------------- how a material breaks
#
# What a hit on a thing made of a material throws up, and how thin a connection may get before the piece it holds comes away whole,
# belongs to the MATERIAL (the engine's pbd.format.BreakProfile reads it from the break* / debris* keys of a .pbdmat block), never to
# a primitive. Every key is optional in the file; what a block leaves out the engine takes from the material's NAME (wood, metal and
# plastic have a profile of their own, any other name the generic one). So the add-on writes nothing for a material until its
# "Custom break" box is ticked - and then all ten keys, so that what you see is what the file says.
#
# The tables below are the engine's, typed again: tools/regression/blender_addon_check.py compares them with the Java classes.

BREAK_NUMBERS = (
    # (key in the .pbdmat, property of the entry, a whole number?, lowest, highest) - a value outside is refused by the engine, not clamped
    ("breakWidth", "break_width", False, 0.0, 1.0),
    ("debrisCount", "debris_count", True, 0, 400),
    ("breakCount", "break_count", True, 0, 400),
    ("debrisSize", "debris_size", False, 0.001, 0.25),
    ("debrisSpeed", "debris_speed", False, 0.0, 30.0),
    ("debrisLifetime", "debris_lifetime", False, 0.1, 30.0),
    ("debrisGravity", "debris_gravity", False, -1.0, 5.0),
    ("debrisBounce", "debris_bounce", False, 0.0, 0.95),
)
BREAK_KEYS = tuple(row[0] for row in BREAK_NUMBERS) + ("debrisColor", "breakSound")

# The eight numbers in BREAK_NUMBERS' order, by exact material name ("Wood" is not "wood" to the engine either)
BREAK_DEFAULTS = {
    "wood": (0.030, 160, 60, 0.022, 3.0, 4.0, 1.0, 0.25),
    "metal": (0.010, 100, 45, 0.014, 4.5, 3.0, 1.0, 0.45),
    "plastic": (0.015, 140, 55, 0.018, 3.8, 3.5, 1.0, 0.40),
}
BREAK_GENERIC = (0.020, 120, 50, 0.020, 3.5, 3.5, 1.0, 0.35)
BREAK_COLOR_START = (0.4, 0.3, 0.2)  # what the tint box starts at when it is ticked (the engine has no tint by default)


def break_defaults_for(name):
    """The eight numbers the engine breaks a material of this name with when its .pbdmat block says nothing about it."""
    return BREAK_DEFAULTS.get(name, BREAK_GENERIC)


def break_values(entry):
    """The eight numbers of an entry, in BREAK_NUMBERS' order."""
    return tuple(getattr(entry, row[1]) for row in BREAK_NUMBERS)


def _same(a, b):
    return abs(a - b) <= 1e-6 * max(1.0, abs(b))  # Blender keeps these as 32-bit floats


def reset_break_to_defaults(entry):
    """Puts the entry's break fields to what the engine uses for a material of its name, and takes the tint and the sound off."""
    for row, value in zip(BREAK_NUMBERS, break_defaults_for(entry.name)):
        setattr(entry, row[1], int(value) if row[2] else value)
    entry.debris_use_color = False
    entry.debris_color = BREAK_COLOR_START
    entry.break_sound = ""


def break_untouched(entry):
    """True while the fields are still the ones a new entry starts with - nobody has edited a number, a tint or a sound yet."""
    return (all(_same(a, b) for a, b in zip(break_values(entry), BREAK_GENERIC))
            and not entry.debris_use_color and entry.break_sound == "")


def _break_toggled(self, context):
    """Ticking "Custom break" on a material nobody has tuned yet starts from the engine's numbers for the material's name (a wood
    starts at 3 cm and 160 chips, not at the generic 2 cm and 120). Numbers already edited are kept: unticking and ticking again
    does not lose them."""
    if self.use_custom_break and break_untouched(self):
        reset_break_to_defaults(self)


def break_sound_problem(name):
    """Why a sound name cannot be written to a .pbdmat, or None when it can: the file format has no way to escape a double quote or end a value early."""
    if '"' in name or any(c in name for c in "\r\n\t"):
        return "a sound name cannot hold a double quote, a tab or a line break"
    return None


def break_sound_of(entry):
    """The sound name of an entry as a .pbdmat will say it - trimmed the way the engine trims it - or "" for no sound."""
    return _java_trim(entry.break_sound)


def _pbdmat_token(text):
    """A value of a .pbdmat block: bare when the engine reads it as one token, in quotes when it has a space, a bracket, a '=' or a '#'."""
    return f'"{text}"' if any(c.isspace() or c in '{}()=#' for c in text) else text


def pbdmat_break_lines(entry, problems=None):
    """The lines of a `material` block that say how it breaks - none at all while the entry uses the engine's own numbers for its name.
    What the format cannot hold (a sound name with a double quote) is left out and, when the caller gave a list, said there."""
    if not entry.use_custom_break:
        return []
    lines = []
    for key, prop, whole, _lo, _hi in BREAK_NUMBERS:
        value = getattr(entry, prop)
        lines.append(f"  {key} = {int(value)}" if whole else f"  {key} = {value:.6g}")
    if entry.debris_use_color:
        lines.append("  debrisColor = (%.6g, %.6g, %.6g)" % tuple(entry.debris_color))
    sound = break_sound_of(entry)
    if sound:
        why = break_sound_problem(sound)
        if why is None:
            lines.append(f"  breakSound = {_pbdmat_token(sound)}")
        elif problems is not None:
            problems.append(f"material '{entry.name}': breakSound not written - {why}")
    return lines


def _number(raw):
    """A number as the older keys have always been read (Python's float), or None - and never NaN or an infinity."""
    try:
        v = float(raw)
    except ValueError:
        return None
    return v if math.isfinite(v) else None


def _f32(x):
    """x rounded to a 32-bit float, the way a Java float holds it - or None when it does not fit in one (the engine reads 1e39 as an infinity)."""
    try:
        return struct.unpack("f", struct.pack("f", x))[0]
    except OverflowError:
        return None


def _decimal_text(raw):
    """The text of a decimal number as the engine's BreakProfile reads one - an optional sign, digits, a point, an exponent; no hex, no 'NaN',
    no suffix, no underscore - trimmed the way Java trims it, or None. (A value in another spelling is left out here, where the engine, which
    also reads '90f', would take it: the add-on never reads MORE than the engine.)"""
    s = _java_trim(raw)
    if not s or any(c not in "0123456789.-+eE" for c in s):
        return None
    return s


def _finite(raw):
    """A decimal number (see _decimal_text) held as a 32-bit float, like every number the engine compares against a range - or None."""
    s = _decimal_text(raw)
    if s is None:
        return None
    try:
        v = _f32(float(s))
    except ValueError:
        return None
    return v if v is not None and math.isfinite(v) else None


def _decimal(raw):
    """A decimal number (see _decimal_text) as a Python float, NOT rounded to 32 bits - how the engine reads a turn - or None."""
    s = _decimal_text(raw)
    if s is None:
        return None
    try:
        v = float(s)
    except ValueError:
        return None
    return v if math.isfinite(v) else None


def _tint(raw):
    """'(r, g, b)' or 'r, g, b', each from 0 to 1 (BreakProfile.parseColor), or None."""
    s = _java_trim(raw)
    if s.startswith("("):
        if not s.endswith(")"):
            return None
        s = s[1:-1]
    parts = s.split(",")
    if len(parts) != 3:
        return None
    rgb = [_finite(p) for p in parts]
    if any(v is None or v < 0.0 or v > 1.0 for v in rgb):
        return None
    return tuple(rgb)


def _typed_fields(name, raw_fields, problems):
    """One block's values, converted. What cannot be read is left out - the engine does the same and falls back to its own default -
    and, when the caller gave a list, said there (so that a script or a click can show it instead of losing it silently)."""

    def note(text):
        if problems is not None:
            problems.append(f"material '{name}': {text}")

    fields = {}
    numbers = {row[0]: row for row in BREAK_NUMBERS}
    for key, raw in raw_fields.items():
        if key == "color":
            parts = [_number(p.strip()) for p in raw.strip("()").split(",")]
            if not parts or any(p is None for p in parts):
                note(f"color='{raw}' is not a colour - left out")
            else:
                fields["color"] = tuple(parts) if len(parts) == 3 else (parts[0],) * 3
        elif key in ("shininess", "specular", "uvScale", "uvScaleU", "uvScaleV", "reflectivity", "transparency", "displacementScale"):
            v = _number(raw)
            if v is None:
                note(f"{key}='{raw}' is not a number - left out")
            else:
                fields[key] = v
        elif key == "uvRotation":
            turns = quarter_turns_of(raw)
            if turns is None:
                note(f"uvRotation='{raw}' is not a multiple of 90 degrees - left out (the picture is not turned)")
            else:
                fields[key] = 90 * turns
        elif key in ("texture", "normalMap", "roughnessMap", "displacementMap"):
            fields[key] = raw
        elif key in numbers:
            _key, _prop, whole, lo, hi = numbers[key]
            v = _finite(raw)
            if v is None or (whole and v != math.floor(v)):
                note(f"{key}='{raw}' is not {'a whole number' if whole else 'a number'} - the engine's own value is kept")
            elif v < _f32(lo) or v > _f32(hi):
                note(f"{key}={_java_trim(raw)} is outside {lo:g} .. {hi:g} - the engine's own value is kept")
            else:
                fields[key] = v
        elif key == "debrisColor":
            tint = _tint(raw)
            if tint is None:
                note(f"debrisColor='{raw}' is not a colour (three numbers from 0 to 1) - the chips take the colour of the surface")
            else:
                fields[key] = tint
        elif key == "breakSound":
            sound = _java_trim(raw)
            if not sound:
                note("breakSound is empty - no sound")
            else:
                fields[key] = sound
        elif key.startswith(("break", "debris")):
            note(f"unknown key '{key}' (the keys that shape a break are {', '.join(BREAK_KEYS)}) - ignored")
    return fields


def _file_of_material(mat_dir, name, key, problems):
    """``name`` (the value of a texture key of a .pbdmat) as a file next to the .pbdmat - or None, with the reason said, when it is not a
    file of the person's: a network path (Windows answers it by offering the person's credentials to that host), an address of another
    kind, an alternate data stream, or - for a .pbdmat unpacked from a bundle - a path that leaves the bundle. The engine's PbdParser
    refuses the same names for the same reason, and the material then keeps no texture."""
    reason = safety.refuse_local_reference(name)
    path = None
    if reason is None:
        path = os.path.join(mat_dir, name)
        if safety.bundle_root_of(mat_dir) is not None and not safety.is_within(safety.bundle_root_of(mat_dir), path):
            reason, path = "it leaves the bundle it is part of", None
    if reason is not None:
        message = f"{key} '{safety.printable(name)}' refused ({reason}) - the material keeps no {key}"
        if problems is not None:
            problems.append(message)
        else:
            print(f"[PBD] {message}")
    return path


def apply_pbdmat_fields(entry, fields, mat_dir, problems=None):
    """Sets a catalog entry from the (already converted) fields of one `material` block - only what the block has, so loading a file
    on top of an entry changes what the file mentions and nothing else. The one place all three readers (the Load .pbdmat button,
    the list of the shared folder, and the .pbd importer's include_material) go through, so that a key cannot be known to one and
    forgotten by another. A texture name that is not a file of the person's (see _file_of_material) is left out and, when `problems`
    is a list, said there."""
    if "color" in fields:
        entry.color = fields["color"]
    if "shininess" in fields:
        entry.shininess = fields["shininess"]
    if "specular" in fields:
        entry.specular = fields["specular"]
    for key, prop in (("texture", "texture_path"), ("normalMap", "normal_map_path"), ("roughnessMap", "roughness_map_path"),
                      ("displacementMap", "displacement_map_path")):
        if key in fields:
            path = _file_of_material(mat_dir, fields[key], key, problems)
            if path is not None:
                setattr(entry, prop, path)
    if "displacementScale" in fields:
        entry.displacement_scale = fields["displacementScale"]
    if "uvScale" in fields:
        entry.uv_scale_u = entry.uv_scale_v = float(fields["uvScale"])
    if "uvScaleU" in fields:
        entry.uv_scale_u = float(fields["uvScaleU"])
    if "uvScaleV" in fields:
        entry.uv_scale_v = float(fields["uvScaleV"])
    if "uvRotation" in fields:
        entry.uv_rotation = str(int(fields["uvRotation"]) % 360)
    if "reflectivity" in fields:
        entry.reflectivity = fields["reflectivity"]
    if "transparency" in fields:
        entry.transparency = fields["transparency"]
    if any(key in fields for key in BREAK_KEYS):
        # the keys the block leaves out are the engine's, for this name - which is where the fields start
        reset_break_to_defaults(entry)
        entry.use_custom_break = True
        for key, prop, whole, _lo, _hi in BREAK_NUMBERS:
            if key in fields:
                setattr(entry, prop, int(fields[key]) if whole else fields[key])
        if "debrisColor" in fields:
            entry.debris_use_color = True
            entry.debris_color = fields["debrisColor"]
        if "breakSound" in fields:
            entry.break_sound = fields["breakSound"]


class PbdIncludeMaterialSource(bpy.types.PropertyGroup):
    """One entry = one include_material line written VERBATIM at export
    - the path or URL exactly as given when it was added (by
    IMPORT_OT_pbdmat's own Include mode, or by hand via the panel), no
    name-convention assumption the way SHARED material_source entries
    make (materials/<name>.pbdmat) and no per-material field
    duplication the way EMBEDDED entries make. This is the mechanism
    that actually satisfies "reference an arbitrary external .pbdmat
    (local OR a URL) without copying its content into this scene" -
    SHARED only ever covers this PROJECT's own conventionally-named
    shared folder, not an arbitrary community asset fetched by its own
    URL."""
    path: bpy.props.StringProperty(name="Path or URL", default="")


def _break_number(index, label, description, **extra):
    """One numeric break property, made from BREAK_NUMBERS[index]: it starts at the generic profile's value and cannot leave the range the
    engine accepts (the engine REFUSES a value outside, it does not clamp it)."""
    _key, _prop, whole, lo, hi = BREAK_NUMBERS[index]
    if whole:
        return bpy.props.IntProperty(name=label, description=description, default=int(BREAK_GENERIC[index]), min=lo, max=hi, **extra)
    return bpy.props.FloatProperty(name=label, description=description, default=BREAK_GENERIC[index], min=lo, max=hi, **extra)


class PbdMaterialEntry(bpy.types.PropertyGroup):
    # Named "name" (not e.g. "mat_name") specifically so prop_search can
    # search this collection directly - see ui_panel.py's use of it on
    # pbd_material - and so bpy.data-style `scene.pbd_materials["wood"]`
    # lookup by name works, both being standard Blender conventions for
    # entries meant to be found by name rather than only by index.
    name: bpy.props.StringProperty(name="Name", default="material", update=_sync_material_entry)
    color: bpy.props.FloatVectorProperty(
        name="Color", subtype='COLOR', size=3, min=0.0, max=1.0,
        default=(0.7, 0.7, 0.7), update=_sync_material_entry,
    )
    shininess: bpy.props.FloatProperty(name="Shininess", default=8.0, min=0.0, soft_max=128.0, update=_sync_material_entry)
    specular: bpy.props.FloatProperty(name="Specular", default=0.1, min=0.0, max=1.0, update=_sync_material_entry)
    texture_path: bpy.props.StringProperty(name="Texture", default="", subtype='FILE_PATH', update=_sync_material_entry)
    normal_map_path: bpy.props.StringProperty(name="Normal Map", default="", subtype='FILE_PATH', update=_sync_material_entry)
    roughness_map_path: bpy.props.StringProperty(name="Roughness Map", default="", subtype='FILE_PATH', update=_sync_material_entry)
    displacement_map_path: bpy.props.StringProperty(name="Displacement Map", default="", subtype='FILE_PATH', update=_sync_material_entry)
    displacement_scale: bpy.props.FloatProperty(name="Displacement Scale", default=0.02, min=0.0, soft_max=0.5, update=_sync_material_entry,
        description="World-space height at a fully-white texel - matches PbdRenderer's own default of 0.02 when this field is omitted from a .pbdmat")
    material_source: bpy.props.EnumProperty(
        name="Material Source",
        items=[
            ('EMBEDDED', "Embed in this .pbd", "Writes this material into a .pbdmat generated alongside this scene's .pbd file"),
            ('SHARED', "Reference materials/ folder", "Points include_material at the shared, project-wide materials/NAME.pbdmat instead of duplicating it here - use for a material that's shared across many assets (ambientcg-derived, say)"),
        ],
        default='EMBEDDED',
    )
    reflectivity: bpy.props.FloatProperty(name="Reflectivity", default=0.0, min=0.0, max=1.0, update=_sync_material_entry)
    transparency: bpy.props.FloatProperty(name="Transparency", default=0.0, min=0.0, max=1.0, update=_sync_material_entry)
    # Split from a single uv_scale (which scaled both axes identically,
    # via a Mapping node's Scale input set to (v,v,v)) into independent
    # U/V control - a non-square texture on a non-square surface needs
    # to tile at a DIFFERENT rate per axis, which a single shared value
    # can never express regardless of what number it's set to. The old
    # combined field's name and meaning are preserved as uvScale= on
    # export/import ONLY when both axes still match (see export_pbd.py/
    # import_pbd.py) - not written as a separate concept alongside the
    # two axis values, since that would just be redundant data that
    # could disagree with them.
    # A NEGATIVE scale mirrors the picture along that axis (the engine reads it that way, on the model and on the voxels a shot object
    # breaks into: the shader's coordinate is multiplied by the scale and the texture repeats, so -1 shows it back to front) - the
    # Mirror U / Mirror V buttons (pbd.mirror_texture) are just a quick way to change the sign. Never 0: that would show one texel
    # everywhere (see _uv_scale_changed).
    uv_scale_u: bpy.props.FloatProperty(name="UV Scale U", default=1.0, min=-UV_SCALE_LIMIT, max=UV_SCALE_LIMIT, soft_min=-20.0, soft_max=20.0,
        update=_uv_scale_changed,
        description="Tiling repeat factor across the surface, U (horizontal) axis - 1.0 = the picture spans each face once, 2.0 = twice, so smaller, more repeated tiles. "
                    "Negative = the picture mirrored left to right (see Mirror U)")
    uv_scale_v: bpy.props.FloatProperty(name="UV Scale V", default=1.0, min=-UV_SCALE_LIMIT, max=UV_SCALE_LIMIT, soft_min=-20.0, soft_max=20.0,
        update=_uv_scale_changed,
        description="Tiling repeat factor across the surface, V (vertical) axis. Negative = the picture mirrored top to bottom (see Mirror V)")

    # The turn of the picture, by quarter turns: counter-clockwise as it is seen on the surface, like the engine's uvRotation (the engine turns the
    # picture where it loads it). Held as the text of the angle, so that Blender offers exactly the four values there are (the Rotate Left /
    # Rotate Right buttons, pbd.rotate_texture, step it). In the Blender material it is the Rotation Z of the Mapping node, minus the angle.
    uv_rotation: bpy.props.EnumProperty(
        name="UV Rotation",
        items=[
            ('0', "0\u00b0", "The picture as it is in the file"),
            ('90', "90\u00b0", "The picture turned a quarter turn counter-clockwise on the surface"),
            ('180', "180\u00b0", "The picture upside down"),
            ('270', "270\u00b0", "The picture turned a quarter turn clockwise on the surface"),
        ],
        default='0', update=_sync_material_entry,
        description="Turns the picture of the material (and its normal map) on the surface by quarter turns, counter-clockwise as seen on the surface. "
                    "The engine turns the picture when it loads it, so the model, the classic meshes and the voxels of a shot object show it the same way")

    # How the material BREAKS - what a hit throws up and how thin a connection may get before the piece it holds comes away whole.
    # Defined here, by the material, and never on a primitive (see "how a material breaks" above). The numbers' defaults and limits
    # come from the tables at the top of this file, so the panel cannot offer a value the engine would refuse.
    use_custom_break: bpy.props.BoolProperty(
        name="Custom break", default=False, update=_break_toggled,
        description="Write how this material breaks into its .pbdmat. Left unticked, the engine breaks it like any material of its name "
                    "(wood, metal and plastic have a profile of their own, any other name the generic one)")
    break_width: _break_number(0, "Break Width",
        "Thinnest connection, in metres, that still holds a piece to the rest. After a shot, a piece joined by less comes away whole, "
        "with a crack. 0 = never (a rubbery material)", precision=3)
    debris_count: _break_number(1, "Chips per Crater",
        "Particles thrown up by a crater of the full size; a smaller crater throws proportionally fewer")
    break_count: _break_number(2, "Chips per Break",
        "Particles thrown up when a piece comes away")
    debris_size: _break_number(3, "Chip Size",
        "Mean edge of a particle, in metres", precision=3)
    debris_speed: _break_number(4, "Chip Speed",
        "Mean speed a particle leaves the crater at, in metres per second")
    debris_lifetime: _break_number(5, "Chip Lifetime",
        "Mean time a particle lives, in seconds; it fades out over its last quarter")
    debris_gravity: _break_number(6, "Chip Gravity",
        "Multiple of gravity: 1 = falls like a stone, 0 = floats, negative = rises")
    debris_bounce: _break_number(7, "Chip Bounce",
        "0 = a particle stays where it lands, 0.95 = it nearly keeps its speed")
    debris_use_color: bpy.props.BoolProperty(
        name="Tint the chips", default=False,
        description="Give the particles the colour below. Unticked, they take the colour of the surface that broke (the usual, and right for a textured one)")
    debris_color: bpy.props.FloatVectorProperty(
        name="Chip Color", subtype='COLOR', size=3, min=0.0, max=1.0, default=BREAK_COLOR_START,
        description="Colour of the particles")
    break_sound: bpy.props.StringProperty(
        name="Break Sound", default="",
        description="Sound played when a piece comes away: the name of a file in resources/sounds (wood-crack.wav, say). Empty = no sound. "
                    "A double quote, a tab or a line break cannot be written to the .pbdmat")


class OBJECT_OT_pbd_material_add(bpy.types.Operator):
    bl_idname = "pbd.material_add"
    bl_label = "Add PBD Material"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        entry = context.scene.pbd_materials.add()
        base = "material"
        name, i = base, 1
        existing = {m.name for m in context.scene.pbd_materials}
        while name in existing:
            i += 1
            name = f"{base}{i}"
        entry.name = name
        context.scene.pbd_materials_active_index = len(context.scene.pbd_materials) - 1
        return {'FINISHED'}


class OBJECT_OT_pbd_material_remove(bpy.types.Operator):
    bl_idname = "pbd.material_remove"
    bl_label = "Remove PBD Material"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        idx = scene.pbd_materials_active_index
        if 0 <= idx < len(scene.pbd_materials):
            scene.pbd_materials.remove(idx)
            scene.pbd_materials_active_index = min(idx, len(scene.pbd_materials) - 1)
        return {'FINISHED'}


class OBJECT_OT_pbd_material_sync_from_objects(bpy.types.Operator):
    """Adds a catalog entry (default color/shininess, no texture) for
    every distinct pbd_material name already set on a PBD object that
    doesn't have one yet - the exact gap that makes a typed-but-not-added
    material's fields (UV scale, texture, normal map...) invisible: they
    only exist on catalog entries, and typing a name directly (prop_search
    allows free text) never creates one."""
    bl_idname = "pbd.material_sync_from_objects"
    bl_label = "Sync PBD Materials From Objects"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        existing = {m.name for m in context.scene.pbd_materials}
        used = {
            obj.pbd.pbd_material
            for obj in bpy.data.objects
            if obj.type == 'MESH' and getattr(obj, "pbd", None)
            and obj.pbd.is_pbd_primitive and obj.pbd.pbd_material
        }
        missing = sorted(used - existing)
        for name in missing:
            entry = context.scene.pbd_materials.add()
            entry.name = name
        self.report({'INFO'}, f"Added {len(missing)} material(s): {', '.join(missing) if missing else '(none missing)'}")
        return {'FINISHED'}


class OBJECT_OT_pbd_material_load(bpy.types.Operator):
    """Loads a .pbdmat file's entries into the scene catalog, on top of
    (not replacing) whatever's already there - reuses the engine's own
    grammar directly rather than a second parser, since it's a small,
    line-oriented format (see the docstring on the parsing helper below)."""
    bl_idname = "pbd.material_load"
    bl_label = "Load .pbdmat"
    bl_options = {'REGISTER', 'UNDO'}

    filepath: bpy.props.StringProperty(subtype='FILE_PATH')

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        problems = []
        try:
            materials = _parse_pbdmat(self.filepath, problems)
        except (OSError, ValueError) as e:  # ValueError: not a .pbdmat the engine could read (and a file that is not UTF-8)
            self.report({'ERROR'}, f"Could not read {self.filepath}: {e}")
            return {'CANCELLED'}

        scene = context.scene
        mat_dir = os.path.dirname(os.path.abspath(self.filepath))
        for name, fields in materials.items():
            entry = scene.pbd_materials.get(name)
            if entry is None:
                entry = scene.pbd_materials.add()
                entry.name = name
            apply_pbdmat_fields(entry, fields, mat_dir, problems)
        for problem in problems:
            self.report({'WARNING'}, problem)
        self.report({'INFO'}, f"Loaded {len(materials)} material(s) from {self.filepath}")
        return {'FINISHED'}


def _parse_pbdmat(filepath, problems=None):
    """-> {material name: {key: value}} for the `material NAME { key = value ... }` blocks of a .pbdmat, the values converted (a colour
    to a tuple, a number to a float; a path stays text). Reads the file exactly as the engine's PbdMatParser does - quotes, balanced
    brackets, comments, several keys on a line - because parse_pbdmat_text is that grammar, not a guess at it.

    A value that cannot be read is left out, and, when `problems` is a list, said there. A file the engine would refuse (a block never
    closed, a stray word) raises ValueError with the line; an unreadable file raises OSError."""
    # read as bytes (the size is looked at before a byte is read) and decoded as is: a lone \r is not a line break to the engine either
    text = safety.read_text_capped(filepath)
    _authors, blocks = parse_pbdmat_text(text)
    return {name: _typed_fields(name, raw, problems) for name, raw in blocks.items()}


class OBJECT_OT_pbd_material_save(bpy.types.Operator):
    bl_idname = "pbd.material_save"
    bl_label = "Save .pbdmat"
    bl_options = {'REGISTER', 'UNDO'}

    filepath: bpy.props.StringProperty(subtype='FILE_PATH', default="materials.pbdmat")

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        lines = []
        problems = []
        for entry in context.scene.pbd_materials:
            lines.append(f"material {entry.name} {{")
            lines.append("  color     = (%.4g, %.4g, %.4g)" % tuple(entry.color))
            lines.append(f"  shininess = {entry.shininess:.4g}")
            lines.append(f"  specular  = {entry.specular:.4g}")
            if entry.texture_path:
                lines.append(f"  texture   = {pbdmat_value(os.path.basename(entry.texture_path))}")
            lines.extend(uv_lines(entry))
            if entry.normal_map_path:
                lines.append(f"  normalMap = {pbdmat_value(os.path.basename(entry.normal_map_path))}")
            if entry.roughness_map_path:
                lines.append(f"  roughnessMap = {pbdmat_value(os.path.basename(entry.roughness_map_path))}")
            if entry.displacement_map_path:
                lines.append(f"  displacementMap = {pbdmat_value(os.path.basename(entry.displacement_map_path))}")
                lines.append(f"  displacementScale = {entry.displacement_scale:.4g}")
            if entry.reflectivity > 0.001:
                lines.append(f"  reflectivity = {entry.reflectivity:.4g}")
            if entry.transparency > 0.001:
                lines.append(f"  transparency = {entry.transparency:.4g}")
            lines.extend(pbdmat_break_lines(entry, problems))
            lines.append("}")
            lines.append("")
        try:
            with open(self.filepath, "w", encoding="utf-8") as f:
                f.write("\n".join(lines))
        except OSError as e:
            self.report({'ERROR'}, f"Could not write {self.filepath}: {e}")
            return {'CANCELLED'}
        for problem in problems:
            self.report({'WARNING'}, problem)
        self.report({'INFO'}, f"Saved {len(context.scene.pbd_materials)} material(s) to {self.filepath}")
        return {'FINISHED'}


class OBJECT_OT_pbd_material_break_reset(bpy.types.Operator):
    """Back to the engine's own break numbers for the active catalog entry's NAME (wood, metal, plastic or the generic profile), and
    "Custom break" unticked - so its .pbdmat block says nothing about breaking again."""
    bl_idname = "pbd.material_break_reset"
    bl_label = "Back to the Engine's Defaults"
    bl_description = ("Puts every break field back to what the engine uses for a material of this name and unticks Custom break, "
                      "so the .pbdmat writes nothing about how it breaks")
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        index = scene.pbd_materials_active_index
        if not 0 <= index < len(scene.pbd_materials):
            self.report({'ERROR'}, "Select a material in the list first")
            return {'CANCELLED'}
        entry = scene.pbd_materials[index]
        reset_break_to_defaults(entry)
        entry.use_custom_break = False
        profile = f"'{entry.name}'" if entry.name in BREAK_DEFAULTS else "generic"
        self.report({'INFO'}, f"'{entry.name}' breaks with the engine's {profile} profile again")
        return {'FINISHED'}


class OBJECT_OT_pbd_include_material_remove(bpy.types.Operator):
    """Removes one entry from scene.pbd_include_material_sources by
    index - the equivalent of OBJECT_OT_pbd_material_remove for THIS
    collection, kept as its own tiny operator rather than reusing that
    one, since the two collections hold structurally different things
    (a full material's worth of fields vs. a single path string)."""
    bl_idname = "pbd.include_material_remove"
    bl_label = "Remove Included Material Source"
    bl_options = {'REGISTER', 'UNDO'}

    index: bpy.props.IntProperty()

    def execute(self, context):
        sources = context.scene.pbd_include_material_sources
        if 0 <= self.index < len(sources):
            sources.remove(self.index)
        return {'FINISHED'}


def pbdmat_value(text):
    """A file name as the engine's PbdMatParser reads a value back: bare when it is one token, in quotes when it holds a space, a tab or one of
    the characters that end a bare value (`{ } ( ) =`, and `#`, which begins a comment). A picture called `wood floor.png` written bare was read
    as the key `wood` followed by a stray word, and the engine refused the whole file. A double quote cannot be written at all (the format has no
    escape for one): it becomes an apostrophe, as in the File box."""
    text = str(text).replace('"', "'")
    if text == "" or any(c.isspace() or c in "{}()=#" for c in text):
        return f'"{text}"'
    return text


def uv_scale_lines(entry):
    """The .pbdmat lines for an entry's UV scale: none for 1 x 1 (the engine's own), `uvScale` when both axes agree (the short,
    backward-compatible form - and, negative, a mirror on both axes), `uvScaleU` and `uvScaleV` when they differ. A negative value
    is written as it is: the engine reads the sign as a mirror (pbd.format.MaterialUv)."""
    if abs(entry.uv_scale_u - 1.0) <= 0.001 and abs(entry.uv_scale_v - 1.0) <= 0.001:
        return []
    if abs(entry.uv_scale_u - entry.uv_scale_v) < 0.001:
        return [f"  uvScale   = {entry.uv_scale_u:.4g}"]
    return [f"  uvScaleU  = {entry.uv_scale_u:.4g}", f"  uvScaleV  = {entry.uv_scale_v:.4g}"]


def uv_rotation_lines(entry):
    """The .pbdmat line for an entry's UV rotation: none for 0 (the engine's own), else `uvRotation` in degrees - 90, 180 or 270."""
    degrees = uv_rotation_degrees(entry)
    return [f"  uvRotation = {degrees}"] if degrees else []


def uv_lines(entry):
    """Every .pbdmat line that places an entry's picture on a surface: its scale (a negative one is a mirror) and its rotation. The one place
    the two writers of a .pbdmat (the Save button, the exporter) ask, so that neither can forget one."""
    return uv_scale_lines(entry) + uv_rotation_lines(entry)


def rotate_texture(entry, turns):
    """Turns the entry's picture `turns` quarter turns counter-clockwise (negative: clockwise; any number, 4 is none). Returns the new angle in
    degrees: 0, 90, 180 or 270."""
    degrees = (uv_rotation_degrees(entry) + 90 * int(turns)) % 360
    entry.uv_rotation = str(degrees)
    return degrees


def mirror_texture(entry, axis):
    """Flips the sign of the entry's UV scale on one axis ('U' or 'V'): the engine reads a negative scale as the picture mirrored on that
    axis. Returns the new scale on that axis."""
    if axis == 'U':
        entry.uv_scale_u = -entry.uv_scale_u
        return entry.uv_scale_u
    if axis == 'V':
        entry.uv_scale_v = -entry.uv_scale_v
        return entry.uv_scale_v
    raise ValueError(f"axis must be 'U' or 'V', not {axis!r}")


class OBJECT_OT_pbd_mirror_texture(bpy.types.Operator):
    """Mirrors the texture of a material along one axis of the picture: left-right (U) or top-bottom (V).

    It changes the sign of the material's UV Scale on that axis - nothing else - and the engine reads a negative scale as a mirror, on the
    model and on the voxels it breaks into. Every object using the material is mirrored with it (the picture belongs to the material,
    not to an object): give an object that must differ a material of its own. Press again to undo."""
    bl_idname = "pbd.mirror_texture"
    bl_label = "Mirror Texture"
    bl_description = ("Mirrors the texture of this material along one axis (the sign of its UV Scale on that axis): the engine reads a negative scale "
                      "as the picture mirrored, on the model and on the voxels it breaks into. Press again to undo. Every object using the material changes")
    bl_options = {'REGISTER', 'UNDO'}

    axis: bpy.props.EnumProperty(
        name="Axis",
        items=[
            ('U', "Left-Right (U)", "Mirror the picture left to right"),
            ('V', "Top-Bottom (V)", "Mirror the picture top to bottom"),
        ],
        default='U',
    )
    material: bpy.props.StringProperty(
        name="Material", default="",
        description="The catalog entry to mirror. Empty = the material of the active object")

    def execute(self, context):
        scene = context.scene
        name = self.material
        if not name:
            obj = context.object
            name = obj.pbd.pbd_material if obj is not None and getattr(obj, "pbd", None) else ""
        entry = scene.pbd_materials.get(name) if name else None
        if entry is None:
            self.report({'ERROR'}, "No material to mirror: pick one in the list, or give the active object a material from the catalog")
            return {'CANCELLED'}
        scale = mirror_texture(entry, self.axis)
        word = "mirrored" if scale < 0 else "back the right way round"
        self.report({'INFO'}, f"'{entry.name}' is now {word} ({'left-right' if self.axis == 'U' else 'top-bottom'}), UV Scale {self.axis} = {scale:g}")
        return {'FINISHED'}


class OBJECT_OT_pbd_rotate_texture(bpy.types.Operator):
    """Turns the texture of a material a quarter turn: counter-clockwise (Rotate Left) or clockwise (Rotate Right).

    It changes the material's UV Rotation - nothing else - and the engine turns the picture where it loads it, so the model, the classic
    meshes and the voxels a shot object breaks into show it the same way; the Blender material shows it through the Rotation of its Mapping
    node. Every object using the material is turned with it (the picture belongs to the material, not to an object): give an object that
    must differ a material of its own. Four quarter turns bring it back."""
    bl_idname = "pbd.rotate_texture"
    bl_label = "Rotate Texture"
    bl_description = ("Turns the texture of this material a quarter turn on the surface (its UV Rotation, in steps of 90 degrees): the engine turns the picture "
                      "where it loads it, so the model and the voxels it breaks into agree. Every object using the material changes")
    bl_options = {'REGISTER', 'UNDO'}

    turns: bpy.props.IntProperty(
        name="Quarter Turns", default=1, min=-3, max=3,
        description="Quarter turns, counter-clockwise as seen on the surface: 1 = Rotate Left, -1 = Rotate Right")
    material: bpy.props.StringProperty(
        name="Material", default="",
        description="The catalog entry to turn. Empty = the material of the active object")

    def execute(self, context):
        scene = context.scene
        name = self.material
        if not name:
            obj = context.object
            name = obj.pbd.pbd_material if obj is not None and getattr(obj, "pbd", None) else ""
        entry = scene.pbd_materials.get(name) if name else None
        if entry is None:
            self.report({'ERROR'}, "No material to rotate: pick one in the list, or give the active object a material from the catalog")
            return {'CANCELLED'}
        degrees = rotate_texture(entry, self.turns)
        what = "the way it is in the file" if degrees == 0 else f"turned {degrees} degrees counter-clockwise"
        self.report({'INFO'}, f"'{entry.name}': the picture is now {what} (UV Rotation = {degrees})")
        return {'FINISHED'}


CLASSES = (
    PbdIncludeMaterialSource,
    OBJECT_OT_pbd_include_material_remove,
    PbdMaterialEntry,
    OBJECT_OT_pbd_mirror_texture,
    OBJECT_OT_pbd_rotate_texture,
    OBJECT_OT_pbd_material_add,
    OBJECT_OT_pbd_material_remove,
    OBJECT_OT_pbd_material_load,
    OBJECT_OT_pbd_material_save,
    OBJECT_OT_pbd_material_break_reset,
    OBJECT_OT_pbd_material_sync_from_objects,
    OBJECT_OT_pbd_refresh,
)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.pbd_materials = bpy.props.CollectionProperty(type=PbdMaterialEntry)
    bpy.types.Scene.pbd_materials_active_index = bpy.props.IntProperty(default=0)
    bpy.types.Scene.pbd_export_minify = bpy.props.BoolProperty(
        name="Minify",
        default=False,
        description="Write the .pbd text minified (every separator trimmed to the minimum "
                    "the parser can still read - no indentation, fields space-separated "
                    "instead of one per line) instead of the human-readable pretty form. "
                    "Smaller file, harder to hand-edit or diff - matches PbdSerializer.java's "
                    "own pretty/minified distinction, now available from the add-on's own "
                    "text export too, not just via the separate .pbdbin compiled format",
    )
    # Scene-level TEXTUAL metadata - describing the FILE as a whole
    # (matching PbdScene.java's own name/kind/authors/origin/description fields),
    # not any one primitive in it. Previously had no UI at all despite
    # being fully supported by the parser/serializer for as long as
    # those existed - distinct from pbd_metadata (a per-OBJECT boolean
    # marking an invisible storage-volume primitive, entirely unrelated
    # despite the similar name) and from the new pbd_category below
    # (also per-object, a free-form semantic tag, not a file description).
    bpy.types.Scene.pbd_scene_name = bpy.props.StringProperty(
        name="Name", default="",
        description="Human-readable label for the whole file ('Wardrobe', 'Rain Barrel') - not the same thing as any instance's own object name",
    )
    bpy.types.Scene.pbd_scene_kind = bpy.props.StringProperty(
        name="Kind", default="",
        description="Free-form category for the whole file ('furniture', 'container', 'decoration') - not validated against a fixed list",
    )
    bpy.types.Scene.pbd_scene_authors = bpy.props.StringProperty(
        name="Authors", default="",
        description="Comma-separated if more than one - each becomes its own author= line on export (PbdScene.authors is a list, a single field would lose all but the last of several credited authors)",
    )
    bpy.types.Scene.pbd_scene_origin = bpy.props.StringProperty(
        name="Origin", default="",
        description="The URL this file was fetched from, if any - normally set automatically by whatever fetched it (see PbdFetcher), not something to fill in by hand for a locally-authored file. A file with no origin was authored locally",
    )
    bpy.types.Scene.pbd_scene_description = bpy.props.StringProperty(
        name="Description", default="",
        description="Free-form text about the whole file ('Oak wardrobe, two doors, the left one sticks') - what the site's search reads along with the name and the kind. One line; a double quote is written as an apostrophe, since the format has no way to escape it. Leave empty for none",
    )
    bpy.types.Scene.pbd_materials_folder = bpy.props.StringProperty(
        name="Materials Folder",
        subtype='DIR_PATH',
        default="",
        description="Where the project-wide shared materials/ folder is - set INDEPENDENTLY of anything else (there is no longer one combined 'project root' setting - each thing that needs a folder gets its own, since a single shared setting was easy to point at the wrong place for whichever purpose wasn't foremost in mind at the time). Leave empty to fall back to guessing relative to this add-on's own install location, which only works if it happens to be installed from inside a checkout of this project",
    )
    bpy.types.Scene.pbd_include_material_sources = bpy.props.CollectionProperty(
        type=PbdIncludeMaterialSource,
        name="Included Material Files",
        description="Extra include_material lines written verbatim at export, beyond what EMBEDDED/SHARED material entries already produce - see PbdIncludeMaterialSource's own doc for why this exists as a THIRD mechanism rather than folding into either of those",
    )


def unregister():
    del bpy.types.Scene.pbd_include_material_sources
    del bpy.types.Scene.pbd_materials_folder
    del bpy.types.Scene.pbd_scene_description
    del bpy.types.Scene.pbd_scene_origin
    del bpy.types.Scene.pbd_scene_authors
    del bpy.types.Scene.pbd_scene_kind
    del bpy.types.Scene.pbd_scene_name
    del bpy.types.Scene.pbd_export_minify
    del bpy.types.Scene.pbd_materials_active_index
    del bpy.types.Scene.pbd_materials
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
