"""
The texture coordinates the ENGINE gives every point of a primitive, worked out for the mesh Blender shows in its place.

How the engine lays a texture over a primitive. Not by the size of the thing in metres: its shader draws each primitive as a few
"patches" (a cube is six, one per face; a cylinder is three - the wall and its two caps; a sphere, a plane, a disc and a torus are one)
and a point of a patch has the coordinate (u, v) it has IN THE PATCH, each running 0 to 1, times the material's uvScale. A face of a
cube shows the whole picture once, whatever its size, and uvScale = 3 repeats it three times; a face of a door 4 cm thick and one of
a wall 4 m long both show the picture once. The tables below are that parametrisation, one line per patch - the shader's own
(pbd.tese's evalCubeFace..., the sphere's longitude/latitude, ...) and what the engine's voxel conversion reads back when a shot
object is made of voxels (pbd.voxel.ShapeEval#locate), so that the picture is the same on the model, on the voxels, and here.

What Blender shows. A Blender primitive is a mesh of its own, and a mesh has the texture coordinates it is given, per corner of
each face. The add-on used to project them as a cube of the object's size (bpy.ops.uv.cube_project) - a different layout on
every face the moment the object was not a cube, which is what made a locker's picture streak in the viewport while the engine
showed it whole. This module computes, for every corner of every face of the preview mesh, the (u, v) the shader has at that point:
no operator, no selection, no edit mode, nothing that depends on the object's size or on a mode.

Frames. Blender's primitives are 2 x 2 x 2 and Z is up; the engine's are 1 x 1 x 1 and Y is up (see export_pbd.py: x2 and the axis
change). A point of the mesh is carried to the engine's frame first (native_to_canonical), then read off the tables.

Pure Python, no bpy and no bmesh: the engine's own evaluator checks it (BlenderAddonDump --uv-probe, in tools/regression).
"""

import math

TAU = 2.0 * math.pi

#: the primitives the engine draws with a parametrisation of its own (a 'mesh' carries its own UVs, a ref/group/light has no surface)
ENGINE_TYPES = ('plane', 'sphere', 'cylinder', 'cone', 'cube', 'disc', 'torus')

#: the torus' ring radius in the engine's canonical unit (pbd.tese: 0.35, tube 0.15) - Blender's own is 0.7 / 0.3 at twice the size
TORUS_MAJOR = 0.35

#: a point nearer the Y axis than this has no longitude: a pole, the apex of a cone, the middle of a cap
AXIS_EPS = 1e-9

#: a cap is flat: its corners differ in height by less than this (canonical units)
FLAT_EPS = 1e-6


def native_to_canonical(p):
    """A point of Blender's native mesh (2 x 2 x 2, Z up) in the engine's canonical frame (1 x 1 x 1, Y up): x, z, -y, halved."""
    return (p[0] * 0.5, p[2] * 0.5, -p[1] * 0.5)


def native_direction_to_canonical(n):
    """A direction (a normal) in the same change of frame, not scaled."""
    return (n[0], n[2], -n[1])


def wrap01(x):
    """x brought into 0 .. 1 (1 itself becomes 0), like the shader's fract."""
    f = x - math.floor(x)
    return 0.0 if f >= 1.0 else f


def turns(b, a):
    """The polar angle of the point (a, b), as a fraction of a turn 0 .. 1 - the shader's uv.x * TAU, backwards."""
    return wrap01(math.atan2(b, a) / TAU)


def newell_normal(points):
    """The normal of a polygon, from its own corners (Newell's method), for a polygon with no normal given."""
    nx = ny = nz = 0.0
    count = len(points)
    for i in range(count):
        a, b = points[i], points[(i + 1) % count]
        nx += (a[1] - b[1]) * (a[2] + b[2])
        ny += (a[2] - b[2]) * (a[0] + b[0])
        nz += (a[0] - b[0]) * (a[1] + b[1])
    return (nx, ny, nz)


# ------------------------------------------------------------------------------------------------ the cube

#: the six faces in the engine's order: +X, -X, +Y, -Y, +Z, -Z - the index is 2 * axis + (1 if the face looks to the negative side)
CUBE_FACE_NAMES = ('+X', '-X', '+Y', '-Y', '+Z', '-Z')


def cube_face_of(direction):
    """The face of the engine's cube that lies in this (canonical) direction from the cube's middle: the axis the direction is longest
    on, and its sign."""
    axis = 0
    for i in (1, 2):
        if abs(direction[i]) > abs(direction[axis]):
            axis = i
    return 2 * axis + (0 if direction[axis] >= 0.0 else 1)


def cube_uv(face, q):
    """(u, v) of the canonical point q on face `face` of a cube - the shader's table: the picture reads left to right and upright seen
    from outside, except that the top and bottom read along X and Z."""
    x, y, z = q
    if face == 0: return (0.5 - z, y + 0.5)
    if face == 1: return (z + 0.5, y + 0.5)
    if face == 2: return (x + 0.5, 0.5 - z)
    if face == 3: return (x + 0.5, z + 0.5)
    if face == 4: return (x + 0.5, y + 0.5)
    return (0.5 - x, y + 0.5)


# ------------------------------------------------------------------------------------------------ the shapes around the Y axis

def _unwrapped(values):
    """The coordinates of a polygon's corners that run round (a longitude: 0.98 and 0.01 are neighbours) made continuous: each moved by a
    whole number of turns to lie within half a turn of the first known one, then the lot moved so that their mean lies in 0 .. 1 - the
    column of the engine's patch the face is in (the face just before the seam runs up to 1.0, the one just after starts at 0).
    A None is a corner with no coordinate of its own (a pole, an apex, the middle of a cap): it takes the mean of the others, which is
    where the engine's triangles that meet there are headed."""
    known = [v for v in values if v is not None]
    if not known:
        return [0.0] * len(values)
    reference = known[0]
    moved = [None if v is None else v + math.floor(reference - v + 0.5) for v in values]
    placed = [m for m in moved if m is not None]
    mean = sum(placed) / len(placed)
    shift = -math.floor(mean)
    return [(mean if m is None else m) + shift for m in moved]


def _is_cap(points, normal):
    """A flat polygon facing up or down: all its corners at one height, the normal along Y."""
    heights = [p[1] for p in points]
    if max(heights) - min(heights) > FLAT_EPS:
        return False
    length = math.sqrt(normal[0] ** 2 + normal[1] ** 2 + normal[2] ** 2)
    return length > 0.0 and abs(normal[1]) / length > 0.99


def _around_axis(prim_type, points, normal):
    """(part, [(u, v) ...]) for a polygon of a sphere, a disc, a torus, a cylinder or a cone (canonical points)."""
    radii = [math.hypot(p[0], p[2]) for p in points]
    longitudes = [turns(p[2], p[0]) if r > AXIS_EPS else None for p, r in zip(points, radii)]
    part = 0
    if prim_type == 'sphere':
        vs = []
        for p in points:
            r = math.sqrt(p[0] ** 2 + p[1] ** 2 + p[2] ** 2)
            vs.append(0.5 if r < 1e-12 else math.acos(max(-1.0, min(1.0, p[1] / r))) / math.pi)
    elif prim_type == 'disc':
        vs = [2.0 * r for r in radii]
    elif prim_type == 'torus':
        rings = [turns(p[1], r - TORUS_MAJOR) for p, r in zip(points, radii)]
        vs = _unwrapped(rings)
    else:  # cylinder, cone
        if _is_cap(points, normal):
            # the cylinder's two caps are parts 1 (top) and 2 (bottom); the cone has one, its base, part 1
            part = 1 if (prim_type == 'cone' or points[0][1] > 0.0) else 2
            vs = [2.0 * r for r in radii]
        else:
            vs = [p[1] + 0.5 for p in points]
    return part, list(zip(_unwrapped(longitudes), vs))


def polygon_loci(prim_type, corners, normal=None):
    """(part, [(u, v), ...]) for one polygon of a primitive's preview mesh: `corners` are the positions of its corners in loop order, in
    Blender's native frame; `normal` its normal there (worked out from the corners when not given). The part is the engine's patch the
    polygon lies in (a cube's face 0 to 5, a cylinder's wall 0 / top 1 / bottom 2, a cone's wall 0 / base 1, 0 for the others) and the
    list is the (u, v) of each corner in it, on the same turn of a longitude from corner to corner. A shape the engine has no
    parametrisation for gets None."""
    if prim_type not in ENGINE_TYPES or len(corners) < 3:
        return None
    points = [native_to_canonical(c) for c in corners]
    n = native_direction_to_canonical(normal) if normal is not None else newell_normal(points)
    if prim_type == 'cube':
        # the face a polygon lies on is the one its middle is on: from the cube's centre, not from the winding (a flipped polygon
        # keeps its face); the normal only answers for a polygon whose middle is at the centre, which no face of a cube has
        middle = tuple(sum(p[i] for p in points) / len(points) for i in range(3))
        face = cube_face_of(middle if max(abs(c) for c in middle) > AXIS_EPS else n)
        return face, [cube_uv(face, p) for p in points]
    if prim_type == 'plane':
        return 0, [(p[0] + 0.5, p[2] + 0.5) for p in points]
    part, uvs = _around_axis(prim_type, points, n)
    if (part != 0 or prim_type == 'disc') and len(points) > 4:
        # an n-gon cap (or disc) has no middle corner to be the pole of its polar layout: all its corners would sit on the rim. Laid flat
        # instead (a stand-in - the add-on gives a cap a middle by poking the face, see mesh_preview.poke_ngons)
        return part, [(p[0] + 0.5, p[2] + 0.5) for p in points]
    return part, uvs


def polygon_uvs(prim_type, corners, normal=None):
    """The (u, v) of each corner of one polygon, see polygon_loci; None for a shape the engine has no parametrisation for."""
    loci = polygon_loci(prim_type, corners, normal)
    return None if loci is None else loci[1]


def mesh_loop_uvs(prim_type, positions, polygons):
    """The (u, v) of every loop of a mesh, polygon by polygon, in the order of `polygons` and of each polygon's corners: `positions` is
    the list of the mesh's vertices (native frame), `polygons` the list of tuples of vertex indices, one per polygon in loop order.
    Returns a flat list, one (u, v) per loop, or None for a shape the engine has no parametrisation for."""
    if prim_type not in ENGINE_TYPES:
        return None
    out = []
    for polygon in polygons:
        uvs = polygon_uvs(prim_type, [positions[i] for i in polygon])
        out.extend(uvs if uvs is not None else [(0.0, 0.0)] * len(polygon))
    return out


# ------------------------------------------------------------------------------------------------ the grids the add-on builds itself

def grid_corner_uv(i, j, segments):
    """The (u, v) of the corner (i, j) of the grid of `segments` x `segments` quads that stands for a patch (a face of a rounded cube):
    the patch's own coordinates, i / segments across and j / segments up - the way mesh_preview.build_smooth_cube_mesh generates it."""
    return (i / segments, j / segments)
