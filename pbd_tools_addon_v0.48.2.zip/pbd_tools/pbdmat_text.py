"""The text of a .pbdmat, read the way the engine's PbdMatParser reads it - no Blender needed.

`parse_pbdmat_text(text)` is the grammar of pbd.format.PbdMatParser (author= lines, then `material NAME { key = value ... }` blocks; a value is a quoted
string, a balanced (...) group or one bare token; `#` starts a comment wherever a token could start - not inside a bare word, so `a#b.png` is a name),
word for word, as a few dozen lines instead of a guess at it. tools/regression/blender_addon_check.py feeds both parsers the same files, odd ones
included, and compares; addon_compiled_check.py does the same for the pictures a file names.

It lives in a module of its own because two kinds of code need it and only one of them has Blender: materials.py (the three readers of a .pbdmat,
the Save button) and compiled_export.py (which pictures a material needs, to put them in a bundle or beside a compiled file).
"""


def _is_white(c):
    """Java's Character.isWhitespace, which the engine's PbdMatParser splits on: Python's, except the no-break spaces and U+0085."""
    return c.isspace() and c not in "\u00a0\u2007\u202f\x85"


def _java_trim(s):
    """String.trim(): drops everything up to U+0020 from both ends, and nothing else."""
    return s.strip("".join(chr(i) for i in range(0x21)))


class _PbdmatReader:
    """The grammar of the engine's PbdMatParser, read the same way (author= lines, then `material NAME { key = value ... }` blocks;
    a value is a quoted string, a balanced (...) group or one bare token; `#` starts a comment), as a few dozen lines instead of a
    guess at it. tools/regression/blender_addon_check.py feeds both parsers the same files, odd ones included, and compares."""

    def __init__(self, text):
        self.src = text
        self.pos = 0
        self.line = 1
        self.authors = []

    def _end(self):
        return self.pos >= len(self.src)

    def _peek(self):
        if self._end():
            raise ValueError(f"line {self.line}: unexpected end of file")
        return self.src[self.pos]

    def _skip(self):
        while not self._end():
            c = self.src[self.pos]
            if c == "\n":
                self.line += 1
                self.pos += 1
            elif _is_white(c):
                self.pos += 1
            elif c == "#":
                while not self._end() and self.src[self.pos] != "\n":
                    self.pos += 1
            else:
                break

    def _word(self):
        start = self.pos
        while not self._end() and self.src[self.pos] not in "{}()=" and not _is_white(self.src[self.pos]):
            self.pos += 1
        return self.src[start:self.pos]

    def _identifier(self):
        self._skip()
        word = self._word()
        if not word:
            raise ValueError(f"line {self.line}: expected a name")
        return word

    def _peek_identifier(self):
        saved = (self.pos, self.line)
        self._skip()
        word = self._word()
        self.pos, self.line = saved
        return word

    def _expect(self, c):
        self._skip()
        if self._end() or self.src[self.pos] != c:
            found = "the end of the file" if self._end() else f"'{self.src[self.pos]}'"
            raise ValueError(f"line {self.line}: expected '{c}', found {found}")
        self.pos += 1

    def _value(self):
        self._skip()
        c = self._peek()
        if c == '"':
            self.pos += 1
            start = self.pos
            while not self._end() and self.src[self.pos] != '"':
                self.pos += 1
            text = self.src[start:self.pos]
            if not self._end():
                self.pos += 1
            return text
        start = self.pos
        if c == "(":
            depth = 0
            while True:
                ch = self.src[self.pos]
                self.pos += 1
                if ch == "(":
                    depth += 1
                elif ch == ")":
                    depth -= 1
                if depth <= 0 or self._end():
                    break
        else:
            self._word()
        return _java_trim(self.src[start:self.pos])

    def _author(self):
        self._skip()
        if self._peek() == '"':
            return self._value()
        start = self.pos
        while not self._end() and self.src[self.pos] not in "\n#":
            self.pos += 1
        return _java_trim(self.src[start:self.pos])

    def _block(self):
        self._expect("{")
        fields = {}
        self._skip()
        while self._peek() != "}":
            key = self._identifier()
            self._expect("=")
            fields[key] = self._value()
            self._skip()
        self._expect("}")
        return fields

    def read(self):
        materials = {}
        self._skip()
        while not self._end() and self._peek_identifier() == "author":
            self._identifier()
            self._expect("=")
            self.authors.append(self._author())
            self._skip()
        while not self._end():
            keyword = self._identifier()
            if keyword != "material":
                raise ValueError(f"line {self.line}: expected 'material', found '{keyword}'")
            name = self._identifier()
            materials[name] = self._block()
            self._skip()
        return materials


def parse_pbdmat_text(text):
    """-> (the author= lines, {material name: {key: raw string}}), exactly what the engine's PbdMatParser makes of the same text.
    Raises ValueError (with the line) for a file the engine refuses."""
    reader = _PbdmatReader(text)
    materials = reader.read()
    return reader.authors, materials
