import bpy
import math

from . import materials
from . import mesh_preview

# Fixed name for the one native modifier this add-on still manages (bend);
# smooth and shear are previewed by directly writing mesh data instead,
# see mesh_preview.py - there is no native Blender effect that matches
# either accurately enough to justify a modifier-based approximation, per
# the project's "implement it in Python if Blender has nothing that
# actually matches" policy.
_BEND_PREVIEW_MODIFIER = "PBD_Bend_Preview"
_SHEAR_BASE_KEY = "_pbd_shear_base_verts"


class PbdDoorLinkItem(bpy.types.PropertyGroup):
    """One entry in a storage cube's list of doors that can open it -
    several doors can share one storage volume (a big wardrobe with two
    independent doors over the same shelf, say), which a single
    PointerProperty couldn't represent at all."""
    door: bpy.props.PointerProperty(
        type=bpy.types.Object,
        name="Door",
        description="An object whose keyframe animation, once fully open, makes this container's contents show",
    )


class PbdMeshLodEntry(bpy.types.PropertyGroup):
    """One additional LOD variant for a 'mesh'-type primitive - its
    geometry lives in mesh_data, a Mesh DATABLOCK that is deliberately
    NEVER linked to any Object or collection (so it never shows as a
    second, separate visible thing in the scene the way a plain
    PointerProperty(Object) forced before this) - see
    OBJECT_OT_pbd_capture_mesh_lod/OBJECT_OT_pbd_apply_mesh_lod for how
    it gets written and read. "Capture" copies the active object's
    CURRENT geometry into this slot; "Apply" replaces the active
    object's current geometry with what is stored here - the object
    itself TRANSFORMS between saved shapes on demand, rather than
    needing a whole second object to exist and be hidden/shown by hand."""
    lod: bpy.props.IntProperty(
        name="LOD", default=1, min=1,
        description="Tier number (never 0 - that's always this object's own CURRENT geometry, not an entry here)",
    )
    mesh_data: bpy.props.PointerProperty(
        type=bpy.types.Mesh,
        name="Stored Shape",
        description="This tier's saved geometry - set via Capture Current Shape, restored onto the object via Apply This Shape",
    )


class PbdKeyframeSoundEntry(bpy.types.PropertyGroup):
    """One entry mapping a keyframe TIME (in seconds, matching what the
    panel already lists per keyframe) to a sound file to play once
    playback reaches it - keyframes themselves come from ordinary
    Blender f-curves, which have no built-in slot for arbitrary custom
    data per keyframe point, so this small separate collection (keyed by
    time rather than attached to the keyframe point itself) is what
    _serialize_keyframes/import_pbd both read and write to carry a
    keyframe's `sound=` field through export/import."""
    time: bpy.props.FloatProperty(name="Time")
    sound_file: bpy.props.StringProperty(name="Sound File", subtype='FILE_PATH')


def _sync_bend_preview(self, context):
    """Keeps a native Blender SimpleDeform modifier in sync with the PBD
    bend settings, so the viewport mesh actually curves the same way the
    engine's pbd.tese/applyBend does. Unlike smooth/shear below, this one
    genuinely matches: SimpleDeform's Bend mode IS the same constant-
    curvature circular arc pbd.tese now implements (the previous version
    of applyBend was not - see pbd.tese's comment on `shear` for what that
    actually did, and why it needed a different name and a from-scratch
    Python preview instead of a modifier).

    deform_axis maps 1:1 to the engine's bend axis (X/Y/Z), both meaning
    "which coordinate does the rotation leave unchanged" - checked for all
    three, not assumed: a subdivided cube was bent under each of
    SimpleDeform's three deform_axis settings and the vertex coordinates
    inspected directly. X left X unchanged and rotated Y/Z; Y left Y
    unchanged and rotated Z/X; Z left Z unchanged and rotated X/Y.
    """
    obj = self.id_data
    existing = obj.modifiers.get(_BEND_PREVIEW_MODIFIER)

    if not (self.is_pbd_primitive and self.pbd_bend_enabled):
        if existing is not None:
            obj.modifiers.remove(existing)
        return

    mod = existing if existing is not None else obj.modifiers.new(
        name=_BEND_PREVIEW_MODIFIER, type='SIMPLE_DEFORM')
    mod.deform_method = 'BEND'
    mod.deform_axis = self.pbd_bend_axis
    mod.angle = self.pbd_bend_angle


def _sync_cap_preview(self, context):
    """Regenerates the mesh via mesh_preview.write_cap_preview whenever
    the cap setting changes, for cylinder/cone only."""
    obj = self.id_data
    if not (self.is_pbd_primitive and self.pbd_type in ('cylinder', 'cone')):
        return
    mesh_preview.write_cap_preview(obj, self.pbd_type, self.pbd_cap)


def _sync_smooth_preview(self, context):
    """Regenerates the cube's mesh directly from mesh_preview's per-axis
    ellipsoid-rounding formula - the exact math pbd.tese uses, not Bevel's
    single-width flat-facet approximation (Bevel has no per-axis width
    concept at all, so it could not represent a flat-topped, round-sided
    cushion correctly no matter how it was configured). All-zero
    smoothness correctly regenerates a plain flat cube (the verified
    degenerate case), so this always regenerates rather than needing a
    separate "disabled" code path. Also the sync point for face removal
    (pbd_cube_face_*) - both features edit the same mesh, so one shared
    regeneration keeps them from fighting over which one's write wins."""
    obj = self.id_data
    if not (self.is_pbd_primitive and self.pbd_type == 'cube'):
        return
    removed = set()
    if not self.pbd_cube_face_posx: removed.add(0)
    if not self.pbd_cube_face_negx: removed.add(1)
    if not self.pbd_cube_face_posz: removed.add(2)  # Blender +Z -> canonical +Y (top)
    if not self.pbd_cube_face_negz: removed.add(3)  # Blender -Z -> canonical -Y (bottom)
    if not self.pbd_cube_face_negy: removed.add(4)  # Blender -Y -> canonical +Z
    if not self.pbd_cube_face_posy: removed.add(5)  # Blender +Y -> canonical -Z
    mesh_preview.write_smooth_cube_mesh(
        obj, self.pbd_cube_smooth_x, self.pbd_cube_smooth_y, self.pbd_cube_smooth_z,
        removed_faces=removed)


def _sync_shear_preview(self, context):
    """Deforms the object's mesh with mesh_preview's shear formula (the
    same math as pbd.tese's applyShear). The FIRST time shear is enabled
    (or if the vertex count no longer matches, e.g. the type changed), the
    object's current shape is cached as a custom property so repeated
    slider adjustments deform from that original shape rather than
    compounding onto an already-sheared mesh; disabling shear restores it.
    """
    obj = self.id_data

    if not (self.is_pbd_primitive and self.pbd_shear_enabled):
        if _SHEAR_BASE_KEY in obj:
            base = obj[_SHEAR_BASE_KEY]
            mesh = obj.data
            if len(mesh.vertices) == len(base) // 3:
                for i, v in enumerate(mesh.vertices):
                    v.co = (base[i * 3], base[i * 3 + 1], base[i * 3 + 2])
                mesh.update()
        return

    mesh = obj.data
    needs_new_base = (
        _SHEAR_BASE_KEY not in obj
        or len(obj[_SHEAR_BASE_KEY]) != len(mesh.vertices) * 3
    )
    if needs_new_base:
        flat = []
        for v in mesh.vertices:
            flat.extend(v.co)
        obj[_SHEAR_BASE_KEY] = flat

    base = obj[_SHEAR_BASE_KEY]
    base_verts = [(base[i * 3], base[i * 3 + 1], base[i * 3 + 2]) for i in range(len(base) // 3)]
    mesh_preview.write_shear_preview(
        obj, base_verts, self.pbd_shear_factor_x, self.pbd_shear_factor_y, self.pbd_shear_factor_z)


def _sync_material_assignment(self, context):
    """Pushes the picked material onto the object so it actually previews
    that color/shading in the viewport - see materials.py for how a name
    resolves to a real Blender Material (the scene catalog if it's
    there, else a neutral placeholder)."""
    obj = self.id_data
    if obj.type == 'MESH' and self.pbd_material:
        materials.assign_material_to_object(obj, self.pbd_material)


def _make_dim_getset(axis):
    def getter(self):
        obj = self.id_data
        return getattr(obj.dimensions, axis) if obj else 0.0

    def setter(self, value):
        obj = self.id_data
        current_scale = getattr(obj.scale, axis)
        if abs(current_scale) < 1e-6:
            return  # can't recover a native size from a fully-collapsed axis
        native_size = getattr(obj.dimensions, axis) / current_scale
        if native_size < 1e-6:
            return
        setattr(obj.scale, axis, value / native_size)

    return getter, setter


def _make_face_getset(axis, is_max):
    """Moves ONE face of the object's bounding box on one axis - the
    opposite face stays exactly where it was, rather than dim_x/y/z's
    symmetric "grow from center" behavior. This is what building
    adjoining panels actually needs: a cabinet's inner wall face pinned
    to a specific position while only the outer face (thickness) moves,
    not both moving apart from the middle. Assumes the object isn't
    rotated - min/max stop meaning "a single axis-aligned face" the
    moment rotation is involved, and this add-on's own primitives
    (panels, walls) are built axis-aligned in the first place."""
    def getter(self):
        obj = self.id_data
        if not obj:
            return 0.0
        center = getattr(obj.location, axis)
        half = getattr(obj.dimensions, axis) / 2.0
        return center + half if is_max else center - half

    def setter(self, value):
        obj = self.id_data
        current_scale = getattr(obj.scale, axis)
        if abs(current_scale) < 1e-6:
            return
        native_size = getattr(obj.dimensions, axis) / current_scale
        if native_size < 1e-6:
            return
        center = getattr(obj.location, axis)
        half = getattr(obj.dimensions, axis) / 2.0
        other_face = (center - half) if is_max else (center + half)  # stays fixed
        new_dim = abs(value - other_face)
        new_center = (value + other_face) / 2.0
        setattr(obj.location, axis, new_center)
        setattr(obj.scale, axis, new_dim / native_size)

    return getter, setter


def _sync_metadata_display(self, context):
    """Wireframe-only display in Blender for a metadata marker - still
    visible and clickable for positioning it, but visually distinct from
    real geometry it's easy to otherwise mistake it for. Engine-side
    invisibility (see PatchExpander's metadata check) doesn't need any
    equivalent Blender-side toggle here - display_type is purely a
    Blender viewport setting, unrelated to what gets exported."""
    obj = self.id_data
    obj.display_type = 'WIRE' if self.pbd_metadata else 'TEXTURED'


class PbdPrimitiveProperties(bpy.types.PropertyGroup):
    """PBD data attached to a Blender object. An object without
    is_pbd_primitive=True is simply ignored by the exporter - no need to
    remove it from the scene to exclude it from the export."""

    is_pbd_primitive: bpy.props.BoolProperty(
        name="PBD Primitive",
        default=False,
    )
    pbd_type: bpy.props.EnumProperty(
        name="Type",
        items=[
            ('plane', "Plane", "Canonical plane (unit square, XZ)"),
            ('sphere', "Sphere", "Canonical sphere (radius 0.5)"),
            ('cylinder', "Cylinder", "Canonical cylinder (radius 0.5, height 1)"),
            ('cone', "Cone", "Canonical cone (radius 0.5, height 1)"),
            ('cube', "Cube", "Canonical cube ([-0.5, 0.5]^3)"),
            ('disc', "Disc", "Canonical flat disc (diameter 1, lies in XZ)"),
            ('torus', "Torus", "Canonical torus (major radius 0.35, minor radius 0.15)"),
            ('mesh', "Mesh (traditional)", "Arbitrary triangulated geometry embedded as base64 data - THIS object's own current mesh, exactly as it looks in Blender, not a procedural shape. Use 'Convert to PBD Mesh' rather than picking this directly, since only that button captures the geometry too."),
            ('ref', "Reference (pbd_ref)", "Places another .pbd file's whole scene here, transformed - see pbd_ref_source"),
            ('light', "Light", "A point or spot light source - no geometry of its own, affects how OTHER geometry gets lit. See the Light section below once selected"),
        ],
        default='cube',
    )
    pbd_material: bpy.props.StringProperty(
        name="Material",
        default="default",
        description="Pick from the scene's PBD Materials list (see the "
                    "Materials panel) or type a name directly - 'wood', "
                    "'metal' and 'plastic' have real shading on the "
                    "engine's GPU side even without a catalog entry; any "
                    "other undefined name falls back to a neutral grey "
                    "appearance rather than failing",
        update=_sync_material_assignment,
    )
    pbd_link_group: bpy.props.StringProperty(
        name="Link Group",
        default="",
        description="Objects sharing this name (and each having their own keyframes) open/close together from a single click in the engine - a wardrobe's two doors, say. Leave empty for independent objects",
    )
    pbd_metadata: bpy.props.BoolProperty(
        name="Metadata Only (invisible)",
        default=False,
        description="This primitive's position/size are kept (for a container's interior storage volume, say - later used for bin-packing game items into it) but it renders nothing at all, in the engine or in Blender - the shape and size still matter, only the visibility doesn't",
        update=_sync_metadata_display,
    )
    pbd_lod_enabled: bpy.props.BoolProperty(
        name="Set LOD tier",
        default=False,
        description="Tags this instance with a level-of-detail tier number (lod= in the exported file). Field-level only for now: it round-trips through export/import, but the engine does not yet use it to actually choose between several same-purpose instances by camera distance - that needs its own grouping concept and rendering logic, not implemented yet (see ENGINE_DEV_GUIDE.md)",
    )
    pbd_lod: bpy.props.IntProperty(
        name="LOD Tier",
        default=0,
        min=0,
        description="Lower is usually higher detail, but this is convention only - nothing in the current engine enforces an ordering (see pbd_lod_enabled's own description for what LOD does and doesn't do yet)",
    )
    pbd_category: bpy.props.StringProperty(
        name="Category",
        default="",
        description="Optional free-form semantic tag ('chair', 'outdoor-decor', whatever a content pipeline finds useful) for telling this instance's PURPOSE apart from others, without relying on mat= alone - two chairs in different woods share no material, and unrelated props can share one. Purely descriptive: nothing in the engine reads it today, it's for external tooling to filter/group by. Leave empty for none - exported as category= only when set",
    )
    pbd_indestructible: bpy.props.BoolProperty(
        name="Indestructible",
        default=False,
        description="Never converted to voxels by the runtime primitive->voxel transform, and never affected by alterations to nearby voxelized geometry - a wall or floor an author wants to guarantee stays solid regardless of what happens around it. Exported as indestructible=true only when checked (the field is absent, not written as false, otherwise)",
    )
    pbd_hardness: bpy.props.FloatProperty(
        name="Hardness",
        default=1.0, min=0.0, soft_max=10.0,
        description="Optional physical parameter, meaningful alongside Indestructible above - how much force it takes to even begin affecting this instance. Only exported when Indestructible is checked (see hardness= in the format spec) - a non-indestructible primitive doesn't have a fixed shape to apply a hardness value TO in the first place, since the voxel transform is what would determine that dynamically instead",
    )
    pbd_resistance: bpy.props.FloatProperty(
        name="Resistance",
        default=1.0, min=0.0, soft_max=10.0,
        description="Optional physical parameter, meaningful alongside Indestructible above - how much sustained damage it takes before any effect shows at all, distinct from Hardness (which is about the force THRESHOLD, not the total amount withstood). Only exported when Indestructible is checked",
    )
    pbd_light_mode: bpy.props.EnumProperty(
        name="Mode",
        items=[
            ('point', "Point", "Radiates equally in every direction from this instance's own position"),
            ('spot', "Spot", "A cone of light aimed along this instance's own -Z (matching Blender's own spot lamp convention) - see Spot Angle below"),
        ],
        default='point',
        description="Only meaningful when Type (above) is set to Light",
    )
    pbd_light_enabled: bpy.props.BoolProperty(
        name="Enabled",
        default=True,
        description="Runtime on/off (a light switch, say) - unchecking this keeps every other light setting (color, intensity...) authored but off until toggled back on. Exported only when unchecked, since on is the default",
    )
    pbd_light_color: bpy.props.FloatVectorProperty(
        name="Color", subtype='COLOR', size=3, default=(1.0, 1.0, 1.0), min=0.0, max=1.0,
        description="This light's own color - independent of any material's color, since a light isn't shaded, it's a light SOURCE",
    )
    pbd_light_intensity: bpy.props.FloatProperty(
        name="Intensity", default=3.0, min=0.0, soft_max=20.0,
        description="Brightness scale - no fixed physical unit (same \"authored, not physically calibrated\" convention as a material's own shininess/specular)",
    )
    pbd_light_range: bpy.props.FloatProperty(
        name="Range", default=6.0, min=0.01, soft_max=50.0,
        description="World-space distance at which this light's contribution fades to zero",
    )
    pbd_light_spot_angle: bpy.props.FloatProperty(
        name="Spot Angle", default=math.radians(30.0), min=math.radians(1.0), max=math.radians(89.0), subtype='ANGLE',
        description="Half-angle of the light cone, in degrees - only meaningful when Mode is Spot",
    )
    pbd_linked_doors: bpy.props.CollectionProperty(
        type=PbdDoorLinkItem,
        name="Doors",
        description="Every door that can open this container - contents show once ANY of them is fully open; with no doors listed, the engine falls back to \"any open object in the whole scene\"",
    )
    pbd_linked_doors_active_index: bpy.props.IntProperty(default=0)
    pbd_mesh_lod_sources: bpy.props.CollectionProperty(type=PbdMeshLodEntry)
    pbd_mesh_lod_active_index: bpy.props.IntProperty(default=0)
    pbd_loop_animation: bpy.props.BoolProperty(
        name="Loop Animation",
        default=False,
        description="This object's keyframes ping-pong continuously in the engine (a ceiling fan, a decorative element) instead of the default click-to-open/close behavior - no click needed, and clicking it has no effect",
    )
    pbd_channel_name: bpy.props.StringProperty(
        name="Channel Name",
        default="",
        description="Leave empty for normal animation (played back in real time, like a door). Set to a name (e.g. \"humidity\") to make this object's keyframes driven by that named channel's own accumulated value instead - keyframe Scale normally on Blender's timeline, this just changes what its frame numbers MEAN once exported. See pbd.render.ChannelTracker on the engine side for what actually makes a channel accumulate.",
    )
    pbd_channel_time_scale: bpy.props.FloatProperty(
        name="Channel Time Scale",
        default=0.1,
        description="Only used when Channel Name is set: multiplies this object's Blender frame number to get the channel value that frame maps to. A small factor is what turns an ordinary, fast-looking Blender animation (say frame 0 to frame 24) into a very slow one once the engine plays it back at the channel's own, usually much slower, pace - that's the whole illusion behind vegetation looking like it grows in over real days from a few seconds of ordinary keyframing.",
    )
    pbd_keyframe_sounds: bpy.props.CollectionProperty(type=PbdKeyframeSoundEntry)
    pbd_ref_source: bpy.props.StringProperty(
        name="Source .pbd",
        default="",
        subtype='FILE_PATH',
        description="Local path OR a full http(s):// URL to the .pbd file this reference places into the scene. A local path is resolved relative to wherever THIS file gets exported; a URL is fetched and cached (see PbdFetcher/fetcher.py) - use the Test Reference button below to fetch it right now and confirm it resolves.",
    )
    pbd_ref_fallback: bpy.props.StringProperty(
        name="Fallback URL",
        default="",
        description="Only used when Source above is a URL: tried if the primary URL 404s or is otherwise unreachable, before finally falling back to whatever was cached from a previous successful fetch. Leave empty for no fallback.",
    )
    pbd_ref_mat_override: bpy.props.StringProperty(
        name="Material Override",
        default="",
        description="Optional - overrides EVERY instance's own mat= inside the referenced file, applied only to THIS placement of it (the source file itself is untouched, so other references to the same file keep their own materials). Leave empty to use each instance's own material as authored",
    )
    pbd_ref_embed: bpy.props.BoolProperty(
        name="Embed contents in this file",
        default=False,
        description="When on, the referenced file's instances are copied directly into THIS exported .pbd (parented to an invisible anchor at this object's transform) instead of being kept as a separate pbd_ref pointing at an external file - use when you want one self-contained file instead of several linked ones. The source file on disk is unaffected either way.",
    )

    # World-space size in meters - a live view onto obj.dimensions
    # (get/set, not a stored value) so it's never stale for a type whose
    # native per-axis size isn't the common 2.0 (torus's Z is 0.6).
    # Centering needs no separate handling: every primitive here has its
    # origin at its own geometric center, and scaling around the object
    # origin - which setting obj.scale always does - can't move that
    # center.
    pbd_dim_x: bpy.props.FloatProperty(name="Dim X", min=0.001, unit='LENGTH',
        get=_make_dim_getset('x')[0], set=_make_dim_getset('x')[1])
    pbd_dim_y: bpy.props.FloatProperty(name="Dim Y", min=0.001, unit='LENGTH',
        get=_make_dim_getset('y')[0], set=_make_dim_getset('y')[1])
    pbd_dim_z: bpy.props.FloatProperty(name="Dim Z", min=0.001, unit='LENGTH',
        get=_make_dim_getset('z')[0], set=_make_dim_getset('z')[1])

    # Per-face position (world space) - moves just that one face, the
    # opposite face stays put. See _make_face_getset for why this is
    # different from (and usually more useful than) Dim X/Y/Z above.
    pbd_face_min_x: bpy.props.FloatProperty(name="Face -X", unit='LENGTH',
        get=_make_face_getset('x', False)[0], set=_make_face_getset('x', False)[1])
    pbd_face_max_x: bpy.props.FloatProperty(name="Face +X", unit='LENGTH',
        get=_make_face_getset('x', True)[0], set=_make_face_getset('x', True)[1])
    pbd_face_min_y: bpy.props.FloatProperty(name="Face -Y", unit='LENGTH',
        get=_make_face_getset('y', False)[0], set=_make_face_getset('y', False)[1])
    pbd_face_max_y: bpy.props.FloatProperty(name="Face +Y", unit='LENGTH',
        get=_make_face_getset('y', True)[0], set=_make_face_getset('y', True)[1])
    pbd_face_min_z: bpy.props.FloatProperty(name="Face -Z", unit='LENGTH',
        get=_make_face_getset('z', False)[0], set=_make_face_getset('z', False)[1])
    pbd_face_max_z: bpy.props.FloatProperty(name="Face +Z", unit='LENGTH',
        get=_make_face_getset('z', True)[0], set=_make_face_getset('z', True)[1])

    # Cylinder/cone only - which end caps to export. Read by the exporter
    # into a plain `cap=` param (PbdInstance's free-form params map, no
    # parser change needed) and by PatchExpander to decide which patches
    # to emit - see its docstring. "Top" = +Y, "bottom" = -Y, matching the
    # local Y axis being the height axis for every canonical primitive.
    # Previewed by regenerating the mesh (see mesh_preview.write_cap_preview)
    # rather than a modifier - no native Blender modifier removes one named
    # face without extra per-object setup (a vertex group or a second
    # boolean object), which this add-on's other previews already avoid
    # needing for the same reason (smooth, shear).
    pbd_cap: bpy.props.EnumProperty(
        name="Caps",
        items=[
            ('both', "Both", "Keep both end caps (default)"),
            ('top', "Top only", "Keep only the +Y cap"),
            ('bottom', "Bottom only", "Keep only the -Y cap"),
            ('none', "None", "Remove both end caps (open tube)"),
        ],
        default='both',
        update=lambda self, context: _sync_cap_preview(self, context),
    )

    # Bend - a real constant-curvature circular arc (see pbd.tese's
    # applyBend). Axis picks both the bend plane and (cyclically) which
    # coordinate is the arc-length parameter - use whichever axis this
    # object has meaningful extent along (a cylinder standing in Y wants
    # X or Z so the pole's own height drives the curve).
    pbd_bend_enabled: bpy.props.BoolProperty(
        name="Enable Bend",
        default=False,
        update=_sync_bend_preview,
    )
    pbd_bend_axis: bpy.props.EnumProperty(
        name="Bend Axis",
        items=[
            ('X', "X (arc-length Y)", "Bends the Y extent into the Y/Z plane; X untouched"),
            ('Y', "Y (arc-length Z)", "Bends the Z extent into the Z/X plane; Y untouched"),
            ('Z', "Z (arc-length X)", "Bends the X extent into the X/Y plane; Z untouched"),
        ],
        default='X',
        update=_sync_bend_preview,
    )
    pbd_bend_angle: bpy.props.FloatProperty(
        name="Bend Angle",
        default=0.0,
        subtype='ANGLE',  # stored/returned in radians, displayed in degrees - export converts back to degrees
        description="Total angle swept across the object's full extent along the chosen axis",
        update=_sync_bend_preview,
    )

    # Shear (formerly mislabeled `bend`) - rotates one plane of coordinates
    # by an angle proportional to a third, which in practice scales that
    # cross-section rather than preserving it like a real bend does. Kept
    # for the warped/spiral look it gives flat shapes (a disc-based leaf's
    # curve, say); all three factors apply together, not a single axis
    # choice, so combined effects are possible where useful. No native
    # Blender modifier matches this, so it's previewed by directly
    # deforming the mesh (see mesh_preview.write_shear_preview).
    pbd_shear_enabled: bpy.props.BoolProperty(
        name="Enable Shear",
        default=False,
        update=_sync_shear_preview,
    )
    pbd_shear_factor_x: bpy.props.FloatProperty(
        name="Factor X", default=0.0, soft_min=-5.0, soft_max=5.0,
        description="Case X: rotates Y/Z by an angle proportional to Y",
        update=_sync_shear_preview,
    )
    pbd_shear_factor_y: bpy.props.FloatProperty(
        name="Factor Y", default=0.0, soft_min=-5.0, soft_max=5.0,
        description="Case Y: rotates Z/X by an angle proportional to Z",
        update=_sync_shear_preview,
    )
    pbd_shear_factor_z: bpy.props.FloatProperty(
        name="Factor Z", default=0.0, soft_min=-5.0, soft_max=5.0,
        description="Case Z: rotates X/Y by an angle proportional to X",
        update=_sync_shear_preview,
    )

    # Taper modifier (cylinder/cone) - independently scales the radius at
    # each end, e.g. for a lampshade-style frustum. Both default to 1.0
    # (no change, matching an untapered shape).
    pbd_taper_enabled: bpy.props.BoolProperty(
        name="Enable Taper",
        default=False,
    )
    pbd_taper_bottom_scale: bpy.props.FloatProperty(
        name="Bottom Scale", default=1.0, min=0.0, soft_max=2.0,
        description="Radius multiplier at the -Y end",
    )
    pbd_taper_top_scale: bpy.props.FloatProperty(
        name="Top Scale", default=1.0, min=0.0, soft_max=2.0,
        description="Radius multiplier at the +Y end",
    )

    # Cube only - per-axis rounding radius for the edges/corners (0 = sharp
    # on that axis, up to 0.5 = fully round on that axis). Independent
    # per-axis values, not one shared value, specifically so a wide flat
    # cushion can have a flat top (smoothY near 0) while its side edges
    # are still rounded (larger smoothX/smoothZ). Previewed by directly
    # regenerating the mesh (see mesh_preview.write_smooth_cube_mesh) -
    # Bevel has no per-axis width concept, so it could not represent this
    # shape at all, not even approximately.
    pbd_cube_smooth_x: bpy.props.FloatProperty(
        name="Smooth X", default=0.0, min=0.0, max=0.5,
        description="Rounding radius along local X - 0.5 degenerates that axis fully round",
        update=_sync_smooth_preview,
    )
    pbd_cube_smooth_y: bpy.props.FloatProperty(
        name="Smooth Y", default=0.0, min=0.0, max=0.5,
        description="Rounding radius along local Y (height) - keep near 0 for a flat top/bottom, e.g. a cushion",
        update=_sync_smooth_preview,
    )
    pbd_cube_smooth_z: bpy.props.FloatProperty(
        name="Smooth Z", default=0.0, min=0.0, max=0.5,
        description="Rounding radius along local Z",
        update=_sync_smooth_preview,
    )

    # Face removal - an open-topped crate, a cabinet with no back panel,
    # etc. Labeled in BLENDER's own axis terms (what you see in the
    # viewport gizmo) since that's what's actually useful while modeling;
    # export_pbd.py converts to the engine's canonical face codes (its
    # Y-up convention means Blender's own +Z/-Z map to the engine's
    # +Y/-Y "top"/"bottom", verified against _AXIS_CONVERSION rather than
    # assumed - see export_pbd.py's FACE_BLENDER_TO_PBD table). All
    # default True (kept) so a file written before this existed still
    # round-trips as a full 6-face cube.
    pbd_cube_face_posx: bpy.props.BoolProperty(
        name="+X", default=True, description="Keep the +X face", update=_sync_smooth_preview)
    pbd_cube_face_negx: bpy.props.BoolProperty(
        name="-X", default=True, description="Keep the -X face", update=_sync_smooth_preview)
    pbd_cube_face_posy: bpy.props.BoolProperty(
        name="+Y", default=True, description="Keep the +Y face", update=_sync_smooth_preview)
    pbd_cube_face_negy: bpy.props.BoolProperty(
        name="-Y", default=True, description="Keep the -Y face", update=_sync_smooth_preview)
    pbd_cube_face_posz: bpy.props.BoolProperty(
        name="+Z (Top)", default=True, description="Keep the +Z (top) face", update=_sync_smooth_preview)
    pbd_cube_face_negz: bpy.props.BoolProperty(
        name="-Z (Bottom)", default=True, description="Keep the -Z (bottom) face", update=_sync_smooth_preview)


CLASSES = (PbdDoorLinkItem, PbdKeyframeSoundEntry, PbdMeshLodEntry, PbdPrimitiveProperties)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Object.pbd = bpy.props.PointerProperty(type=PbdPrimitiveProperties)


def unregister():
    del bpy.types.Object.pbd
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
