"""Fetches a PBD/PBDMAT/PBDBIN asset from a URL, with local caching and a
fallback URL for a 404 - the Blender-side counterpart to pbd.net.PbdFetcher
in the Java engine. Deliberately minimal for security: exactly one HTTP
method (GET, nothing that writes or deletes anything remote), and
redirects are NOT followed automatically - a server-controlled redirect
silently retargeting a fetch is exactly the kind of thing a "keep it
simple" security posture should avoid doing on a caller's behalf.

User-Agent identifies this as addon traffic specifically (distinct from
the Java engine's own string) so server-side metrics can tell the two
apart.
"""

import hashlib
import os
import urllib.error
import urllib.request

USER_AGENT = "PrimitiveBasedDescription Blender (pbd.mazetrojan.fr)"


class FetchError(Exception):
    pass


def fetch(url, cache_dir, fallback_url=None, use_cache=True):
    """Returns the local cached file path for url. Uses the cache
    directly (no request at all) if a copy already exists and use_cache
    is True. On 404 or any other failure, tries fallback_url if given,
    then finally an existing stale cache entry, before raising."""
    os.makedirs(cache_dir, exist_ok=True)
    cache_path = _cache_path_for(url, cache_dir)

    if use_cache and os.path.exists(cache_path):
        return cache_path

    try:
        return _do_fetch(url, cache_path)
    except FetchError as primary_failure:
        if fallback_url:
            try:
                print(f"[fetcher] '{url}' failed ({primary_failure}) - trying fallback: {fallback_url}")
                return _do_fetch(fallback_url, cache_path)
            except FetchError as fallback_failure:
                print(f"[fetcher] Fallback also failed: {fallback_failure}")
        if os.path.exists(cache_path):
            print(f"[fetcher] Using stale cached copy of '{url}' after fetch failure")
            return cache_path
        raise


def _do_fetch(url, cache_path):
    if not (url.startswith("http://") or url.startswith("https://")):
        raise FetchError(f"Not an http(s) URL: {url}")

    request = urllib.request.Request(url, method="GET", headers={"User-Agent": USER_AGENT})
    try:
        # Explicitly built with no redirect handler installed beyond
        # urllib's own default opener behavior - urllib.request DOES
        # follow redirects by default via HTTPRedirectHandler, which
        # this project's own security preference (see PbdFetcher.java's
        # own doc comment) would rather avoid. A custom opener with
        # redirect handling disabled keeps this consistent with the
        # Java side: a redirect is treated as a failure, not resolved
        # transparently.
        opener = urllib.request.build_opener(_NoRedirectHandler)
        with opener.open(request, timeout=30) as response:
            data = response.read()
    except urllib.error.HTTPError as e:
        if e.code == 404:
            raise FetchError(f"404 Not Found: {url}") from e
        if 300 <= e.code < 400:
            raise FetchError(f"Redirect ({e.code}) not followed for '{url}' - this fetcher never follows redirects automatically") from e
        raise FetchError(f"HTTP {e.code} fetching '{url}'") from e
    except urllib.error.URLError as e:
        raise FetchError(f"Network error fetching '{url}': {e.reason}") from e

    with open(cache_path, "wb") as f:
        f.write(data)
    return cache_path


class _NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None  # returning None tells urllib to treat this as a terminal response, not follow it


def _cache_path_for(url, cache_dir):
    """Cache filename is a hash of the URL, not its own path segment -
    avoids collisions between two different URLs sharing a filename, and
    sidesteps sanitizing arbitrary URL characters into a valid filename."""
    hash_hex = hashlib.sha256(url.encode("utf-8")).hexdigest()[:32]
    return os.path.join(cache_dir, hash_hex + ".cache")
